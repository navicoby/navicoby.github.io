from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch

BASE=Path(__file__).resolve().parent
import runpy
runpy.run_path(str(BASE/'make_birds_eye.py'))
ESS=BASE/'pv_ess_screening'
RUN=BASE
OUT=BASE/'figures';OUT.mkdir(exist_ok=True)
b=pd.read_csv(BASE/'pv_comparison/baseline.csv').set_index('case_id')

hourly=pd.read_csv(ESS/'inputs/pv_hourly.csv.gz',index_col=0,parse_dates=True)
hourly.index=pd.to_datetime(hourly.index,utc=True).tz_convert('Asia/Seoul')
best=pd.read_csv(ESS/'results/selected_candidates.csv')
costs=pd.read_csv(ESS/'results/cost_scenarios.csv.gz')
energy=pd.read_csv(ESS/'results/annual_energy.csv.gz')
BLUE='#0072B2';ORANGE='#D55E00';GREEN='#009E73';GREY='#859199';BLACK='#20272d';PURPLE='#805BA6'
plt.rcParams.update({'font.family':['Arial','DejaVu Sans'],'font.size':8.5,'axes.labelsize':8.5,'axes.titlesize':9,'axes.titleweight':'normal','axes.linewidth':.65,'axes.edgecolor':BLACK,'xtick.major.width':.65,'ytick.major.width':.65,'xtick.major.size':3,'ytick.major.size':3,'axes.spines.top':False,'axes.spines.right':False,'legend.fontsize':7.7,'legend.frameon':False,'lines.linewidth':1.4,'lines.markersize':4,'svg.fonttype':'none','pdf.fonttype':42,'ps.fonttype':42,'savefig.facecolor':'white'})
manifest=[]
def save(fig,name):
    for ext in ['png','svg','pdf']:fig.savefig(OUT/f'{name}.{ext}',dpi=300,bbox_inches='tight',pad_inches=.08)
    manifest.append(name);plt.close(fig)
def label(ax,ch,title):
    ax.text(-.16,1.18,ch,transform=ax.transAxes,fontweight='bold',fontsize=10,va='baseline')
    ax.set_title(title,loc='left',pad=13)
def axis(ax):ax.grid(axis='y',color='#e4e8eb',lw=.5);ax.set_axisbelow(True)

# Figure 1: representative geometry and the actual calculation chain.
fig,axes=plt.subplots(2,1,figsize=(9,7));fig.subplots_adjust(hspace=.5)
ax=axes[0];ax.set(xlim=(-.5,9),ylim=(-.65,2.8));ax.axis('off')
for x,tilt,col in [(0,90,ORANGE),(4.5,30,BLUE)]:
    width=1.1*np.cos(np.radians(tilt));pitch=max(.5,width)+2
    for xx in [x,x+pitch]:
        ax.plot([xx,xx+width],[.3,.3+1.1*np.sin(np.radians(tilt))],color=col,lw=4)
        ax.plot([xx,xx],[0,.3],color=GREY,lw=1)
    ax.plot([x-.2,x+pitch+width+.2],[0,0],color=GREY,lw=.8)
    ax.annotate('',xy=(x,-.25),xytext=(x+pitch,-.25),arrowprops={'arrowstyle':'<->'})
    ax.text(x+pitch/2,-.55,f'Pitch {pitch:.3f} m',ha='center')
    ax.text(x+pitch/2,2.1,'Vertical bifacial' if tilt==90 else 'Tilted monofacial',ha='center',color=col,fontsize=12)
ax.text(3.6,2.65,'Same lower edge: 0.30 m | Same clear aisle: 2.00 m',ha='center',fontweight='bold')
ax=axes[1];ax.axis('off');ax.set(xlim=(0,10),ylim=(0,4))
boxes=[(.1,2.6,2.8,'Shared geometry + TMY','No weeds / snow'),(3.6,2.6,2.7,'pvlib hourly AC','Clean energy + height sweep'),(7.1,2.6,2.8,'ESS / cost screening','Equipment aging; clean PV'),(.1,.3,2.8,'Warp GPU','Dry + rain first-hit tracing'),(3.6,.3,2.7,'Persistent dust pools','Assumed rain wash-off'),(7.1,.3,2.8,'10-year optical losses','HSU domain checked')]
for x,y,w,t,sub in boxes:
    ax.add_patch(Rectangle((x,y),w,1,fc='#f3f7f9',ec=BLUE,lw=.8));ax.text(x+w/2,y+.67,t,ha='center',fontsize=10,fontweight='bold');ax.text(x+w/2,y+.27,sub,ha='center',fontsize=8.5)
for a,z in [((2.9,3.1),(3.6,3.1)),((6.3,3.1),(7.1,3.1)),((1.5,2.6),(1.5,1.3)),((2.9,.8),(3.6,.8)),((6.3,.8),(7.1,.8)),((5,2.6),(8,1.3))]:ax.annotate('',xy=z,xytext=a,arrowprops={'arrowstyle':'->','color':GREY})
fig.text(.5,.015,'Annual clean yield, assumed soiling loss and financial screening have distinct outputs; no field validation.',ha='center',fontsize=8)
save(fig,'fig1_study_framework')

# Figure 2: optical/electrical performance, all read from saved results.
fig,axes=plt.subplots(2,2,figsize=(7.2,5.5));fig.subplots_adjust(hspace=.65,wspace=.34,bottom=.13)
for tilt,color,name in [(30,BLUE,'Tilted monofacial'),(90,ORANGE,'Vertical bifacial')]:
    g=b[(b.tilt==tilt)&(b.index!='C01')].sort_values('albedo')
    axes[0,0].plot(g.albedo,g.specific_yield_kwh_kwp,'o-',color=color,label=name)
    axes[0,1].plot(g.albedo,(g.specific_yield_kwh_kwp/g.iloc[0].specific_yield_kwh_kwp-1)*100,'o-',color=color,label=name)
for ax in axes[0,:]:ax.set(xlabel='Ground albedo, α',xticks=[.2,.4,.6,.8]);axis(ax)
axes[0,0].set(ylabel='Annual AC yield (kWh kWp⁻¹)',ylim=(0,2000));axes[0,0].legend(loc='lower right')
axes[0,1].set(ylabel='Gain relative to α = 0.20 (%)',ylim=(0,35))
label(axes[0,0],'a','Capacity-normalized energy yield');label(axes[0,1],'b','Sensitivity to ground reflectance')
for cid,color,style,name in [('M01',BLUE,'-','Tilted, α = 0.20'),('M03',BLUE,'--','Tilted, α = 0.60'),('B05',ORANGE,'-','Vertical, α = 0.20'),('B07',ORANGE,'--','Vertical, α = 0.60')]:
    g=hourly[cid].groupby(hourly.index.hour).mean()
    axes[1,0].plot(g.index+.5,g,color=color,ls=style,label=name)
axes[1,0].set(xlabel='Local clock time (KST)',ylabel='Mean AC power (kW kWp⁻¹)',xlim=(5,20),ylim=(0,.72),xticks=[6,9,12,15,18]);axis(axes[1,0]);label(axes[1,0],'c','Annual mean hourly generation')
x=np.arange(2);width=.31
for off,cid,color,name in [(-width/2,'M01',BLUE,'Tilted monofacial'),(width/2,'B05',ORANGE,'Vertical bifacial')]:
    vals=b.loc[cid,['morning_fraction','evening_fraction']].astype(float).values*100
    axes[1,1].bar(x+off,vals,width,color=color,label=name)
    for xx,yy in zip(x+off,vals):axes[1,1].text(xx,yy+1,f'{yy:.1f}',ha='center',fontsize=7.5)
axes[1,1].set(xticks=x,xticklabels=['Before 10:00','From 15:00'],ylabel='Share of annual generation (%)',ylim=(0,40));axis(axes[1,1]);label(axes[1,1],'d','Generation share at α = 0.20')
handles,labels=axes[1,0].get_legend_handles_labels();fig.legend(handles,labels,ncols=4,loc='lower center',bbox_to_anchor=(.5,-.015),fontsize=7.5)
save(fig,'fig2_energy_performance')

# Figure 3: both systems swept over matched clear aisles; height audit.
site=pd.read_csv(BASE/'site_10000m2/results.csv');height=pd.read_csv(BASE/'height_comparison.csv')
fig,axes=plt.subplots(1,2,figsize=(9,3.7));fig.subplots_adjust(wspace=.35,bottom=.28)
for fam,col,name in [('tilted',BLUE,'Tilted monofacial'),('vertical',ORANGE,'Vertical bifacial')]:
    for alb,ls in [(.2,'-'),(.6,'--')]:
        q=site[(site.family==fam)&(site['mode']=='equal_clear_gap')&np.isclose(site.albedo,alb)].sort_values('clear_gap_m')
        axes[0].plot(q.clear_gap_m,q.annual_mwh,'o',ls=ls,color=col,label=f'{name}, albedo {alb:.1f}')
    q=height[(height.family==fam)&np.isclose(height.albedo,.2)].sort_values('clearance_m')
    axes[1].plot(q.clearance_m,q.specific_yield_kwh_kwp,'o-',color=col,label=name)
axes[0].set(xlabel='Clear aisle (m)',ylabel='Annual site AC energy (MWh)');axes[0].axvline(2,ls=':',color=GREY)
axes[1].set(xlabel='Lower-edge height (m)',ylabel='Annual clean AC yield (kWh/kWp)',xticks=[.3,.5,.8],ylim=(0,1800))
for ax in axes:axis(ax)
label(axes[0],'a','Matched aisle comparison');label(axes[1],'b','Height sensitivity of infinite-sheds model')
fig.legend(*axes[0].get_legend_handles_labels(),loc='lower center',ncols=2,bbox_to_anchor=(.5,.02))
fig.text(.5,-.035,'Height effect is near numerical resolution here; this is not evidence that installation height never matters.',ha='center',fontsize=8)
save(fig,'fig3_spatial_tradeoff')

# Figure 4 is generated by make_birds_eye.py from the same module polygons.
manifest.append('fig4_birds_eye')
# Figure 5: finite one-hectare layouts with matched clear-gap comparisons.
site=pd.read_csv(ESS.parent/'site_10000m2/results.csv')
cfg=json.loads((ESS.parent/'site_10000m2/config.json').read_text(encoding='utf-8'))
fig,axes=plt.subplots(2,2,figsize=(7.2,6.4))
fig.subplots_adjust(hspace=.73,wspace=.37,bottom=.14)
for ax,family,color,ch,title in [(axes[0,0],'vertical',ORANGE,'a','Vertical: 2 m clear gap'),(axes[0,1],'tilted',BLUE,'b','Tilted: 2 m clear gap')]:
    r=site[(site['mode']=='equal_clear_gap')&(site.family==family)&np.isclose(site.clear_gap_m,2)&np.isclose(site.albedo,.2)].iloc[0]
    ax.add_patch(Rectangle((0,0),100,100,facecolor='#f5f7f8',edgecolor=GREY,lw=.7))
    ax.add_patch(Rectangle((3,3),94,94,fill=False,edgecolor=GREY,lw=.6,linestyle='--'))
    if family=='vertical':ax.add_patch(Rectangle((3,48),94,4,facecolor='#cdd7dc',edgecolor='none'))
    else:ax.add_patch(Rectangle((48,3),4,94,facecolor='#cdd7dc',edgecolor='none'))
    for k in range(int(r.rows)):
        for start in [3.405,52.405]:
            xy=(3+k*r.pitch_m,start) if family=='vertical' else (start,3+k*r.pitch_m)
            width,height=(r.row_strip_m,44.19) if family=='vertical' else (44.19,r.row_strip_m)
            ax.add_patch(Rectangle(xy,width,height,facecolor=color,edgecolor='none'))
    ax.set(xlim=(-1,101),ylim=(-1,101),aspect='equal',xticks=[0,50,100],yticks=[0,50,100],xlabel='East (m)',ylabel='North (m)')
    ax.text(.5,-.38,f'{int(r.modules):,} modules · {r.pv_kwp/1000:.3f} MWp',transform=ax.transAxes,ha='center',fontsize=8,color=color,fontweight='bold')
    label(ax,ch,title)
for family,color,name in [('tilted',BLUE,'Tilted monofacial'),('vertical',ORANGE,'Vertical bifacial')]:
    g=site[(site['mode']=='equal_clear_gap')&(site.family==family)&np.isclose(site.albedo,.2)].sort_values('clear_gap_m')
    axes[1,0].plot(g.clear_gap_m,g.pv_kwp/1000,'o-',color=color,label=name)
    for albedo,style in [(.2,'-'),(.6,'--')]:
        q=site[(site['mode']=='equal_clear_gap')&(site.family==family)&np.isclose(site.albedo,albedo)].sort_values('clear_gap_m')
        axes[1,1].plot(q.clear_gap_m,q.annual_mwh,marker='o',ls=style,color=color,label=f'{name}, α = {albedo:.2f}')
for ax in axes[1,:]:
    ax.set(xlabel='Clear gap between row strips (m)',xticks=[1,2,3,4]);axis(ax);ax.axvline(2,color=GREY,lw=.7,ls=':')
axes[1,0].set(ylabel='Installed capacity (MWp per 1 ha)',ylim=(0,1.6));axes[1,1].set(ylabel='Annual site AC energy (MWh)',ylim=(0,2000))
label(axes[1,0],'c','Capacity density on the whole site');label(axes[1,1],'d','Energy after row-shading effects')
fig.legend(*axes[1,1].get_legend_handles_labels(),ncols=2,loc='lower center',bbox_to_anchor=(.5,-.015),fontsize=7.5)
save(fig,'fig5_one_hectare')

# Figure 6: orientation-constrained comparison; a zero-PV grid baseline is separate.
c10=costs.query('profile=="daytime" and horizon_years==10 and cost_multiplier==1 and tariff=="base_assumed" and recovery_fraction==0 and pv_kwp>0')
targets=[0,.5,.8,.95];orows=[]
for family,cases in [('Tilted monofacial',['M01','M03']),('Vertical bifacial',['B05','B07'])]:
    for target in targets:
        eligible=c10[c10.case_id.isin(cases)&(c10.minimum_annual_user_solar_fraction>=target-1e-10)]
        if len(eligible):
            r=eligible.sort_values(['present_total_cost_krw','ess_nominal_kwh','pv_kwp']).iloc[0].to_dict()
            r.update(family=family,target=target);orows.append(r)
odf=pd.DataFrame(orows)
odf.to_csv(BASE/'data/orientation_costs.csv',index=False,encoding='utf-8-sig')
fig,axes=plt.subplots(2,2,figsize=(7.2,5.7));fig.subplots_adjust(hspace=.63,wspace=.36,bottom=.17)
labels=['No target','≥50%','≥80%','≥95%'];x=np.arange(4)
for family,color,off in [('Tilted monofacial',BLUE,-.17),('Vertical bifacial',ORANGE,.17)]:
    g=odf[odf.family==family].sort_values('target');assert len(g)==4
    for ax,col in [(axes[0,0],'pv_kwp'),(axes[0,1],'ess_nominal_kwh')]:ax.bar(x+off,g[col],.32,color=color,label=family)
    axes[1,0].bar(x+off,-g.npv_saving_vs_grid_krw/1e6,.32,color=color,label=family)
for ax in [axes[0,0],axes[0,1],axes[1,0]]:ax.set(xticks=x,xticklabels=labels,xlabel='Minimum annual solar fraction');axis(ax)
axes[0,0].set(ylabel='Selected PV capacity (kWp)',ylim=(0,85));axes[0,1].set(ylabel='Selected battery energy (kWh)',ylim=(0,60));axes[1,0].set(ylabel='Additional present cost (million KRW)');axes[1,0].axhline(0,color=BLACK,lw=.65)
label(axes[0,0],'a','PV size within each orientation');label(axes[0,1],'b','Battery size within each orientation');label(axes[1,0],'c','Cost relative to grid-only supply')
g=best.query('profile=="daytime" and cost_multiplier==1 and tariff=="base_assumed" and recovery_fraction==0 and selection=="any"')
for target,color,labeltext in [(0,BLACK,'Cost only'),(.5,GREEN,'≥50%'),(.8,ORANGE,'≥80%'),(.95,PURPLE,'≥95%')]:
    k=g[g.minimum_solar_fraction_target==target].sort_values('horizon_years')
    axes[1,1].plot(k.horizon_years,-k.npv_saving_vs_grid_krw/1e6,'o-',color=color,label=labeltext)
axes[1,1].set(xlabel='Land-use period (yr)',ylabel='Additional present cost (million KRW)',xticks=[1,3,5,7,10]);axes[1,1].axhline(0,color=BLACK,lw=.65);axis(axes[1,1]);axes[1,1].legend(fontsize=7,loc='upper right',ncols=2);label(axes[1,1],'d','Unrestricted orientation and grid option')
fig.legend(*axes[0,0].get_legend_handles_labels(),ncols=2,loc='lower center',bbox_to_anchor=(.5,.025))
fig.text(.5,-.01,'a–c: PV > 0 within each orientation; d: grid-only and both orientations included. All cost inputs are assumed.',ha='center',fontsize=7)
save(fig,'fig6_application_costs')

metrics={'vertical_base_yield':float(b.loc['B05','specific_yield_kwh_kwp']),'tilted_base_yield':float(b.loc['M01','specific_yield_kwh_kwp']),'vertical_high_albedo_yield':float(b.loc['B07','specific_yield_kwh_kwp']),'vertical_albedo_gain_pct':float(100*(b.loc['B07','specific_yield_kwh_kwp']/b.loc['B05','specific_yield_kwh_kwp']-1)),'vertical_vs_tilted_pct':float(100*(b.loc['B05','specific_yield_kwh_kwp']/b.loc['M01','specific_yield_kwh_kwp']-1)),'vertical_high_vs_tilted_base_pct':float(100*(b.loc['B07','specific_yield_kwh_kwp']/b.loc['M01','specific_yield_kwh_kwp']-1)),'figure_names':manifest,'orientation_candidates':orows}
(BASE/'figure_metrics.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(metrics,ensure_ascii=False,indent=2))


