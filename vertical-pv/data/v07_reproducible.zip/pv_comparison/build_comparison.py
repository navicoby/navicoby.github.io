"""Current comparison: tilted monofacial and vertical bifacial, same front rating.

Requires sibling site_10000m2 with model.py/config.json/inputs/weather.csv.gz.
Original all-bifacial reproduction remains a separate historical artifact.
"""
from pathlib import Path
import importlib.util,json,hashlib
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('site_model',ROOT.parent/'site_10000m2/model.py')
model=importlib.util.module_from_spec(spec);spec.loader.exec_module(model)

def summary(h,cid,tilt,azimuth,albedo,pitch):
    ac=h.ac_w_per_kwp/1000;sy=ac.sum();front=h.front_w_m2.sum()/1000;rear=h.rear_w_m2.sum()/1000
    return dict(case_id=cid,tilt=tilt,azimuth=azimuth,albedo=albedo,pitch=pitch,clearance=model.C["geometry"]["clearance_m"],
        bifaciality=0 if tilt==30 else .8,module_type='monofacial' if tilt==30 else 'bifacial',
        thermal_irradiance='front only' if tilt==30 else 'front plus rear',slant_length=1.1,along_row=2.2,
        annual_front_poa_kwh_m2=front,annual_rear_poa_kwh_m2=rear,
        annual_effective_poa_kwh_m2=h.effective_w_m2.sum()/1000,
        specific_yield_kwh_kwp=sy,periodic_area_productivity_kwh_m2=sy/(2.21*pitch/.5),
        morning_fraction=ac[ac.index.hour<10].sum()/sy,midday_fraction=ac[(ac.index.hour>=10)&(ac.index.hour<15)].sum()/sy,
        evening_fraction=ac[ac.index.hour>=15].sum()/sy,peak_ac_kw_per_kwp=ac.max(),status='ASSUMED_NOT_FIELD_VALIDATED')

if __name__=='__main__':
    import runpy
    runpy.run_path(str(ROOT.parent/'rebuild_energy.py'),run_name='__main__')
