"""Ten-year controlled extension, retaining dust across year boundaries.

HSU above 10 g/m2 is NOT evaluated. Invalid power/energy is NA, never zero,
clipped, or silently summed over partial intervals. No new GPU run is made.
"""
from pathlib import Path
import hashlib,json,platform
import numpy as np
import pandas as pd
from scipy.special import erf
from power_reference import irradiance,ac_power,dust_series as hourly_reference

ROOT=Path(__file__).resolve().parent

def evolve(hours,deposition,exposure,rainfall,initial,fraction,kl,kb):
    """Exact constant-deposition recurrence between rain events, no time subsampling."""
    state=np.full(2,initial)[:,None]*np.array([1-fraction,fraction])
    incoming=np.array(deposition)[:,None]*np.array([1-fraction,fraction])
    pools=np.empty((hours,2,2));removed=np.zeros(2);start=0
    for stop in np.r_[np.flatnonzero(rainfall),hours]:
        if stop>start:
            pools[start:stop]=state+np.arange(1,stop-start+1)[:,None,None]*incoming
            state=pools[stop-1].copy()
        if stop<hours:
            state+=incoming
            after=state*np.exp(-np.array(exposure)[:,None]*rainfall[stop]*np.array([kl,kb]))
            removed+=(state-after).sum(axis=1);pools[stop]=state=after
        start=stop+1
    residual=initial+np.array(deposition)*hours-pools[-1].sum(axis=1)-removed
    return pools,float(np.max(np.abs(residual)))

def masked_power(front,rear,temp,phi,mass):
    active=[0] if phi==0 else [0,1]
    valid=(mass[:,active]<=10).all(axis=1)
    trans=np.ones_like(mass)
    for face in active:
        in_range=mass[:,face]<=10
        trans[:,face]=np.nan
        trans[in_range,face]=1-.3437*erf(.17*mass[in_range,face]**.8473)
    ac=ac_power(front,rear,temp,phi,trans)
    ac[~valid]=np.nan
    return ac,valid

def strict_sum(a):
    return float(np.sum(a)) # propagates NaN instead of reporting partial energy

def main():
    c=json.loads((ROOT/'config.json').read_text(encoding='utf-8'))
    years=c['simulation_years'];nh=8760*years;nd=365*years
    w=pd.read_csv(ROOT/'inputs/weather.csv.gz',index_col=0,parse_dates=True)
    w.index=pd.to_datetime(w.index,utc=True).tz_convert('Asia/Seoul')
    assert len(w)==8760 and np.all((w.index[1:]-w.index[:-1])==pd.Timedelta(hours=1))
    dry=pd.read_csv(ROOT/'inputs/warp_soiling_results.csv')
    wet=pd.read_csv(ROOT/'inputs/rain_exposure.csv')
    baseline=pd.read_csv(ROOT/'inputs/baseline.csv').set_index('case_id')
    weights=c['wind_weights'];summaries=[];daily=[];monthly=[];annual=[];checkpoints=[]
    max_balance=0;first_year_error=0;domain_times={};massmax=0
    month_lengths=np.array([31,28,31,30,31,30,31,31,30,31,30,31])
    month_ends=np.cumsum(np.tile(month_lengths,years))*24
    # Verify optimized recurrence against the independent hourly recurrence.
    test_rain=np.zeros(1001);test_rain[[0,1,137,999]]=10
    p,err=evolve(1001,[.001,.002],[.86,.15],test_rain,.1,.7,.25,.015)
    ref,_,_=hourly_reference(1001,[.001,.002],[.86,.15],test_rain,.1,.7,.25,.015)
    assert np.allclose(p,ref,atol=1e-11) and err<1e-10
    for family,case in c['cases'].items():
        dep=[];exp=[]
        for face in ['front','rear']:
            d=dry[dry.family.eq(family)].groupby('wind')[face+'_g_m2'].mean()
            r=wet[wet.family.eq(family)&wet.face.eq(face)].groupby('wind').surface_rain_mm_per_horizontal_mm.mean()
            dep.append(sum(d[k]*v for k,v in weights.items())*c['concentration_ug_m3']/100)
            exp.append(sum(r[k]*v for k,v in weights.items()))
        front,rear,temp=[np.tile(a,years) for a in irradiance(w,case,c['albedo'])]
        clean=ac_power(front,rear,temp,case['bifaciality'],np.ones((nh,2)))
        assert np.allclose(clean[:8760],clean[-8760:])
        assert abs(clean[:8760].sum()-baseline.loc[case['baseline_case'],'specific_yield_kwh_kwp'])<1e-7
        for mode in ['no_rain','periodic_rain']:
            rain=np.zeros(nh)
            if mode=='periodic_rain':rain[np.arange(c['rain_interval_days']-1,nd,c['rain_interval_days'])*24]=c['rain_event_mm']
            for dm in c['deposition_multipliers']:
                for km in c['wash_multipliers']:
                    pools,balance=evolve(nh,np.array(dep)*dm,exp,rain,c['initial_dust_g_m2_per_face'],c['bound_fraction'],c['loose_washoff_per_mm']*km,c['bound_washoff_per_mm']*km)
                    mass=pools.sum(axis=2);ac,valid=masked_power(front,rear,temp,case['bifaciality'],mass)
                    max_balance=max(max_balance,balance);massmax=max(massmax,float(mass.max()))
                    assert balance<1e-9 and mass.min()>=0
                    assert np.all(ac[valid]>=0) and np.all(ac[valid]<=clean[valid]+1e-12)
                    assert np.isnan(ac[~valid]).all()
                    if mode=='no_rain':assert np.all(np.diff(mass,axis=0)>=-1e-10)
                    bad=np.flatnonzero(~valid);first_bad=float((bad[0]+1)/8760) if len(bad) else None
                    row=dict(family=family,module_type=case['module_type'],rain_mode=mode,deposition_multiplier=dm,wash_multiplier=km,
                        first_out_of_domain_year=first_bad,final_front_g_m2=float(mass[-1,0]),final_rear_g_m2=float(mass[-1,1]),
                        ten_year_clean_kwh_kwp=strict_sum(clean),ten_year_soiled_kwh_kwp=strict_sum(ac),
                        ten_year_loss_percent=float(100*np.sum(clean-ac)/clean.sum()),all_hours_within_optical_mass_domain=bool(valid.all()))
                    summaries.append(row)
                    if dm!=1 or km!=1:continue
                    key=family+'_'+mode;domain_times[key]=first_bad
                    ref,_,_=hourly_reference(8760,np.array(dep)*dm,exp,rain[:8760],c['initial_dust_g_m2_per_face'],c['bound_fraction'],c['loose_washoff_per_mm']*km,c['bound_washoff_per_mm']*km)
                    ref_ac,_=masked_power(front[:8760],rear[:8760],temp[:8760],case['bifaciality'],ref.sum(axis=2))
                    first_year_error=max(first_year_error,abs(ac[:8760].sum()-ref_ac.sum()))
                    assert first_year_error<1e-7
                    loss=clean-ac;cumulative=np.cumsum(loss)
                    energy=ac.reshape(-1,24).sum(axis=1);reference=clean.reshape(-1,24).sum(axis=1)
                    d=pd.DataFrame(dict(family=family,rain_mode=mode,day=np.arange(1,nd+1),elapsed_years=np.arange(1,nd+1)/365,
                        clean_ac_kwh_kwp=reference,soiled_ac_kwh_kwp=energy,retained_generation_percent=energy/reference*100,
                        cumulative_loss_kwh_kwp=cumulative[23::24],front_g_m2=mass[23::24,0],rear_g_m2=mass[23::24,1],
                        optical_domain_valid_day=valid.reshape(-1,24).all(axis=1),rain_mm=rain.reshape(-1,24).sum(axis=1)))
                    daily.append(d)
                    start=0
                    for mi,stop in enumerate(month_ends):
                        monthly.append(dict(family=family,rain_mode=mode,month_index=mi+1,year=mi//12+1,tmy_month=mi%12+1,
                            elapsed_years=(mi+1)/12,clean_ac_kwh_kwp=strict_sum(clean[start:stop]),soiled_ac_kwh_kwp=strict_sum(ac[start:stop]),
                            retained_generation_percent=float(100*np.sum(ac[start:stop])/clean[start:stop].sum()),
                            cumulative_loss_kwh_kwp=float(cumulative[stop-1]),optical_domain_valid=bool(valid[start:stop].all())))
                        start=stop
                    for yr in range(1,years+1):
                        sl=slice((yr-1)*8760,yr*8760)
                        annual.append(dict(family=family,rain_mode=mode,year=yr,clean_kwh_kwp=strict_sum(clean[sl]),soiled_kwh_kwp=strict_sum(ac[sl]),
                            annual_loss_percent=float(100*np.sum(loss[sl])/clean[sl].sum()),optical_domain_valid=bool(valid[sl].all())))
                    for yr in c['checkpoints_years']:
                        end=yr*8760
                        checkpoints.append(dict(family=family,rain_mode=mode,years=yr,clean_cumulative_kwh_kwp=strict_sum(clean[:end]),
                            soiled_cumulative_kwh_kwp=strict_sum(ac[:end]),cumulative_loss_kwh_kwp=strict_sum(loss[:end]),
                            cumulative_loss_percent=float(100*np.sum(loss[:end])/clean[:end].sum()),
                            optical_domain_valid=bool(valid[:end].all()),first_out_of_domain_year=first_bad))
    assert first_year_error<1e-7
    # A non-generating rear surface never blocks monofacial electricity evaluation.
    test_mass=np.column_stack([np.zeros(nh),np.full(nh,100.)])
    pwr,v=masked_power(front,rear,temp,0,test_mass)
    assert v.all() and np.isfinite(pwr).all()
    test_mass[:,0]=10.001;pwr,v=masked_power(front,rear,temp,0,test_mass)
    assert not v.any() and np.isnan(pwr).all()
    for name,frame in [('daily',pd.concat(daily,ignore_index=True)),('monthly',pd.DataFrame(monthly)),('annual',pd.DataFrame(annual)),('checkpoints',pd.DataFrame(checkpoints)),('sensitivity',pd.DataFrame(summaries))]:
        frame.to_csv(ROOT/f'{name}.csv',index=False,encoding='utf-8-sig',na_rep='NA')
    audit=dict(status='PASS',years=years,hourly_steps_per_case=nh,scenarios=len(summaries),field_validated=False,
        first_year_independent_recurrence_max_abs_kwh_kwp=first_year_error,mass_balance_max_abs_g_m2=max_balance,
        hourly_recurrence_crosscheck=True,year_boundary_mass_not_reset=True,identical_tmy_repeated=True,module_aging_included=False,
        out_of_domain_power_is_NA=True,partial_energy_totals_not_reported=True,monofacial_rear_does_not_block_power=True,
        central_first_out_of_domain_year=domain_times,maximum_scenario_mass_g_m2=massmax,
        python_version=platform.python_version(),input_sha256={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((ROOT/'inputs').glob('*'))})
    (ROOT/'validation.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    print(pd.DataFrame(checkpoints).to_string(index=False));print(json.dumps(audit,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
