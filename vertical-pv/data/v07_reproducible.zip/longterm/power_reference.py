"""Illustrative no-manual-cleaning scenarios; not a site forecast.

Reuses published Warp face-mean interception and rain exposure outputs.
This script does NOT run Warp. An hourly, spatially uniform two-pool model
preserves residual bound dust across rain events. See README.md for scope.
"""
from pathlib import Path
import hashlib
import json
import math
import platform
import sys

import numpy as np
import pandas as pd
import pvlib
from scipy.special import erf

ROOT = Path(__file__).resolve().parent


def transmission(mass_g_m2):
    """HSU empirical mass/transmission relation ONLY, not its deposition model."""
    mass = np.asarray(mass_g_m2, dtype=float)
    if np.any(mass < -1e-12) or np.any(mass > 10):
        raise ValueError('Outside adopted 0–10 g/m2 HSU mass domain')
    return 1 - .3437 * erf(.17 * np.maximum(mass, 0)**.8473)


def dust_series(hours, deposition_g_m2_h, exposure, rainfall, initial, bound, kl, kb):
    """Two faces x two persistent pools; input rain is horizontal mm per hour.

    Deposit, remove rain-exposed fractions, then use the hourly end state.
    Uniform dust per family/face; no module-to-module variability or remobilization.
    """
    state = np.full(2, initial)[:, None] * np.array([1-bound, bound])[None, :]
    incoming = np.asarray(deposition_g_m2_h)[:, None] * np.array([1-bound, bound])[None, :]
    pools = np.empty((hours, 2, 2))
    removed = np.zeros(2)
    for t in range(hours):
        state += incoming
        after = state * np.exp(-np.asarray(exposure)[:, None] * rainfall[t] * np.array([kl, kb])[None, :])
        removed += (state-after).sum(axis=1)
        pools[t] = state = after
    residual = initial + np.asarray(deposition_g_m2_h)*hours - pools[-1].sum(axis=1) - removed
    return pools, removed, float(np.max(np.abs(residual)))


def irradiance(weather, case, albedo):
    tilt, azimuth, pitch = case['tilt_deg'], case['azimuth_deg'], case['pitch_m']
    ir = pvlib.bifacial.infinite_sheds.get_irradiance(
        tilt, azimuth, weather.solar_zenith, weather.solar_azimuth, 1.1/pitch,
        case['clearance_m'] + .55*np.sin(np.radians(tilt)), pitch, weather.ghi, weather.dhi,
        weather.dni, albedo, model='haydavies',
        dni_extra=pvlib.irradiance.get_extra_radiation(weather.index),
        bifaciality=case['bifaciality'], shade_factor=0, transmission_factor=0,
        npoints=100, vectorize=True).clip(lower=0)
    ir.loc[weather.solar_zenith >= 90, :] = 0
    thermal = ir.poa_front if case['bifaciality'] == 0 else ir.poa_front+ir.poa_back
    temp = pvlib.temperature.faiman(thermal, weather.temp_air,
                                   weather.wind_speed, u0=25, u1=6.84)
    return ir.poa_front.to_numpy(), ir.poa_back.to_numpy(), temp.to_numpy()


def ac_power(front, rear, temp, bifaciality, trans):
    effective = front*trans[:, 0] + bifaciality*rear*trans[:, 1]
    dc = np.maximum(pvlib.pvsystem.pvwatts_dc(effective, temp, pdc0=1000, gamma_pdc=-.0035), 0)*.92
    return pvlib.inverter.pvwatts(dc, pdc0=1000/1.2/.96, eta_inv_nom=.96)/1000

