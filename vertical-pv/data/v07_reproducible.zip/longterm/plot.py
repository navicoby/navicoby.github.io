from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'Malgun Gothic','font.size':11,'axes.unicode_minus':False,
 'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'path','pdf.fonttype':42,
 'text.color':'#233746','axes.labelcolor':'#233746','xtick.color':'#445360','ytick.color':'#445360'})
C={'tilted':'#14678b','vertical':'#d56a22'};N={'tilted':'경사형 단면','vertical':'수직형 양면'};L={'periodic_rain':'-','no_rain':'--'}
D=pd.read_csv(ROOT/'daily.csv');M=pd.read_csv(ROOT/'monthly.csv');A=pd.read_csv(ROOT/'annual.csv')
def setup(title,subtitle):
 fig,axes=plt.subplots(2,1,figsize=(10.6,8.8),sharex=True)
 fig.subplots_adjust(left=.11,right=.96,top=.80,bottom=.14,hspace=.36)
 fig.suptitle(title,x=.075,y=.975,ha='left',fontsize=18,fontweight='bold')
 fig.text(.075,.925,subtitle,fontsize=10.5,color='#536573')
 handles=[Line2D([0],[0],color=C[f],lw=2.4,label=N[f]) for f in C]
 handles += [Line2D([0],[0],color='#536573',ls=L[r],lw=2,label=t) for r,t in [('periodic_rain','14일마다 비 10 mm'),('no_rain','비 없음')]]
 fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(.069,.90),ncol=4,frameon=False,columnspacing=1.1)
 for ax in axes:
  ax.set_xlim(0,10);ax.set_xticks([0,1,2,3,4,5,6,7,8,9,10]);ax.grid(axis='y',color='#e1e7eb',lw=.7);ax.set_axisbelow(True)
  ax.axvline(5,color='#bac4cb',lw=.8,ls=':');ax.axvline(10,color='#bac4cb',lw=.8,ls=':')
 axes[1].set_xlabel('운영 기간 (년 · 1년 = 365일)')
 return fig,axes
def save(fig,name):
 for ext in ['png','svg','pdf']:fig.savefig(OUT/f'{name}.{ext}',dpi=180,facecolor='white')
 plt.close(fig)
fig,axs=setup('청소하지 않는 10년: 잔류 먼지와 발전량 변화','서울 대표 기상년 반복 · 기기 경년열화 제외 · 실측이 아닌 가정 시나리오')
for f in C:
 for r in L:
  m=M[(M.family==f)&(M.rain_mode==r)];d=D[(D.family==f)&(D.rain_mode==r)]
  axs[0].plot(m.elapsed_years,m.retained_generation_percent,color=C[f],ls=L[r],lw=1.9)
  mass=d.front_g_m2 if f=='tilted' else np.maximum(d.front_g_m2,d.rear_g_m2)
  axs[1].plot(d.elapsed_years,mass,color=C[f],ls=L[r],lw=1.8)
  if r=='no_rain':
   last=m.dropna(subset=['retained_generation_percent']).iloc[-1]
   axs[0].plot(last.elapsed_years,last.retained_generation_percent,'o',mfc='white',mec=C[f],ms=6)
axs[0].set_title('a  청결 기준 대비 월 발전량 유지율',loc='left',fontsize=12,fontweight='bold',pad=12)
axs[0].set_ylabel('월 발전량 유지율 (%)');axs[0].set_ylim(60,102)
axs[0].text(5.1,70,'무강우 곡선은 적용 범위 초과로 종료\n경사형 약 2.12년 · 수직형 약 2.59년',fontsize=10,color='#536573',va='top')
axs[1].set_title('b  발전하는 표면에 쌓인 먼지량',loc='left',fontsize=12,fontweight='bold',pad=12)
axs[1].set_ylabel('먼지 질량 (g/m²)');axs[1].set_ylim(0,50)
axs[1].axhspan(10,50,color='#edf0f2',alpha=.65,zorder=0);axs[1].axhline(10,color='#64737f',lw=1,ls=':')
axs[1].text(.2,45,'10 g/m² 초과: 광투과율 관계식의 적용 범위 밖',fontsize=10,color='#536573')
fig.text(.075,.063,'수직형 먼지량은 앞·뒷면 중 큰 값. 질량 계산은 계속하지만 범위 밖의 발전량은 외삽하지 않습니다.',fontsize=9.5,color='#536573')
fig.text(.075,.03,'초기 0.1 g/m²/면 · 가상 농도 10 μg/m³ · 강부착분 70% · 하단 0.3 m · 통로 2 m · 인위적 청소 0회',fontsize=9.5,color='#536573')
save(fig,'figS3_no_cleaning_10years')
fig,axs=setup('5년과 10년의 발전량·누적 손실','동일 1 kWp 기준 · 같은 기상년을 10회 반복 · 먼지의 누적 상태는 연말에도 유지')
for f in C:
 ref=A[(A.family==f)&(A.rain_mode=='periodic_rain')]
 axs[0].plot(ref.year,ref.clean_kwh_kwp,color=C[f],ls=':',lw=1,alpha=.6)
 for r in L:
  a=A[(A.family==f)&(A.rain_mode==r)];m=M[(M.family==f)&(M.rain_mode==r)]
  axs[0].plot(a.year,a.soiled_kwh_kwp,color=C[f],ls=L[r],lw=1.9,marker='o',ms=3)
  axs[1].plot(m.elapsed_years,m.cumulative_loss_kwh_kwp,color=C[f],ls=L[r],lw=1.9)
axs[0].set_title('a  해당 운영 연도의 발전량 (옅은 점선: 청결 기준)',loc='left',fontsize=12,fontweight='bold',pad=12)
axs[0].set_ylabel('연간 발전량 (kWh/kWp·년)');axs[0].set_ylim(0,1700)
axs[1].set_title('b  운전 시작 이후의 누적 발전 손실',loc='left',fontsize=12,fontweight='bold',pad=12)
axs[1].set_ylabel('누적 손실 (kWh/kWp)');axs[1].set_ylim(bottom=0)
fig.text(.075,.063,'빈 구간은 손실 0을 뜻하지 않습니다. 적용 범위를 넘긴 시간이 포함된 연간·누적 발전량은 NA입니다.',fontsize=9.5,color='#536573')
fig.text(.075,.03,'14일마다 비가 오는 가정에서는 잔류 먼지가 이어집니다. 10년 실측 성능이나 제품 수명 예측은 아닙니다.',fontsize=9.5,color='#536573')
save(fig,'figS4_no_cleaning_10year_energy')
print('Saved long-term figures.')
