from pathlib import Path
import importlib.util,json,shutil
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
# Prepare output folders in a fresh extracted archive.
for folder in ['pv_comparison/hourly','pv_ess_screening/inputs','longterm/inputs']:(ROOT/folder).mkdir(parents=True,exist_ok=True)
spec=importlib.util.spec_from_file_location('site_model',ROOT/'site_10000m2/model.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
spec=importlib.util.spec_from_file_location('comparison',ROOT/'pv_comparison/build_comparison.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
study=json.loads((ROOT/'study.json').read_text());rows=[];hourly={}
for tilt,az,fam,start,prefix in [(30,180,'tilted',1,'M'),(90,90,'vertical',5,'B')]:
    pitch=m.layout(tilt,2)['row_strip_m']+study['clear_gap_m']
    for j,alb in enumerate(study['albedos']):
        cid=f'{prefix}{start+j:02d}';h=m.power(tilt,az,alb,pitch,True)
        row=c.summary(h,cid,tilt,az,alb,pitch);row['clearance']=study['clearance_m'];row['clear_gap_m']=study['clear_gap_m'];row['revision']='v0.7';rows.append(row)
        hourly[cid]=h.ac_w_per_kwp/1000;h.to_csv(ROOT/f'pv_comparison/hourly/{cid}.csv.gz',compression='gzip')
b=pd.DataFrame(rows);b.to_csv(ROOT/'pv_comparison/baseline.csv',index=False,encoding='utf-8-sig')
hf=pd.DataFrame(hourly);hf.to_csv(ROOT/'pv_comparison/hourly_kw_per_kwp.csv.gz',compression='gzip');hf.to_csv(ROOT/'pv_ess_screening/inputs/pv_hourly.csv.gz',compression='gzip')
print(b[['case_id','pitch','clearance','specific_yield_kwh_kwp']].to_string(index=False),flush=True)
site=[];height=[]
for tilt,az,fam in [(30,180,'tilted'),(90,90,'vertical')]:
    strip=m.layout(tilt,2)['row_strip_m']
    for alb in [.2,.6]:
        for mode,pitch in [('equal_pitch',x) for x in m.C['row_pitch_m']]+[('equal_clear_gap',strip+x) for x in m.C['clear_gap_m']]:
            ac=m.power(tilt,az,alb,pitch);d=m.layout(tilt,pitch)
            site.append(dict(scenario_id=f'{fam}_{mode}_a{alb}_p{pitch:.6f}',mode=mode,family=fam,tilt=tilt,module_type=m.C['module_types'][fam]['type'],bifaciality=m.C['module_types'][fam]['bifaciality'],albedo=alb,pitch_m=pitch,clearance_m=.3,**d,specific_yield_kwh_kwp=float(ac.sum()),annual_mwh=float(ac.sum()*d['pv_kwp']/1000),site_yield_kwh_m2=float(ac.sum()*d['kwp_per_m2'])))
        for h in study['height_candidates_m']:
            m.C['geometry']['clearance_m']=h;pitch=strip+2;ac=m.power(tilt,az,alb,pitch);d=m.layout(tilt,pitch)
            height.append(dict(family=fam,clearance_m=h,albedo=alb,pitch_m=pitch,clear_gap_m=2,modules=d['modules'],pv_kwp=d['pv_kwp'],specific_yield_kwh_kwp=float(ac.sum()),annual_mwh=float(ac.sum()*d['pv_kwp']/1000)))
        m.C['geometry']['clearance_m']=.3
    print('Completed layout and heights:',fam,flush=True)
s=pd.DataFrame(site);s.to_csv(ROOT/'site_10000m2/results.csv',index=False,encoding='utf-8-sig');pd.DataFrame(height).to_csv(ROOT/'height_comparison.csv',index=False,encoding='utf-8-sig')
assert len(s)==52 and np.allclose(s.annual_mwh*1000/10000,s.site_yield_kwh_m2)
for _,r in b[b.albedo.isin([.2,.6])].iterrows():
    match=s[(s.family==('tilted' if r.tilt==30 else 'vertical'))&(s['mode']=='equal_clear_gap')&np.isclose(s.clear_gap_m,2)&np.isclose(s.albedo,r.albedo)].iloc[0]
    assert abs(r.specific_yield_kwh_kwp-match.specific_yield_kwh_kwp)<1e-7
(ROOT/'site_10000m2/validation.json').write_text(json.dumps(dict(status='PASS',scenarios=52,height_scenarios=len(height),geometry_bounds='PASS',area_energy_identity='PASS',baseline_clear_gap_2m_consistency='PASS',site_conditions=study,field_validated=False),indent=2))
shutil.copy2(ROOT/'pv_comparison/baseline.csv',ROOT/'longterm/inputs/baseline.csv')
print('ENERGY PASS',flush=True)
