"""Same dispatch bookkeeping as model.dispatch, with only the hourly loop compiled."""
import math
import numpy as np
from numba import njit

@njit(cache=True)
def loop(pv,load,usable,pcs,eta,aux,initial):
    s=min(initial,usable);totals=np.zeros(9);out=np.empty((len(pv),10))
    residual=0.;ddc=0.;lo=s;hi=s
    for i in range(len(pv)):
        old=s;du=min(pv[i],load[i]);remaining=pv[i]-du
        da=min(remaining,aux);remaining-=da;fu=load[i]-du;fa=aux-da
        ch=min(remaining,pcs,max(0.,usable-s)/eta);s+=ch*eta
        dis=min(fu+fa,pcs,s*eta);s=max(0.,min(usable,s-dis/eta))
        bu=min(dis,fu);ba=dis-bu;gu=fu-bu;ga=fa-ba;ex=max(0.,remaining-ch)
        loss=ch*(1-eta)+dis*(1/eta-1)
        vals=(du,da,ch,bu,ba,gu,ga,ex,loss)
        for j in range(9):totals[j]+=vals[j];out[i,j]=vals[j]
        out[i,9]=s
        residual=max(residual,abs(pv[i]+gu+ga-load[i]-aux-ex-loss-(s-old)))
        ddc+=dis/eta;lo=min(lo,s);hi=max(hi,s)
    return totals,out,s,residual,ddc,lo,hi

def dispatch(pv,user_load,nominal_kwh,pcs_kw,battery,soh=1.,initial=0.,traces=False):
    pv=np.asarray(pv,dtype=float);load=np.asarray(user_load,dtype=float)
    if pv.shape!=load.shape or pv.ndim!=1 or not np.isfinite(pv).all() or not np.isfinite(load).all() or (pv<0).any() or (load<0).any():raise ValueError('Invalid input')
    if min(nominal_kwh,pcs_kw,initial)<0 or (nominal_kwh==0)!=(pcs_kw==0):raise ValueError('Invalid capacity')
    eta=math.sqrt(battery['roundtrip_efficiency']);usable=nominal_kwh*soh*(battery['maximum_soc_fraction']-battery['minimum_soc_fraction']);aux=pcs_kw*battery['auxiliary_kw_per_pcs_kw']
    if not 0<eta<=1 or not 0<=usable<=nominal_kwh:raise ValueError('Invalid efficiency or SOC')
    total,out,s,res,ddc,lo,hi=loop(pv,load,usable,pcs_kw,eta,aux,initial)
    assert res<1e-8 and lo>=-1e-8 and hi<=usable+1e-8
    names=['direct_user_kwh','direct_aux_kwh','charge_ac_kwh','discharge_user_kwh','discharge_aux_kwh','grid_user_kwh','grid_aux_kwh','export_kwh','conversion_loss_kwh']
    r=dict(zip(names,map(float,total)))
    r.update(pv_generation_kwh=float(pv.sum()),user_load_kwh=float(load.sum()),aux_load_kwh=aux*len(pv),end_usable_soc_kwh=s,initial_capacity_spill_kwh=initial-min(initial,usable),max_balance_residual_kwh=res,min_usable_soc_kwh=lo,max_usable_soc_kwh=hi,available_usable_kwh=usable,equivalent_full_cycles=ddc/nominal_kwh if nominal_kwh else 0.)
    r['user_solar_fraction']=(r['direct_user_kwh']+r['discharge_user_kwh'])/r['user_load_kwh'] if r['user_load_kwh'] else 0.
    return r,out if traces else None

if __name__=='__main__':
    from model import dispatch as reference
    from pathlib import Path
    import json
    b=json.loads((Path(__file__).parent/'config.json').read_text())['battery'];rng=np.random.default_rng(1729);err=0.
    for energy in [0,25,100]:
        for soh in [.3,1.]:
            for initial in [0,energy*.8]:
                pv=rng.random(2000)*40;load=rng.random(2000)*20;pcs=energy/4
                a,ta=reference(pv,load,energy,pcs,b,soh,initial,True);z,tz=dispatch(pv,load,energy,pcs,b,soh,initial,True)
                err=max(err,max(abs(a[k]-z[k]) for k in a),float(np.max(np.abs(ta-tz))))
                assert all(np.isclose(a[k],z[k],rtol=1e-12,atol=1e-9) for k in a) and np.allclose(ta,tz,rtol=1e-12,atol=1e-9)
    (Path(__file__).parent/'fast_dispatch_validation.json').write_text(json.dumps({'status':'PASS','independent_reference_cases':12,'hours_each':2000,'max_abs_difference':err}))
    print('Dispatch equivalence PASS',err)
