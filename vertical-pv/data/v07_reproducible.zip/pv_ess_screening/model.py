"""Transparent AC-coupled PV/ESS screening, not an optimal dispatch solver."""
from pathlib import Path
import math, json, hashlib, time
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent

def dispatch(pv, user_load, nominal_kwh, pcs_kw, battery, soh=1.0, initial=0.0, traces=False):
    """1-hour energy balance. Stored energy is above the minimum SOC reserve.

    Starts with no free usable energy. Residual energy carries to the next year.
    Power limits are at the AC bus; E is nominal DC battery energy.
    """
    pv=np.asarray(pv,dtype=float);load=np.asarray(user_load,dtype=float)
    if pv.shape!=load.shape or pv.ndim!=1:raise ValueError('1-D matching inputs required')
    if not np.isfinite(pv).all() or not np.isfinite(load).all() or (pv<0).any() or (load<0).any():raise ValueError('Invalid energy inputs')
    if min(nominal_kwh,pcs_kw,initial)<0:raise ValueError('Negative battery parameter')
    if (nominal_kwh==0)!=(pcs_kw==0):raise ValueError('Both battery energy and power must be zero or positive')
    eta=math.sqrt(battery['roundtrip_efficiency'])
    usable=nominal_kwh*soh*(battery['maximum_soc_fraction']-battery['minimum_soc_fraction'])
    if not 0<eta<=1 or not 0<=usable<=nominal_kwh:raise ValueError('Invalid efficiency or SOC')
    s=min(initial,usable);initial_spill=initial-s
    aux=pcs_kw*battery['auxiliary_kw_per_pcs_kw']
    # Per-hour columns: direct user, direct aux, charge AC, discharge user AC,
    # discharge aux AC, grid user, grid aux, export, conversion loss, SOC.
    totals=np.zeros(9);out=np.empty((len(pv),10)) if traces else None
    max_residual=0.;discharge_dc=0.;min_soc=s;max_soc=s
    for i in range(len(pv)):
        old=s;direct_user=min(pv[i],load[i]);remaining=pv[i]-direct_user
        direct_aux=min(remaining,aux);remaining-=direct_aux
        deficit_user=load[i]-direct_user;deficit_aux=aux-direct_aux
        charge=min(remaining,pcs_kw,max(0.,usable-s)/eta)
        s+=charge*eta
        discharge=min(deficit_user+deficit_aux,pcs_kw,s*eta)
        s=max(0.,min(usable,s-discharge/eta)) # Remove sub-ulp drift after an empty/full event.
        discharge_user=min(discharge,deficit_user);discharge_aux=discharge-discharge_user
        grid_user=deficit_user-discharge_user;grid_aux=deficit_aux-discharge_aux
        export=max(0.,remaining-charge)
        loss=charge*(1-eta)+discharge*(1/eta-1)
        vals=(direct_user,direct_aux,charge,discharge_user,discharge_aux,grid_user,grid_aux,export,loss)
        totals+=vals
        balance=pv[i]+grid_user+grid_aux-load[i]-aux-export-loss-(s-old)
        max_residual=max(max_residual,abs(balance))
        discharge_dc+=discharge/eta
        min_soc=min(min_soc,s);max_soc=max(max_soc,s)
        if traces:out[i]=(*vals,s)
    if max_residual>1e-8 or min_soc< -1e-8 or max_soc>usable+1e-8:raise AssertionError('Energy/SOC balance failure')
    names=['direct_user_kwh','direct_aux_kwh','charge_ac_kwh','discharge_user_kwh','discharge_aux_kwh','grid_user_kwh','grid_aux_kwh','export_kwh','conversion_loss_kwh']
    result=dict(zip(names,map(float,totals)))
    result.update(pv_generation_kwh=float(pv.sum()),user_load_kwh=float(load.sum()),aux_load_kwh=aux*len(pv),end_usable_soc_kwh=s,initial_capacity_spill_kwh=initial_spill,max_balance_residual_kwh=max_residual,min_usable_soc_kwh=min_soc,max_usable_soc_kwh=max_soc,available_usable_kwh=usable,equivalent_full_cycles=discharge_dc/nominal_kwh if nominal_kwh else 0.)
    result['user_solar_fraction']=(result['direct_user_kwh']+result['discharge_user_kwh'])/result['user_load_kwh'] if result['user_load_kwh'] else 0.
    return result,out

def load_profiles(index,daily_average):
    h=index.hour.to_numpy()
    weights={'daytime':np.where((h>=8)&(h<18),1.,.1),'flat':np.ones(len(h)),'evening':np.where((h>=17)&(h<23),1.,.1)}
    return {k:v/v.sum()*365*daily_average for k,v in weights.items()}

def import_inputs(config):
    local=ROOT/'inputs';local.mkdir(exist_ok=True)
    saved=local/'pv_hourly.csv.gz'
    if saved.exists():
        frame=pd.read_csv(saved,index_col=0,parse_dates=True)
        frame.index=pd.to_datetime(frame.index,utc=True).tz_convert('Asia/Seoul')
        return frame
    raise FileNotFoundError('Preserve inputs/pv_hourly.csv.gz from the v0.5 comparison package.')


def run_physics(config,frame):
    profiles=load_profiles(frame.index,config['load']['daily_average_kwh'])
    rows=[];begin=time.monotonic();count=0
    battery=config['battery']
    from fast_dispatch import dispatch as fast_dispatch
    for profile in config['load']['profiles']:
        load=profiles[profile]
        for cid in config['pv_cases']:
            unit=frame[cid].to_numpy()
            for pv_kwp in config['pv_kwp_candidates']:
                if pv_kwp==0 and cid!=config['pv_cases'][0]:continue
                for energy in config['ess_nominal_kwh_candidates']:
                    if pv_kwp==0 and energy>0:continue # PV-only charging, so zero-PV ESS is dominated.
                    for duration in ([0] if energy==0 else config['ess_duration_hours_candidates']):
                        power=energy/duration if duration else 0.
                        ident=f'{profile}_{cid}_pv{pv_kwp}_e{energy}_p{power:g}'
                        soc=0.;soh=1.;last_replacement=0
                        for year in range(1,config['years']+1):
                            replacement=energy>0 and soh<battery['replacement_soh_threshold']
                            replacement_spill=soc if replacement else 0.
                            if replacement:soh=1.;soc=0.;last_replacement=year-1
                            pv=unit*pv_kwp*(1-config['pv_degradation_per_year'])**(year-1)
                            r,_=fast_dispatch(pv,load,energy,power,battery,soh,soc)
                            soc=r['end_usable_soc_kwh']
                            rows.append(dict(design_id=ident,profile=profile,case_id=cid,pv_kwp=pv_kwp,ess_nominal_kwh=energy,ess_pcs_kw=power,year=year,soh_start=soh,replacement=bool(replacement),replacement_spill_kwh=replacement_spill,last_replacement_year_start=last_replacement,**r))
                            if energy:soh=max(.1,soh-battery['calendar_capacity_loss_per_year']-battery['cycle_capacity_loss_per_equivalent_full_cycle']*r['equivalent_full_cycles'])
                        count+=1
        print(f'Physics {profile}: {count} designs in {time.monotonic()-begin:.1f}s',flush=True)
    return pd.DataFrame(rows)

def cost_results(config,physics):
    c=config['cost'];r=c['discount_rate'];results=[]
    for ident,g in physics.groupby('design_id',sort=False):
        first=g.iloc[0];pv=float(first.pv_kwp);energy=float(first.ess_nominal_kwh);power=float(first.ess_pcs_kw)
        tilt=30 if first.case_id in ['M01','M03'] else 90
        coated=first.case_id in ['M03','B07']
        pv_variable=pv*c['pv_krw_kwp'][str(tilt)];pv_fixed=c['pv_project_fixed_krw'] if pv else 0
        ground=pv*config['area'].get('periodic_pv_m2_per_kwp_by_case',{}).get(first.case_id,config['area']['periodic_pv_m2_per_kwp'])*c['ground_treatment_krw_m2'] if coated else 0
        ess_variable=energy*c['ess_energy_krw_nominal_kwh']+power*c['ess_pcs_krw_kw']
        ess_fixed=c['ess_project_fixed_krw'] if energy else 0
        annual_om=(pv_variable+pv_fixed)*c['pv_annual_om_fraction']+ground*c['ground_treatment_annual_om_fraction']+(ess_variable+ess_fixed)*c['ess_annual_om_fraction']
        for costmult in c['cost_multipliers']:
            capex=(pv_variable+pv_fixed+ground+ess_variable+ess_fixed)*costmult
            for tariff in config['tariff_scenarios']:
                buy=tariff['import_krw_kwh'];sell=tariff['export_krw_kwh']
                discounted_operating=0.;discounted_baseline=0.;discounted_self=0.;discounted_load=0.
                cumulative_user_solar=0.;cumulative_load=0.;cumulative_battery_user=0.;minimum_fraction=1.
                for _,a in g.iterrows():
                    y=int(a.year);df=(1+r)**y
                    replacement_cost=(energy*c['ess_energy_krw_nominal_kwh']*c['ess_replacement_energy_cost_fraction']+c['ess_replacement_fixed_krw'])*costmult if a.replacement else 0
                    operating=(a.grid_user_kwh+a.grid_aux_kwh)*buy-a.export_kwh*sell+annual_om*costmult
                    # Replacement is paid at start of its operating year.
                    discounted_operating+=operating/df+replacement_cost/(1+r)**(y-1)
                    discounted_baseline+=a.user_load_kwh*buy/df
                    supplied=a.direct_user_kwh+a.discharge_user_kwh
                    discounted_self+=supplied/df;discounted_load+=a.user_load_kwh/df
                    cumulative_user_solar+=supplied;cumulative_load+=a.user_load_kwh;cumulative_battery_user+=a.discharge_user_kwh
                    minimum_fraction=min(minimum_fraction,a.user_solar_fraction)
                    decom=(pv*c['pv_decommission_krw_kwp']+energy*c['ess_decommission_krw_nominal_kwh'])*costmult
                    for recovery in c['terminal_recovery_fractions']:
                        battery_age=y-int(a.last_replacement_year_start)
                        residual_proxy=costmult*recovery*(pv_variable*max(0,1-y/c['pv_life_years_for_residual_proxy'])+ess_variable*max(0,1-battery_age/c['ess_life_years_for_residual_proxy']))
                        npc=capex+discounted_operating+(decom-residual_proxy)/df
                        results.append(dict(design_id=ident,profile=first.profile,case_id=first.case_id,pv_kwp=pv,ess_nominal_kwh=energy,ess_pcs_kw=power,horizon_years=y,cost_multiplier=costmult,tariff=tariff['name'],recovery_fraction=recovery,capex_krw=capex,present_total_cost_krw=npc,grid_only_present_cost_krw=discounted_baseline,npv_saving_vs_grid_krw=discounted_baseline-npc,cumulative_user_solar_fraction=cumulative_user_solar/cumulative_load,last_year_user_solar_fraction=a.user_solar_fraction,minimum_annual_user_solar_fraction=minimum_fraction,cumulative_battery_user_kwh=cumulative_battery_user,discounted_user_load_kwh=discounted_load,net_present_cost_per_discounted_user_kwh=npc/discounted_load,terminal_residual_proxy_krw=residual_proxy,planning_pv_area_m2=pv*config['area'].get('periodic_pv_m2_per_kwp_by_case',{}).get(first.case_id,config['area']['periodic_pv_m2_per_kwp'])*config['area']['site_allowance_multiplier']))
    return pd.DataFrame(results)

def select_candidates(config,results):
    grouping=['profile','horizon_years','cost_multiplier','tariff','recovery_fraction']
    rows=[]
    for keys,g in results.groupby(grouping,sort=False):
        for target in config['minimum_user_solar_fraction_targets']:
            eligible=g[g.minimum_annual_user_solar_fraction>=target-1e-10]
            for option in ['any','no_ess']:
                e=eligible if option=='any' else eligible[eligible.ess_nominal_kwh==0]
                if len(e):
                    best=e.sort_values(['present_total_cost_krw','ess_nominal_kwh','pv_kwp']).iloc[0].to_dict()
                    rows.append({**best,'minimum_solar_fraction_target':target,'selection':option,'feasible_in_grid':True})
                else:rows.append({**dict(zip(grouping,keys)),'minimum_solar_fraction_target':target,'selection':option,'feasible_in_grid':False})
    return pd.DataFrame(rows)

def main():
    config=json.loads((ROOT/'config.json').read_text(encoding='utf-8'))
    frame=import_inputs(config)
    resultdir=ROOT/'results';resultdir.mkdir(exist_ok=True)
    physics=run_physics(config,frame);physics.to_csv(resultdir/'annual_energy.csv.gz',index=False,compression='gzip')
    print('Energy simulation complete; pricing scenarios.',flush=True)
    costs=cost_results(config,physics);costs.to_csv(resultdir/'cost_scenarios.csv.gz',index=False,compression='gzip')
    best=select_candidates(config,costs);best.to_csv(resultdir/'selected_candidates.csv',index=False,encoding='utf-8-sig')
    validation={'status':'SCREENING_BALANCES_PASS','designs':int(physics.design_id.nunique()),'design_years':len(physics),'financial_scenarios':len(costs),'selected_rows':len(best),'max_hourly_energy_balance_error_kwh':float(physics.max_balance_residual_kwh.max()),'config_sha256':hashlib.sha256((ROOT/'config.json').read_bytes()).hexdigest(),'source_run':config['source_run'],'dispatch_optimality_proven':False,'field_validated':False,'demand_charge_savings_included':False,'actual_tariff_or_cost_quote':False}
    (resultdir/'validation.json').write_text(json.dumps(validation,indent=2),encoding='utf-8')
    print(json.dumps(validation,indent=2),flush=True)

if __name__=='__main__':main()
