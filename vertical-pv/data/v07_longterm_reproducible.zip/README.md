# No-cleaning 10-year scenario v0.7
Lower edge 0.30 m; clear aisle 2 m; no weeds or snow.
Python 3.11. Install requirements.txt; run python model.py then python plot.py.
inputs/ contains newly calculated clean baseline and Warp interception/exposure. Config assumptions and validation.json document physical scope. No field calibration; no 10-year observed weather.
