import unittest
import numpy as np
import pandas as pd
from model import layout, ROOT

class LayoutChecks(unittest.TestCase):
    def test_equal_pitch_hand_count(self):
        # 94m available, 40 modules per row, 47 rows at 2m pitch.
        for tilt in [30,90]:
            d=layout(tilt,2)
            self.assertEqual((d['rows'],d['modules'],d['pv_kwp']),(47,1880,940))
    def test_equal_clear_gap_hand_count(self):
        v=layout(90,1.5)
        t=layout(30,1+1.1*np.cos(np.radians(30)))
        self.assertEqual((v['rows'],v['modules'],v['pv_kwp']),(63,2520,1260))
        self.assertEqual((t['rows'],t['modules'],t['pv_kwp']),(48,1920,960))
        self.assertAlmostEqual(v['clear_gap_m'],t['clear_gap_m'])
    def test_saved_annual_energy(self):
        results=pd.read_csv(ROOT/'results.csv').set_index('scenario_id')
        h=pd.read_csv(ROOT/'hourly_kw.csv.gz',index_col=0)
        self.assertTrue(np.allclose(h.sum()/1000,results.loc[h.columns,'annual_mwh'],rtol=1e-12))
    def test_same_pitch_capacity_is_not_orientation_advantage(self):
        r=pd.read_csv(ROOT/'results.csv').query('mode == "equal_pitch"')
        p=r.pivot(index=['pitch_m','albedo'],columns='family',values='pv_kwp')
        self.assertTrue(np.all(p.vertical==p.tilted))

if __name__=='__main__':
    unittest.main()
