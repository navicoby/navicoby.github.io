"""One-hectare layout screening; finite module counts x infinite-row AC yields.

No structural, fire-access, construction, or grid-connection approval is implied.
Run next to config.json and inputs/weather.csv.gz. Geometry assumptions are explicit.
"""
from pathlib import Path
import hashlib, json, math
import numpy as np
import pandas as pd
import pvlib

ROOT = Path(__file__).resolve().parent
C = json.loads((ROOT / 'config.json').read_text(encoding='utf-8'))
W = pd.read_csv(ROOT / 'inputs/weather.csv.gz', index_col=0, parse_dates=True)
W.index = pd.to_datetime(W.index, utc=True).tz_convert('Asia/Seoul')
EXTRA = pvlib.irradiance.get_extra_radiation(W.index)

def layout(tilt, pitch):
    g = C['geometry']
    usable = g['side_m'] - 2 * g['boundary_margin_m']
    block = (usable - g['central_cross_aisle_m']) / 2
    n_block = math.floor((block + g['module_gap_m']) / (g['along_row_m'] + g['module_gap_m']))
    projected = g['slant_m'] * math.cos(math.radians(tilt))
    strip = max(g['minimum_row_strip_m'], projected)
    n_rows = math.floor((usable - strip) / pitch + 1e-10) + 1
    n_modules = n_rows * n_block * 2
    assert (n_rows - 1) * pitch + strip <= usable + 1e-9
    assert n_block * g['along_row_m'] + (n_block - 1) * g['module_gap_m'] <= block + 1e-9
    return dict(row_strip_m=strip, clear_gap_m=pitch-strip, rows=n_rows,
                modules_per_row=n_block*2, modules=n_modules,
                pv_kwp=n_modules*g['module_kwp'],
                modules_per_m2=n_modules/g['side_m']**2,
                kwp_per_m2=n_modules*g['module_kwp']/g['side_m']**2)

def electrical(front, rear, air, wind, bifaciality):
    """Monofacial has no rear optical or rear heating term in this approximation."""
    thermal_poa = front if bifaciality == 0 else front + rear
    temp = pvlib.temperature.faiman(thermal_poa, air, wind, u0=25, u1=6.84)
    eff = front + bifaciality * rear
    dc = pvlib.pvsystem.pvwatts_dc(eff, temp, pdc0=1000, gamma_pdc=-.0035).clip(lower=0)*.92
    ac = pvlib.inverter.pvwatts(dc, pdc0=1000/1.2/.96, eta_inv_nom=.96)/1000
    return ac, dc, temp, eff

def power(tilt, azimuth, albedo, pitch, return_details=False):
    g = C['geometry']
    family = 'tilted' if tilt == 30 else 'vertical'
    bifaciality = C['module_types'][family]['bifaciality']
    ir = pvlib.bifacial.infinite_sheds.get_irradiance(
        tilt, azimuth, W.solar_zenith, W.solar_azimuth, g['slant_m']/pitch,
        g['clearance_m'] + g['slant_m']/2*np.sin(np.radians(tilt)), pitch,
        W.ghi, W.dhi, W.dni, albedo, model='haydavies', dni_extra=EXTRA,
        bifaciality=bifaciality, shade_factor=0, transmission_factor=0, npoints=100,
        vectorize=True).clip(lower=0)
    ir.loc[W.solar_zenith >= 90, :] = 0
    ac, dc, temp, eff = electrical(ir.poa_front, ir.poa_back, W.temp_air, W.wind_speed, bifaciality)
    assert np.isfinite(ac).all() and ac.min() >= 0
    if return_details:
        return pd.DataFrame(dict(front_w_m2=ir.poa_front, rear_w_m2=ir.poa_back,
            effective_w_m2=eff,cell_temp_C=temp,dc_w_per_kwp=dc,ac_w_per_kwp=ac*1000))
    return ac

def main():
    rows, hourly, baseline_errors = [], {}, []
    baseline = pd.read_csv(ROOT/'inputs/baseline.csv').set_index('case_id')
    for tilt, azimuth, family, codes in [(30,180,'tilted',['M01','M03']), (90,90,'vertical',['B05','B07'])]:
        strip = layout(tilt, 2)['row_strip_m']
        candidates = [('equal_pitch', p) for p in C['row_pitch_m']]
        candidates += [('equal_clear_gap', strip+gap) for gap in C['clear_gap_m']]
        for albedo, cid in zip(C['albedos'], codes):
            ref = power(tilt, azimuth, albedo, 2)
            baseline_errors.append(abs(ref.sum()-baseline.loc[cid,'specific_yield_kwh_kwp']))
            for mode, pitch in candidates:
                d = layout(tilt, pitch)
                ac = power(tilt, azimuth, albedo, pitch)
                ident = f'{family}_{mode}_a{albedo:.1f}_p{pitch:.6f}'
                hourly[ident] = ac * d['pv_kwp']
                rows.append(dict(scenario_id=ident, mode=mode, family=family, tilt=tilt,
                    module_type=C['module_types'][family]['type'],bifaciality=C['module_types'][family]['bifaciality'],
                    albedo=albedo, pitch_m=pitch, **d,
                    specific_yield_kwh_kwp=float(ac.sum()),
                    annual_mwh=float(ac.sum()*d['pv_kwp']/1000),
                    site_yield_kwh_m2=float(ac.sum()*d['kwp_per_m2'])))
    result = pd.DataFrame(rows)
    result.to_csv(ROOT/'results.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(hourly,index=W.index).to_csv(ROOT/'hourly_kw.csv.gz', compression='gzip')
    err=max(baseline_errors)
    assert err < 1e-7, err
    assert np.allclose(result.annual_mwh*1000/10000, result.site_yield_kwh_m2)
    audit=dict(status='PASS', scenarios=len(rows), baseline_max_abs_kwh_kwp=err,
        geometry_bounds='PASS', area_energy_identity='PASS',
        weather_sha256=hashlib.sha256((ROOT/'inputs/weather.csv.gz').read_bytes()).hexdigest(),
        pvlib_version=pvlib.__version__, field_validated=False,
        limitation='Finite layout counts multiplied by infinite-row AC yield; boundary and central-aisle irradiance are not simulated.')
    (ROOT/'validation.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    selection=result[(result['mode'].eq('equal_pitch') & result.pitch_m.eq(2)) | (result['mode'].eq('equal_clear_gap') & np.isclose(result.clear_gap_m,1))]
    print(selection[['mode','family','albedo','pitch_m','clear_gap_m','rows','modules','pv_kwp','specific_yield_kwh_kwp','annual_mwh']].to_string(index=False))
    print(json.dumps(audit))

if __name__=='__main__':
    main()
