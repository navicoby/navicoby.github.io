"""Module polygons shared by the bird's-eye figure and Warp dust tracing.
Coordinates: x east, y north, z up; fixed geometric screening assumptions.
"""
import numpy as np

def module_polygons(family, clear_gap=1.0, minimum_strip=.5):
    tilt=90 if family=='vertical' else 30
    strip=max(minimum_strip,1.1*np.cos(np.radians(tilt)))
    pitch=strip+clear_gap
    rows=int(np.floor((94-strip)/pitch+1e-10))+1
    polygons=[]
    for r in range(rows):
        across=3+r*pitch
        for block_start in [3.405,52.405]:
            for m in range(20):
                along=block_start+m*2.21
                if family=='vertical':
                    # Winding points east (front); opposite surface points west.
                    x=across+strip/2
                    p=[[x,along,.8],[x,along+2.2,.8],[x,along+2.2,1.9],[x,along,1.9]]
                else:
                    # Winding points south and up (front).
                    width=1.1*np.cos(np.radians(30))
                    p=[[along,across,.8],[along+2.2,across,.8],[along+2.2,across+width,1.35],[along,across+width,1.35]]
                polygons.append(p)
    return np.asarray(polygons,dtype=np.float32)

def triangulated(family):
    polygons=module_polygons(family)
    points=polygons.reshape((-1,3))
    indices=np.asarray([[4*i,4*i+1,4*i+2,4*i,4*i+2,4*i+3] for i in range(len(polygons))],dtype=np.int32).ravel()
    return points,indices,len(polygons)
