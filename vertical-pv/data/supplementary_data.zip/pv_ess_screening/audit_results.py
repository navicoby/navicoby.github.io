from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
p=pd.read_csv(ROOT/'results/annual_energy.csv.gz')
c=pd.read_csv(ROOT/'results/cost_scenarios.csv.gz')
s=pd.read_csv(ROOT/'results/selected_candidates.csv')
assert not p.duplicated(['design_id','year']).any()
assert p.groupby('design_id').size().eq(10).all()
user_res=(p.direct_user_kwh+p.discharge_user_kwh+p.grid_user_kwh-p.user_load_kwh).abs().max()
assert user_res<1e-7
none=p[p.ess_nominal_kwh==0]
assert (none[['discharge_user_kwh','discharge_aux_kwh','charge_ac_kwh','aux_load_kwh','end_usable_soc_kwh']]==0).all().all()
balance=[]
for _,g in p.groupby('design_id'):
    net=(g.pv_generation_kwh+g.grid_user_kwh+g.grid_aux_kwh-g.user_load_kwh-g.aux_load_kwh-g.export_kwh-g.conversion_loss_kwh-g.initial_capacity_spill_kwh-g.replacement_spill_kwh).sum()-g.iloc[-1].end_usable_soc_kwh
    balance.append(abs(net))
assert max(balance)<1e-6
grouping=['profile','horizon_years','cost_multiplier','tariff','recovery_fraction']
selected=s.set_index(grouping)
max_rank_error=0.;count=0
for keys,g in c.groupby(grouping):
    for _,r in selected.loc[[keys]].iterrows():
        eligible=g[g.minimum_annual_user_solar_fraction>=r.minimum_solar_fraction_target-1e-10]
        if r.selection=='no_ess':eligible=eligible[eligible.ess_nominal_kwh==0]
        assert bool(r.feasible_in_grid)==bool(len(eligible))
        if len(eligible):
            error=abs(r.present_total_cost_krw-eligible.present_total_cost_krw.min())
            max_rank_error=max(max_rank_error,error)
            assert error<1e-5
        count+=1
audit={'status':'SAVED_RESULTS_AUDIT_PASS','user_energy_balance_max_kwh':float(user_res),'ten_year_system_energy_balance_max_kwh':max(balance),'candidate_selections_checked':count,'maximum_cost_ranking_error_krw':max_rank_error,'scope':'Energy balance, bookkeeping and finite candidate selection; not measured validation or optimal dispatch verification.'}
(ROOT/'results/independent_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
manifest={str(f.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest() for f in ROOT.rglob('*') if f.is_file() and '__pycache__' not in f.parts and f.name!='MANIFEST.sha256.json'}
(ROOT/'MANIFEST.sha256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps(audit,indent=2))

