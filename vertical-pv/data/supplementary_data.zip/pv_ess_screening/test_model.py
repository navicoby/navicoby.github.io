import unittest
import numpy as np
from model import dispatch, cost_results, select_candidates
import pandas as pd
import json
from pathlib import Path

B={'roundtrip_efficiency':1.,'minimum_soc_fraction':.1,'maximum_soc_fraction':.9,'auxiliary_kw_per_pcs_kw':0.}

class DispatchTests(unittest.TestCase):
    def test_no_ess_is_direct_pv_only(self):
        r,_=dispatch([0,10,0],[2,4,2],0,0,B)
        self.assertEqual(r['direct_user_kwh'],4)
        self.assertEqual(r['grid_user_kwh'],4)
        self.assertEqual(r['export_kwh'],6)

    def test_nominal_and_usable_capacity_differ(self):
        r,t=dispatch([10,0],[0,10],10,10,B,traces=True)
        self.assertEqual(r['available_usable_kwh'],8)
        self.assertAlmostEqual(r['discharge_user_kwh'],8)
        self.assertAlmostEqual(r['grid_user_kwh'],2)
        self.assertAlmostEqual(r['export_kwh'],2)
        self.assertAlmostEqual(t[0,-1],8)

    def test_roundtrip_loss(self):
        r,_=dispatch([10,0],[0,10],100,100,{**B,'roundtrip_efficiency':.81})
        self.assertAlmostEqual(r['discharge_user_kwh'],8.1)
        self.assertAlmostEqual(r['conversion_loss_kwh'],1.9)
        self.assertAlmostEqual(r['grid_user_kwh'],1.9)

    def test_power_constraint(self):
        r,_=dispatch([100,0],[0,100],100,5,B)
        self.assertEqual(r['charge_ac_kwh'],5)
        self.assertEqual(r['discharge_user_kwh'],5)

    def test_no_free_initial_energy(self):
        r,_=dispatch([0,0],[5,5],100,100,B)
        self.assertEqual(r['discharge_user_kwh'],0)
        self.assertEqual(r['grid_user_kwh'],10)

    def test_energy_carries_between_years(self):
        a,_=dispatch([10],[0],10,10,B)
        b,_=dispatch([0],[10],10,10,B,initial=a['end_usable_soc_kwh'])
        self.assertAlmostEqual(b['discharge_user_kwh'],8)

    def test_capacity_fade_spill_is_recorded(self):
        r,_=dispatch([0],[0],10,10,B,soh=.5,initial=8)
        self.assertAlmostEqual(r['initial_capacity_spill_kwh'],4)
        self.assertAlmostEqual(r['end_usable_soc_kwh'],4)

    def test_auxiliary_consumption_not_counted_as_user_supply(self):
        r,_=dispatch([0,0],[0,2],10,10,{**B,'auxiliary_kw_per_pcs_kw':.01})
        self.assertAlmostEqual(r['grid_aux_kwh'],.2)
        self.assertEqual(r['user_solar_fraction'],0)

    def test_random_energy_balance(self):
        rng=np.random.default_rng(93)
        r,t=dispatch(rng.random(500)*20,rng.random(500)*15,30,7,{**B,'roundtrip_efficiency':.9,'auxiliary_kw_per_pcs_kw':.002},traces=True)
        self.assertLess(r['max_balance_residual_kwh'],1e-10)
        self.assertTrue(np.all(t[:,2]*(t[:,3]+t[:,4])<1e-9))

    def test_bad_inputs_rejected(self):
        with self.assertRaises(ValueError):dispatch([-1],[1],0,0,B)
        with self.assertRaises(ValueError):dispatch([1],[1],10,0,B)

    def test_roundoff_cannot_make_next_year_start_negative(self):
        a,_=dispatch([5,0],[0,20],25,12.5,{**B,'roundtrip_efficiency':.9})
        self.assertGreaterEqual(a['end_usable_soc_kwh'],0)
        b,_=dispatch([0],[1],25,12.5,{**B,'roundtrip_efficiency':.9},initial=a['end_usable_soc_kwh'])
        self.assertAlmostEqual(b['grid_user_kwh'],1)

class FinanceTests(unittest.TestCase):
    def test_grid_only_cashflow_has_zero_investment_and_zero_savings(self):
        config=json.loads((Path(__file__).parent/'config.json').read_text())
        r,_=dispatch([0,0],[10,10],0,0,B)
        frame=pd.DataFrame([dict(design_id='grid',profile='daytime',case_id='B01',pv_kwp=0,ess_nominal_kwh=0,ess_pcs_kw=0,year=1,replacement=False,last_replacement_year_start=0,**r)])
        cost=cost_results(config,frame)
        self.assertTrue((cost.capex_krw==0).all())
        self.assertTrue((cost.npv_saving_vs_grid_krw==0).all())
        expected=20*180/1.05
        self.assertAlmostEqual(cost.query('tariff=="base_assumed"').iloc[0].present_total_cost_krw,expected)

    def test_target_uses_worst_year_and_can_select_no_ess(self):
        config={'minimum_user_solar_fraction_targets':[0,.8]}
        base=dict(profile='daytime',horizon_years=10,cost_multiplier=1,tariff='base',recovery_fraction=0,pv_kwp=20,ess_nominal_kwh=0,present_total_cost_krw=100,minimum_annual_user_solar_fraction=.5)
        rows=pd.DataFrame([dict(base,design_id='none'),dict(base,design_id='battery',ess_nominal_kwh=100,present_total_cost_krw=200,minimum_annual_user_solar_fraction=.9)])
        best=select_candidates(config,rows)
        self.assertEqual(best.query('minimum_solar_fraction_target==0 and selection=="any"').iloc[0].design_id,'none')
        self.assertEqual(best.query('minimum_solar_fraction_target==0.8 and selection=="any"').iloc[0].design_id,'battery')
        self.assertFalse(best.query('minimum_solar_fraction_target==0.8 and selection=="no_ess"').iloc[0].feasible_in_grid)

if __name__=='__main__':unittest.main()
