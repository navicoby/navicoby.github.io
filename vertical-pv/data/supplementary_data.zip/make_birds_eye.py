from pathlib import Path
import importlib.util
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from mpl_toolkits.mplot3d.art3d import Poly3DCollection, Line3DCollection
import numpy as np

BASE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('site_geometry',BASE/'site_10000m2/geometry.py')
geo=importlib.util.module_from_spec(spec);spec.loader.exec_module(geo)
OUT=BASE/'figures';OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':['Arial','DejaVu Sans'],'font.size':9,'svg.fonttype':'none','pdf.fonttype':42,'savefig.facecolor':'white'})
fig=plt.figure(figsize=(10,8))
fig.subplots_adjust(left=.02,right=.98,top=.91,bottom=.07,wspace=.03,hspace=.18)
for col,(family,title,color) in enumerate([('vertical','VERTICAL','#D55E00'),('tilted','TILTED','#0072B2')]):
    polys=geo.module_polygons(family)
    for row in [0,1]:
        ax=fig.add_subplot(2,2,row*2+col+1,projection='3d',proj_type='ortho',computed_zorder=False)
        full=row==0
        if full:
            g=[[(0,0,0),(100,0,0),(100,100,0),(0,100,0)]]
            ax.add_collection3d(Poly3DCollection(g,facecolors='#eef0e8',edgecolors='#9ea7a0',linewidths=.6,zorder=0))
            path=[[(3,48,.01),(97,48,.01),(97,52,.01),(3,52,.01)]] if family=='vertical' else [[(48,3,.01),(52,3,.01),(52,97,.01),(48,97,.01)]]
            ax.add_collection3d(Poly3DCollection(path,facecolors='#ccd4d7',edgecolors='none',zorder=1))
            chosen=polys
            ax.set(xlim=(-5,105),ylim=(-5,105),zlim=(0,8));ax.set_box_aspect((110,110,8))
            subtitle=f'{len(polys):,} modules | {len(polys)*.5/1000:.3f} MWp | 100 × 100 m'
        else:
            chosen=polys[(polys[:,:,0].max(axis=1)<13)&(polys[:,:,1].max(axis=1)<13)]
            ax.add_collection3d(Poly3DCollection([[(2,2,0),(13,2,0),(13,13,0),(2,13,0)]],facecolors='#eef0e8',edgecolors='#aeb6ad',linewidths=.5,zorder=0))
            ax.set(xlim=(1,14),ylim=(1,14),zlim=(0,3.2));ax.set_box_aspect((13,13,3.2))
            subtitle='Detail: 90° tilt · 1.50 m pitch' if family=='vertical' else 'Detail: 30° tilt · 1.953 m pitch'
        ax.add_collection3d(Poly3DCollection(chosen,facecolors=color,edgecolors='#f4f8fa',linewidths=.07 if full else .45,alpha=.95,zorder=3))
        supports=[]
        for p in chosen:
            for idx in [0,1]:supports.append([p[idx],[p[idx][0],p[idx][1],0]])
        ax.add_collection3d(Line3DCollection(supports,colors='#7e878a',linewidths=.14 if full else .75,zorder=2))
        ax.view_init(elev=26,azim=-55)
        ax.set_axis_off()
        ax.text2D(.03,.99,'abcd'[row*2+col],transform=ax.transAxes,fontsize=12,fontweight='bold')
        ax.text2D(.5,.98,title if full else subtitle,transform=ax.transAxes,ha='center',fontsize=13 if full else 10,fontweight='bold',color=color)
        ax.text2D(.5,.03,subtitle if full else 'Module: 2.2 × 1.1 m · lower edge 0.8 m',transform=ax.transAxes,ha='center',fontsize=9)
fig.text(.5,.98,'One-hectare layouts with the same 1 m clear gap',ha='center',fontsize=13,fontweight='bold')
fig.text(.5,.035,'Same orthographic camera and true geometric proportions within each row; close-ups use a separate common scale.',ha='center',fontsize=8)
fig.text(.5,.015,'Supports are schematic. No structural design, terrain, soiling or irradiance is encoded by the colours.',ha='center',fontsize=8,color='#52616b')
for ext in ['png','svg','pdf']:fig.savefig(OUT/f'fig4_birds_eye.{ext}',dpi=300,bbox_inches='tight',pad_inches=.05)
plt.close(fig)
print('Birds-eye comparison generated from the one-hectare module geometry.')
