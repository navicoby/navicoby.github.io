# Supplementary material: vertical PV on vacant land

All loads and costs are assumed, not facility measurements or quotes.

Python 3.12. Install pv_ess_screening/requirements.txt. To regenerate figures, run `python make_figures.py` from this folder. To rerun ESS, enter pv_ess_screening and run `python -m unittest -v test_model`, then `python model.py` and `python audit_results.py`. Preserve existing results before rerunning.

Saved PV hourly outputs are inputs. This package does not include the original full RADIANCE/pvlib workflow or imply field validation. Orientation-constrained cost comparisons require positive PV; tenure comparison also permits grid-only.
