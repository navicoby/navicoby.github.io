"""Current comparison: tilted monofacial and vertical bifacial, same front rating.

Requires sibling site_10000m2 with model.py/config.json/inputs/weather.csv.gz.
Original all-bifacial reproduction remains a separate historical artifact.
"""
from pathlib import Path
import importlib.util,json,hashlib
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('site_model',ROOT.parent/'site_10000m2/model.py')
model=importlib.util.module_from_spec(spec);spec.loader.exec_module(model)

def summary(h,cid,tilt,azimuth,albedo,pitch):
    ac=h.ac_w_per_kwp/1000;sy=ac.sum();front=h.front_w_m2.sum()/1000;rear=h.rear_w_m2.sum()/1000
    return dict(case_id=cid,tilt=tilt,azimuth=azimuth,albedo=albedo,pitch=pitch,clearance=.8,
        bifaciality=0 if tilt==30 else .8,module_type='monofacial' if tilt==30 else 'bifacial',
        thermal_irradiance='front only' if tilt==30 else 'front plus rear',slant_length=1.1,along_row=2.2,
        annual_front_poa_kwh_m2=front,annual_rear_poa_kwh_m2=rear,
        annual_effective_poa_kwh_m2=h.effective_w_m2.sum()/1000,
        specific_yield_kwh_kwp=sy,periodic_area_productivity_kwh_m2=sy/(2.21*pitch/.5),
        morning_fraction=ac[ac.index.hour<10].sum()/sy,midday_fraction=ac[(ac.index.hour>=10)&(ac.index.hour<15)].sum()/sy,
        evening_fraction=ac[ac.index.hour>=15].sum()/sy,peak_ac_kw_per_kwp=ac.max(),status='ASSUMED_NOT_FIELD_VALIDATED')

def main():
    (ROOT/'hourly').mkdir(exist_ok=True)
    rows=[];hourly={}
    for tilt,azimuth,start,prefix in [(30,180,1,'M'),(90,90,5,'B')]:
        for j,albedo in enumerate([.2,.4,.6,.8]):
            cid=f'{prefix}{start+j:02d}';h=model.power(tilt,azimuth,albedo,2,return_details=True)
            rows.append(summary(h,cid,tilt,azimuth,albedo,2));hourly[cid]=h.ac_w_per_kwp/1000
            h.to_csv(ROOT/f'hourly/{cid}.csv.gz',compression='gzip')
    baseline=pd.DataFrame(rows);baseline.to_csv(ROOT/'baseline.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(hourly).to_csv(ROOT/'hourly_kw_per_kwp.csv.gz',compression='gzip')
    # Existing Figure 3 scope: vertical pitch sweep, one tilted reference at 2.5m.
    old=pd.read_csv(ROOT/'spacing_design.csv');spacing=[]
    for _,r in old.iterrows():
        family='tilted' if r.family=='tilted_reference' else 'vertical';tilt=30 if family=='tilted' else 90;az=180 if tilt==30 else 90
        h=model.power(tilt,az,r.albedo,r.pitch,return_details=True)
        s=summary(h,'spacing',tilt,az,r.albedo,r.pitch);s['family']=r.family
        spacing.append(s)
    pd.DataFrame(spacing).to_csv(ROOT/'spacing.csv',index=False,encoding='utf-8-sig')
    config=dict(revision='v0.5',module_types=model.C['module_types'],front_rating_wp=500,
        dimensions_m=[2.2,1.1],gamma_pdc=-.0035,dc_loss=.08,inverter_efficiency=.96,dc_ac_ratio=1.2,
        temperature_note='Faiman front POA for monofacial; front+rear for bifacial. Empirical thermal parameters are not product calibrated.',
        previous_case_ids='M01-M04 replace tilted bifacial B01-B04. B05-B08 vertical outputs unchanged.',
        weather_sha256=hashlib.sha256((model.ROOT/'inputs/weather.csv.gz').read_bytes()).hexdigest(),
        soiling_coupled=False)
    (ROOT/'config.json').write_text(json.dumps(config,indent=2),encoding='utf-8')
    print(baseline[['case_id','module_type','albedo','specific_yield_kwh_kwp']].to_string(index=False))

if __name__=='__main__':main()
