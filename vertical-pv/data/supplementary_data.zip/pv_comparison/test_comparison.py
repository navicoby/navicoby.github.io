import unittest,importlib.util
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('site_model',ROOT.parent/'site_10000m2/model.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class ModuleTypeChecks(unittest.TestCase):
    def test_monofacial_ignores_rear_irradiance(self):
        front=pd.Series([0.,150.,600.]);back=pd.Series([100.,300.,800.])
        one=m.electrical(front,back,25.,1.,0.)
        two=m.electrical(front,back*3,25.,1.,0.)
        for a,b in zip(one,two):np.testing.assert_array_equal(a,b)
        self.assertEqual(one[0].iloc[0],0.) # Rear-only light cannot generate mono power.
    def test_bifacial_responds_to_rear_only_light(self):
        f=pd.Series([0.,0.]);r=pd.Series([0.,300.])
        ac,_,_,eff=m.electrical(f,r,25.,1.,.8)
        self.assertGreater(ac.iloc[1],0.);self.assertEqual(eff.iloc[1],240.)
    def test_saved_module_types_and_effective_irradiance(self):
        b=pd.read_csv(ROOT/'baseline.csv')
        for _,row in b.iterrows():
            h=pd.read_csv(ROOT/f'hourly/{row.case_id}.csv.gz',index_col=0)
            self.assertAlmostEqual(h.ac_w_per_kwp.sum()/1000,row.specific_yield_kwh_kwp,places=8)
            np.testing.assert_allclose(h.effective_w_m2,h.front_w_m2+row.bifaciality*h.rear_w_m2,atol=1e-9)
            if row.tilt==30:self.assertEqual(row.bifaciality,0.)
            else:self.assertEqual(row.bifaciality,.8)

if __name__=='__main__':unittest.main()
