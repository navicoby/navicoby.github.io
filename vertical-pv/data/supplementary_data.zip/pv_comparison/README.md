# Current PV comparison, v0.5

The current manuscript compares **south-facing 30-degree monofacial** panels
(M01–M04, rear electrical weight 0) with **east–west vertical bifacial** panels
(B05–B08, rear electrical weight 0.8). Both have the same 500 Wp front rating
and 2.2 × 1.1 m geometry. This compares two system configurations; it does not
isolate orientation from module technology.

`baseline.csv` contains eight albedo/configuration cases. `hourly` contains
front/rear incident irradiance, effective irradiance, temperature and DC/AC
outputs; rear incident irradiance on a monofacial panel is diagnostic only.
`spacing.csv` contains the 22 landscape vertical pitch cases and two monofacial
tilted references used in Figure 3. Earlier portrait/control sweeps are historical
and are not used in this figure.

Faiman temperature uses front irradiance for the monofacial approximation and
front+rear irradiance for the bifacial approximation. Common heat-transfer
parameters are not calibrated to actual products or backsheet materials.
The earlier C01 rear-disabled counterfactual retained rear heating, so it is
not identical to the current monofacial thermal assumption.

The original Seoul TMY, time convention, common 8% DC loss, inverter efficiency
0.96 and DC/AC ratio 1.2 are retained. The four vertical reference yields are
unchanged within numerical precision. Front-only and rear-response invariants
are checked in `test_comparison.py`. Surface soiling is not yet coupled to annual
power. Field validation is not claimed.

Reproduce from the supplementary archive with sibling `site_10000m2` intact:

1. Install `pv_ess_screening/requirements.txt` (Python 3.12).
2. Run `python pv_comparison/build_comparison.py`.
3. Run `python -m unittest discover -s pv_comparison -p test_comparison.py`.
4. Run `python site_10000m2/model.py` for the 52 one-hectare cases.

The ESS input CSV is the M01/M03/B05/B07 subset of the saved hourly AC output,
in kW per kWp. Preserve it when rerunning the cost model. All costs remain
hypothetical; identical PV unit costs do not imply identical market prices for
monofacial and bifacial products.
