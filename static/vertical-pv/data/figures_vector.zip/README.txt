Figures v0.7: lower edge 30 cm, clear aisle 2 m, no weeds/snow. All 10 figures regenerated. SVG and PDF files; source tables in figure_source_data.zip.
