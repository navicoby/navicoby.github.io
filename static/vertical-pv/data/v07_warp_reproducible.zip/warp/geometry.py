"""Module polygons shared by the bird's-eye figure and Warp dust tracing.
Coordinates: x east, y north, z up; fixed geometric screening assumptions.
"""
import numpy as np
from pathlib import Path
import json
STUDY=json.loads((Path(__file__).resolve().parent.parent/"study.json").read_text(encoding="utf-8"))

def module_polygons(family, clear_gap=None, minimum_strip=.5):
    if clear_gap is None: clear_gap=STUDY["clear_gap_m"]
    h=STUDY["clearance_m"]
    tilt=90 if family=='vertical' else 30
    strip=max(minimum_strip,1.1*np.cos(np.radians(tilt)))
    pitch=strip+clear_gap
    rows=int(np.floor((94-strip)/pitch+1e-10))+1
    polygons=[]
    for r in range(rows):
        across=3+r*pitch
        for block_start in [3.405,52.405]:
            for m in range(20):
                along=block_start+m*2.21
                if family=='vertical':
                    # Winding points east (front); opposite surface points west.
                    x=across+strip/2
                    p=[[x,along,h],[x,along+2.2,h],[x,along+2.2,h+1.1],[x,along,h+1.1]]
                else:
                    # Winding points south and up (front).
                    width=1.1*np.cos(np.radians(30))
                    p=[[along,across,h],[along+2.2,across,h],[along+2.2,across+width,h+.55],[along,across+width,h+.55]]
                polygons.append(p)
    return np.asarray(polygons,dtype=np.float32)

def triangulated(family):
    polygons=module_polygons(family)
    points=polygons.reshape((-1,3))
    indices=np.asarray([[4*i,4*i+1,4*i+2,4*i,4*i+2,4*i+3] for i in range(len(polygons))],dtype=np.int32).ravel()
    return points,indices,len(polygons)
