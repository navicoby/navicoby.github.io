from pathlib import Path
import json,hashlib,shutil,re
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent.parent
(R/'warp/generated_site/figures').mkdir(parents=True,exist_ok=True)
# Regenerate the dry figure used on both current pages.
d=pd.read_csv(R/'warp/results.csv');fig,axs=plt.subplots(1,2,figsize=(9,3.7));fig.subplots_adjust(bottom=.24,wspace=.3)
names=['calm','from_east','from_west','from_north','from_south'];x=np.arange(5)
plt.rcParams.update({'svg.fonttype':'none','pdf.fonttype':42})
for ax,face in zip(axs,['front','rear']):
 for off,fam,col,label in [(-.18,'tilted','#0072B2','Tilted monofacial'),(.18,'vertical','#D55E00','Vertical bifacial')]:
  g=d[d.family==fam].groupby('wind')[face+'_g_m2'].agg(['mean','std']).reindex(names)
  ax.bar(x+off,g['mean']*1000,.34,yerr=g['std']*1000,capsize=2,color=col,label=label)
 ax.set(xticks=x,xticklabels=['Calm','East','West','North','South'],ylabel='Intercepted dust (mg/m² per hour)',title=face.title()+(' (tilted rear: non-generating)' if face=='rear' else ''));ax.spines[['top','right']].set_visible(False)
fig.legend(*axs[0].get_legend_handles_labels(),loc='lower center',ncol=2,bbox_to_anchor=(.5,.065))
fig.suptitle('Lower edge 0.30 m | Clear aisle 2.00 m | Dust concentration 100 µg/m³',fontsize=11)
fig.text(.5,.01,'First-hit capture = 1; error bars: three-seed Monte Carlo standard deviation, not field uncertainty.',ha='center',fontsize=8)
for ext in ['svg','png','pdf']:fig.savefig(R/f'warp/generated_site/figures/figS1_warp_interception.{ext}',dpi=180,bbox_inches='tight')
plt.close(fig)
