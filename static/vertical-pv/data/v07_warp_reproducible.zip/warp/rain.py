"""GPU rain interception + hypothetical two-pool dust wash-off scenarios.

Run alongside pilot.py and geometry.py. Values in rain_config.json are explicit
scenario assumptions, not fitted field parameters. One parcel represents water
volume, NOT one physical raindrop. Each module face is a well-mixed compartment.
"""
from pathlib import Path
import csv, json, time
import numpy as np
import warp as wp
from pilot import mesh_data, origins_for, trace, numpy_reference

ROOT = Path(__file__).resolve().parent

@wp.kernel
def remove_dust(exposure: wp.array(dtype=wp.float32), rain: float, initial: float,
                bound_fraction: float, loose_k: float, bound_k: float,
                after: wp.array(dtype=wp.float32)):
    i = wp.tid()
    dose = exposure[i] * rain
    after[i] = initial * ((1.0-bound_fraction)*wp.exp(-loose_k*dose)
                         + bound_fraction*wp.exp(-bound_k*dose))

def gpu_remaining(exposure, rain, initial, fraction, kl, kb, device):
    inp=wp.array(np.asarray(exposure,dtype=np.float32).ravel(),dtype=wp.float32,device=device)
    out=wp.empty_like(inp)
    wp.launch(remove_dust,dim=inp.size,inputs=[inp,float(rain),float(initial),float(fraction),float(kl),float(kb),out],device=device)
    return out.numpy().reshape(exposure.shape)

def reference_remaining(exposure, rain, initial, fraction, kl, kb):
    dose=exposure.astype(np.float64)*rain
    return initial*((1-fraction)*np.exp(-kl*dose)+fraction*np.exp(-kb*dose))

def write_csv(name, rows):
    with (ROOT/name).open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)

def main():
    cfg=json.loads((ROOT/'rain_config.json').read_text())
    device=wp.get_device('cuda:0');assert device.is_cuda
    down=cfg['rain_downward_speed_m_s'];horizontal=cfg['rain_horizontal_speed_m_s']
    m0=cfg['initial_dust_mg_m2_per_face'];area=cfg['module_area_m2']
    winds=[('calm',(0,0)),('from_east',(-horizontal,0)),('from_west',(horizontal,0)),
           ('from_north',(0,-horizontal)),('from_south',(0,horizontal))]
    results=[];exposures=[];checks=[];convergence=[];max_error=0.;start=time.perf_counter()
    (ROOT/'rain_surfaces').mkdir(exist_ok=True)
    for family in ['vertical','tilted']:
        pts,idx,nmodules=mesh_data(family)
        mesh=wp.Mesh(points=wp.array(pts,dtype=wp.vec3,device=device),indices=wp.array(idx,dtype=wp.int32,device=device))
        for wind,vxy in winds:
            velocity=(*vxy,-down)
            origins,_=origins_for(velocity,256,79)
            got,_=trace(mesh,origins,velocity,nmodules,device)
            expected=numpy_reference(pts,idx,origins,velocity,nmodules)
            assert np.array_equal(got,expected),(family,wind,got,expected)
            checks.append(dict(family=family,wind=wind,rays=256,counts=got.tolist()))
            seed_residual=[]
            for seed in cfg['seeds']:
                origins,flux=origins_for(velocity,cfg['particles_per_run'],seed)
                counts,surface=trace(mesh,origins,velocity,nmodules,device)
                assert counts.sum()==cfg['particles_per_run']
                assert np.array_equal(surface.sum(axis=0),counts[:2])
                # For 1 mm of horizontal rain: V_in = (flux / |vz|) litres.
                litres_per_parcel_per_mm=flux/down/cfg['particles_per_run']
                exposure=surface*litres_per_parcel_per_mm/area
                volume_by_category=counts*litres_per_parcel_per_mm
                assert np.isclose(volume_by_category.sum(),flux/down)
                for side,col in [('front',0),('rear',1)]:
                    exposures.append(dict(family=family,wind=wind,seed=seed,face=side,modules=nmodules,
                        surface_rain_mm_per_horizontal_mm=exposure[:,col].mean(),
                        front_parcels=int(counts[0]),rear_parcels=int(counts[1]),ground_parcels=int(counts[2]),escape_parcels=int(counts[3]),
                        incoming_litres_per_horizontal_mm=flux/down))
                if seed==201:
                    np.savez_compressed(ROOT/f'rain_surfaces/{family}_{wind}.npz',exposure_mm_per_mm=exposure)
                previous={}
                for rain in cfg['rainfall_mm']:
                    for pool,fraction in cfg['strongly_bound_fractions'].items():
                        for multiplier in cfg['coefficient_multipliers']:
                            kl=cfg['loose_washoff_per_mm']*multiplier;kb=cfg['bound_washoff_per_mm']*multiplier
                            after=gpu_remaining(exposure,rain,m0,fraction,kl,kb,device)
                            reference=reference_remaining(exposure,rain,m0,fraction,kl,kb)
                            error=float(np.max(np.abs(after-reference)));max_error=max(max_error,error)
                            assert np.allclose(after,reference,atol=3e-5,rtol=1e-6)
                            assert after.min()>=0 and after.max()<=m0+1e-5
                            assert np.allclose(after[exposure==0],m0)
                            if rain==0:assert np.allclose(after,m0)
                            key=(pool,multiplier)
                            if key in previous:assert np.all(after<=previous[key]+1e-5)
                            previous[key]=after
                            removed=m0-after
                            assert np.allclose(after+removed,m0)
                            for side,col in [('front',0),('rear',1)]:
                                avg=float(after[:,col].mean(dtype=np.float64))
                                results.append(dict(family=family,wind=wind,seed=seed,face=side,rainfall_mm=rain,
                                    adhesion=pool,bound_fraction=fraction,coefficient_multiplier=multiplier,
                                    initial_mg_m2=m0,surface_rain_mm=exposure[:,col].mean()*rain,
                                    remaining_mg_m2=avg,removed_mg_m2=m0-avg,remaining_percent=100*avg/m0))
                            if rain==10 and pool=='loose_dominated' and multiplier==1:
                                seed_residual.append(float(after[:,0].mean(dtype=np.float64)))
                # Increasing the strongly bound fraction cannot improve washing.
                low=reference_remaining(exposure,10,m0,.2,.25,.015)
                high=reference_remaining(exposure,10,m0,.7,.25,.015)
                assert np.all(high>=low-1e-9)
            # A larger independent parcel sample tests nonlinear per-module bias.
            if wind=='from_east':
                large_origins,flux=origins_for(velocity,cfg['convergence_particles'],901)
                counts,surface=trace(mesh,large_origins,velocity,nmodules,device)
                assert counts.sum()==cfg['convergence_particles']
                e=surface*(flux/down/cfg['convergence_particles'])/area
                large=float(reference_remaining(e,10,m0,.2,.25,.015)[:,0].mean())
                difference=abs(large-np.mean(seed_residual))
                assert difference<1.0,(family,difference)
                convergence.append(dict(family=family,wind=wind,case='front, 10 mm, loose dominated, central coefficients',
                    baseline_remaining_mg_m2=float(np.mean(seed_residual)),large_sample_remaining_mg_m2=large,
                    absolute_difference_percentage_points=difference,acceptance_percentage_points=1.0))
    # Analytic unshadowed checks: vertical calm has no direct rain; tilted calm
    # catches cos(30deg) mm per horizontal mm; vertical E-facing front catches 3/5.
    analytic=[]
    for family,wind,face,target in [('vertical','calm','front',0.),('vertical','calm','rear',0.),
        ('tilted','calm','front',np.cos(np.pi/6)),('tilted','calm','rear',0.),
        ('vertical','from_east','front',horizontal/down)]:
        value=float(np.mean([r['surface_rain_mm_per_horizontal_mm'] for r in exposures if (r['family'],r['wind'],r['face'])==(family,wind,face)]))
        assert abs(value-target)<.01,(family,wind,face,value,target)
        analytic.append(dict(family=family,wind=wind,face=face,analytic=target,gpu=value,tolerance=.01))
    write_csv('rain_results.csv',results);write_csv('rain_exposure.csv',exposures)
    audit=dict(status='PASS',warp_version=wp.__version__,device_name=device.name,
        rain_ray_runs=30,primary_water_parcels=30*cfg['particles_per_run'],additional_convergence_parcels=2*cfg['convergence_particles'],
        result_rows=len(results),independent_ray_checks=checks,analytic_exposure_checks=analytic,
        wash_gpu_numpy_max_abs_error_mg_m2=max_error,convergence=convergence,
        invariants=['parcel conservation','water volume conservation','surface count conservation','dust mass conservation',
          'zero-rain identity','zero-exposure identity','nonnegative bounded residual','monotonic washing with dose','greater adhesion retains more dust'],
        elapsed_seconds=time.perf_counter()-start,field_validated=False,annual_energy_adjusted=False)
    (ROOT/'rain_validation.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in audit.items() if k not in ['independent_ray_checks','analytic_exposure_checks']},indent=2))

if __name__=='__main__':main()
