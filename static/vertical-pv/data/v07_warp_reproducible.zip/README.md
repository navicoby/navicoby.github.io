# Warp v0.7
Lower edge 0.30 m; clear aisle 2 m; no weeds/snow.
Python 3.11, NVIDIA GPU. From this root run: python warp/pilot.py; python warp/rain.py; python warp/plot_dry.py; python warp/build_rain_figure.py.
Keep study.json above warp/geometry.py. See warp/README.md for scientific scope. The full workflow is in v07_reproducible.zip.
