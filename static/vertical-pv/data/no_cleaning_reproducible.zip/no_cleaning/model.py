"""Illustrative no-manual-cleaning scenarios; not a site forecast.

Reuses published Warp face-mean interception and rain exposure outputs.
This script does NOT run Warp. An hourly, spatially uniform two-pool model
preserves residual bound dust across rain events. See README.md for scope.
"""
from pathlib import Path
import hashlib
import json
import math
import platform
import sys

import numpy as np
import pandas as pd
import pvlib
from scipy.special import erf

ROOT = Path(__file__).resolve().parent


def transmission(mass_g_m2):
    """HSU empirical mass/transmission relation ONLY, not its deposition model."""
    mass = np.asarray(mass_g_m2, dtype=float)
    if np.any(mass < -1e-12) or np.any(mass > 10):
        raise ValueError('Outside adopted 0–10 g/m2 HSU mass domain')
    return 1 - .3437 * erf(.17 * np.maximum(mass, 0)**.8473)


def dust_series(hours, deposition_g_m2_h, exposure, rainfall, initial, bound, kl, kb):
    """Two faces x two persistent pools; input rain is horizontal mm per hour.

    Deposit, remove rain-exposed fractions, then use the hourly end state.
    Uniform dust per family/face; no module-to-module variability or remobilization.
    """
    state = np.full(2, initial)[:, None] * np.array([1-bound, bound])[None, :]
    incoming = np.asarray(deposition_g_m2_h)[:, None] * np.array([1-bound, bound])[None, :]
    pools = np.empty((hours, 2, 2))
    removed = np.zeros(2)
    for t in range(hours):
        state += incoming
        after = state * np.exp(-np.asarray(exposure)[:, None] * rainfall[t] * np.array([kl, kb])[None, :])
        removed += (state-after).sum(axis=1)
        pools[t] = state = after
    residual = initial + np.asarray(deposition_g_m2_h)*hours - pools[-1].sum(axis=1) - removed
    return pools, removed, float(np.max(np.abs(residual)))


def irradiance(weather, case, albedo):
    tilt, azimuth, pitch = case['tilt_deg'], case['azimuth_deg'], case['pitch_m']
    ir = pvlib.bifacial.infinite_sheds.get_irradiance(
        tilt, azimuth, weather.solar_zenith, weather.solar_azimuth, 1.1/pitch,
        .8 + .55*np.sin(np.radians(tilt)), pitch, weather.ghi, weather.dhi,
        weather.dni, albedo, model='haydavies',
        dni_extra=pvlib.irradiance.get_extra_radiation(weather.index),
        bifaciality=case['bifaciality'], shade_factor=0, transmission_factor=0,
        npoints=100, vectorize=True).clip(lower=0)
    ir.loc[weather.solar_zenith >= 90, :] = 0
    thermal = ir.poa_front if case['bifaciality'] == 0 else ir.poa_front+ir.poa_back
    temp = pvlib.temperature.faiman(thermal, weather.temp_air,
                                   weather.wind_speed, u0=25, u1=6.84)
    return ir.poa_front.to_numpy(), ir.poa_back.to_numpy(), temp.to_numpy()


def ac_power(front, rear, temp, bifaciality, trans):
    effective = front*trans[:, 0] + bifaciality*rear*trans[:, 1]
    dc = np.maximum(pvlib.pvsystem.pvwatts_dc(effective, temp, pdc0=1000, gamma_pdc=-.0035), 0)*.92
    return pvlib.inverter.pvwatts(dc, pdc0=1000/1.2/.96, eta_inv_nom=.96)/1000


def run():
    cfg = json.loads((ROOT/'config.json').read_text(encoding='utf-8'))
    w = pd.read_csv(ROOT/'inputs/weather.csv.gz', index_col=0, parse_dates=True)
    w.index = pd.to_datetime(w.index, utc=True).tz_convert('Asia/Seoul')
    assert len(w) == 8760 and np.all((w.index[1:]-w.index[:-1]) == pd.Timedelta(hours=1))
    dry = pd.read_csv(ROOT/'inputs/warp_soiling_results.csv')
    wet = pd.read_csv(ROOT/'inputs/rain_exposure.csv')
    winds = list(cfg['wind_weights'])
    daily_rows, hourly_main, summary, checks, mean_inputs = [], {}, [], {}, []
    max_balance, max_mass = 0., 0.
    zero = np.ones((len(w), 2))
    for family, case in cfg['cases'].items():
        deposition, exposure = [], []
        for face in ['front', 'rear']:
            # First average the original three random seeds, then the assumed winds.
            d = dry[dry.family.eq(family)].groupby('wind')[face+'_g_m2'].mean()
            r = wet[wet.family.eq(family) & wet.face.eq(face)].groupby('wind').surface_rain_mm_per_horizontal_mm.mean()
            dep = sum(d.loc[k]*cfg['wind_weights'][k] for k in winds)*cfg['concentration_ug_m3']/100
            exp = sum(r.loc[k]*cfg['wind_weights'][k] for k in winds)
            deposition.append(dep)
            exposure.append(exp)
            mean_inputs.append(dict(family=family, face=face, deposition_mg_m2_day=dep*24000,
                                    surface_rain_mm_per_horizontal_mm=exp))
        front, rear, temp = irradiance(w, case, cfg['albedo'])
        clean = ac_power(front, rear, temp, case['bifaciality'], zero)
        # Independent baseline regression at 2m pitch against M01 / B05.
        base = pd.read_csv(ROOT/'inputs/baseline.csv').set_index('case_id')
        ref = irradiance(w, dict(case, pitch_m=2), cfg['albedo'])
        error = abs(ac_power(*ref, case['bifaciality'], zero).sum()-base.loc[case['baseline_case'], 'specific_yield_kwh_kwp'])
        checks[family+'_baseline_abs_kwh_kwp'] = float(error)
        assert error < 1e-7
        for rain_mode in ['no_rain', 'periodic_rain']:
            rainfall = np.zeros(len(w))
            if rain_mode == 'periodic_rain':
                # Start of day 14, 28, ... at 00:00 KST; 26 hypothetical events.
                event_hours = np.arange(cfg['rain_interval_days']-1, 365, cfg['rain_interval_days'])*24
                rainfall[event_hours] = cfg['rain_event_mm']
            for dep_multiplier in cfg['deposition_multipliers']:
                for wash_multiplier in cfg['wash_multipliers']:
                    pools, removed, balance = dust_series(len(w), np.array(deposition)*dep_multiplier,
                        exposure, rainfall, cfg['initial_dust_g_m2_per_face'], cfg['bound_fraction'],
                        cfg['loose_washoff_per_mm']*wash_multiplier, cfg['bound_washoff_per_mm']*wash_multiplier)
                    mass = pools.sum(axis=2)
                    trans = transmission(mass)
                    ac = ac_power(front, rear, temp, case['bifaciality'], trans)
                    assert np.isfinite(ac).all() and np.min(ac) >= 0 and np.all(ac <= clean+1e-12)
                    assert balance < 1e-9 and mass.min() >= 0
                    if rain_mode == 'no_rain':
                        assert np.all(np.diff(mass, axis=0) >= -1e-12)
                    max_balance = max(max_balance, balance)
                    max_mass = max(max_mass, float(mass.max()))
                    summary.append(dict(family=family, module_type=case['module_type'], rain_mode=rain_mode,
                        deposition_multiplier=dep_multiplier, wash_multiplier=wash_multiplier,
                        clean_annual_kwh_kwp=float(clean.sum()), soiled_annual_kwh_kwp=float(ac.sum()),
                        lost_annual_kwh_kwp=float((clean-ac).sum()), annual_loss_percent=float(100*(clean-ac).sum()/clean.sum()),
                        final_front_g_m2=float(mass[-1, 0]), final_rear_g_m2=float(mass[-1, 1])))
                    if dep_multiplier != 1 or wash_multiplier != 1:
                        continue
                    frame = pd.DataFrame(dict(clean_ac_kwh_kwp=clean, soiled_ac_kwh_kwp=ac,
                        loss_kwh_kwp=clean-ac, rain_mm=rainfall, front_g_m2=mass[:, 0], rear_g_m2=mass[:, 1],
                        front_transmission=trans[:, 0], rear_transmission=trans[:, 1],
                        front_bound_g_m2=pools[:, 0, 1], rear_bound_g_m2=pools[:, 1, 1]), index=w.index)
                    hourly_main[family+'_'+rain_mode] = frame
                    daily = frame.resample('D').agg({k: ('sum' if k in ['clean_ac_kwh_kwp','soiled_ac_kwh_kwp','loss_kwh_kwp','rain_mm'] else 'last') for k in frame})
                    daily['retained_generation_percent'] = daily.soiled_ac_kwh_kwp/daily.clean_ac_kwh_kwp*100
                    daily['cumulative_loss_kwh_kwp'] = daily.loss_kwh_kwp.cumsum()
                    daily['day'] = np.arange(1, 366)
                    daily['family'], daily['rain_mode'] = family, rain_mode
                    daily_rows.append(daily.reset_index(names='tmy_date'))
    # Invariants beyond regression to prior output.
    p0, _, _ = dust_series(48, [0, 0], [1, 1], np.zeros(48), 0, .7, .25, .015)
    assert np.all(p0 == 0) and np.all(transmission(p0.sum(axis=2)) == 1)
    clean_check = ac_power(front, rear, temp, case['bifaciality'], np.ones((8760,2)))
    assert np.allclose(clean_check, clean, atol=1e-12)
    ref_trans = np.column_stack([np.ones(8760), np.full(8760, .7)])
    assert np.allclose(ac_power(front, rear, temp, 0, ref_trans), ac_power(front, rear, temp, 0, zero))
    # Rain cannot remove more than present; bound and loose pools are not reset after a rain event.
    pp, _, bal = dust_series(2, [0,0], [1,1], np.array([10.,10.]), .1, .7, .25, .015)
    expected = .1*np.array([.3,.7])*np.exp(-np.array([.25,.015])*20)
    assert np.allclose(pp[-1,0], expected) and bal < 1e-12
    daily = pd.concat(daily_rows, ignore_index=True)
    sm = pd.DataFrame(summary)
    for family in cfg['cases']:
        a = sm[(sm.family==family) & (sm.deposition_multiplier==1) & (sm.wash_multiplier==1)]
        assert a.set_index('rain_mode').loc['periodic_rain','soiled_annual_kwh_kwp'] >= a.set_index('rain_mode').loc['no_rain','soiled_annual_kwh_kwp']
    daily.to_csv(ROOT/'daily.csv', index=False, encoding='utf-8-sig')
    sm.to_csv(ROOT/'summary.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(mean_inputs).to_csv(ROOT/'face_inputs.csv', index=False, encoding='utf-8-sig')
    pd.concat(hourly_main, axis=1).to_csv(ROOT/'hourly.csv.gz', compression='gzip')
    monthly = []
    for key, frame in hourly_main.items():
        m = frame[['clean_ac_kwh_kwp','soiled_ac_kwh_kwp','loss_kwh_kwp','rain_mm']].resample('MS').sum()
        m['scenario'] = key
        m['month'] = np.arange(1,13)
        monthly.append(m.reset_index(names='tmy_month'))
    pd.concat(monthly).to_csv(ROOT/'monthly.csv', index=False, encoding='utf-8-sig')
    audit = dict(status='PASS', field_validated=False, scenarios=len(sm), hourly_steps=8760,
        **checks, mass_balance_max_abs_g_m2=max_balance, maximum_mass_g_m2_all_scenarios=max_mass,
        adopted_hsu_domain_g_m2=[0,10], zero_dust_equals_clean=True,
        no_rain_mass_monotonic=True, persistent_two_pool_rain_check=True,
        monofacial_rear_has_zero_power_effect=True, ac_bounded_by_clean_reference=True,
        rain_does_not_reduce_yield=True, implementation='CPU extension of archived Warp results; no new Warp run',
        versions=dict(python=platform.python_version(),pvlib=pvlib.__version__,numpy=np.__version__,pandas=pd.__version__),
        input_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'inputs').glob('*'))})
    (ROOT/'validation.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    print(sm[(sm.deposition_multiplier==1)&(sm.wash_multiplier==1)].to_string(index=False))
    print(json.dumps(audit, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    run()
