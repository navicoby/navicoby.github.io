"""Publication figures from the saved, auditable scenario CSVs."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'figures'
OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'Malgun Gothic','font.size':11,'axes.unicode_minus':False,
    'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'path',
    'pdf.fonttype':42,'axes.labelcolor':'#233746','text.color':'#233746',
    'xtick.color':'#445360','ytick.color':'#445360'})
COLORS={'tilted':'#14678b','vertical':'#d56a22'}
NAMES={'tilted':'경사형 단면','vertical':'수직형 양면'}
STYLES={'periodic_rain':'-','no_rain':'--'}
D=pd.read_csv(ROOT/'daily.csv')
M=pd.read_csv(ROOT/'monthly.csv')

def save(fig,name):
    for ext in ['png','svg','pdf']:
        fig.savefig(OUT/f'{name}.{ext}',dpi=180,facecolor='white')
    plt.close(fig)

fig,axs=plt.subplots(2,1,figsize=(10.4,8.6),sharex=True)
fig.subplots_adjust(left=.11,right=.97,top=.80,bottom=.13,hspace=.32)
fig.suptitle('청소하지 않는 1년, 발전량은 얼마나 줄어들까',x=.08,y=.975,ha='left',fontsize=19,fontweight='bold')
fig.text(.08,.925,'경사형 단면 30° · 수직형 양면 90°  |  같은 1 kWp 기준  |  실측이 아닌 가정 시나리오',fontsize=11,color='#536573')
handles=[Line2D([0],[0],color=COLORS[f],lw=2.4,label=NAMES[f]) for f in COLORS]
handles += [Line2D([0],[0],color='#536573',ls=STYLES[r],lw=2,label=l) for r,l in [('periodic_rain','14일마다 비 10 mm'),('no_rain','비 없음')]]
fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(.073,.90),ncol=4,frameon=False,handlelength=2.7,columnspacing=1.3)
for f in COLORS:
    for r in STYLES:
        d=D[(D.family==f)&(D.rain_mode==r)]
        axs[0].plot(d.day,d.retained_generation_percent,color=COLORS[f],ls=STYLES[r],lw=1.7)
        axs[1].plot(d.day,d.cumulative_loss_kwh_kwp,color=COLORS[f],ls=STYLES[r],lw=1.9)
axs[0].set_title('a  같은 날의 청결 상태를 100%로 보았을 때',loc='left',fontsize=12,fontweight='bold',pad=12)
axs[0].set_ylabel('일 발전량 유지율 (%)')
axs[0].axhline(100,color='#9cabb3',lw=.8)
axs[0].set_ylim(75,101)
axs[1].set_title('b  먼지 때문에 생산하지 못한 전력의 누적량',loc='left',fontsize=12,fontweight='bold',pad=12)
axs[1].set_ylabel('누적 발전 손실 (kWh/kWp)')
axs[1].set_xlabel('경과일 (TMY 1월 1일부터)')
axs[1].set_ylim(bottom=0)
for ax in axs:
    ax.set_xlim(1,365);ax.set_xticks([1,60,120,180,240,300,365]);ax.grid(axis='y',color='#e2e9ed',lw=.7);ax.set_axisbelow(True)
fig.text(.08,.055,'초기 잔류 먼지 0.1 g/m²/면 · 가상 농도 10 μg/m³ · 강부착분 70% · 인위적 청소 0회',fontsize=10,color='#536573')
fig.text(.08,.028,'비·바람은 별도 가정이며 서울의 실제 강우 기록이 아닙니다. 먼지 질량과 발전 손실률은 다른 값입니다.',fontsize=10,color='#536573')
save(fig,'figS3_no_cleaning_time')

fig,axs=plt.subplots(1,2,figsize=(11,5.5),sharey=True)
fig.subplots_adjust(left=.085,right=.97,top=.70,bottom=.20,wspace=.15)
fig.suptitle('계절 변화와 먼지 손실을 나누어 본 월별 발전량',x=.07,y=.97,ha='left',fontsize=18,fontweight='bold')
fig.text(.07,.885,'같은 기상·같은 설비의 청결 상태와 비교  |  경사형 단면 φ=0 · 수직형 양면 φ=0.8',fontsize=11,color='#536573')
legend=[Line2D([0],[0],color='#a1a9af',lw=2,label='먼지 없는 기준')]
legend += [Line2D([0],[0],color='#334f60',lw=2,ls=STYLES[r],label=l) for r,l in [('periodic_rain','비만 맞고 청소 안 함'),('no_rain','비도 청소도 없음')]]
fig.legend(handles=legend,loc='upper left',bbox_to_anchor=(.064,.85),ncol=3,frameon=False)
for ax,f,letter in zip(axs,COLORS,['a','b']):
    for r in STYLES:
        m=M[M.scenario.eq(f+'_'+r)]
        if r=='periodic_rain':
            ax.plot(m.month,m.clean_ac_kwh_kwp,color='#a1a9af',lw=2.5)
            ax.fill_between(m.month,m.soiled_ac_kwh_kwp,m.clean_ac_kwh_kwp,color=COLORS[f],alpha=.09)
        ax.plot(m.month,m.soiled_ac_kwh_kwp,color=COLORS[f],ls=STYLES[r],lw=2)
    ax.set_title(letter+'  '+NAMES[f],loc='left',fontsize=12,fontweight='bold',pad=12)
    ax.set_xlim(1,12);ax.set_xticks([1,3,6,9,12]);ax.set_xlabel('TMY 월');ax.set_ylim(0,210)
    ax.grid(axis='y',color='#e2e9ed',lw=.7);ax.set_axisbelow(True)
axs[0].set_ylabel('월 발전량 (kWh/kWp)')
fig.text(.07,.08,'서울 대표 기상년의 일사·기온으로 계산한 AC 발전량. 두 패널의 설치 용량을 1 kWp로 맞췄습니다.',fontsize=10,color='#536573')
fig.text(.07,.035,'오염 후에도 날씨가 좋아지면 발전량은 늘 수 있습니다. 먼지의 영향은 같은 달의 청결 기준과의 차이입니다.',fontsize=10,color='#536573')
save(fig,'figS4_no_cleaning_monthly')
print('Saved 2 figures in PNG, SVG and PDF.')
