"""Warp GPU first-hit dust interception pilot, not calibrated soiling physics.

Particles follow a prescribed uniform wind plus settling velocity. Every panel hit
sticks (upper capture assumption). There is no flow solver, drag evolution,
turbulence, rebound, resuspension, rainfall or conversion to power loss.
"""
from pathlib import Path
import importlib.util, json, time, csv
import numpy as np
import warp as wp

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('geometry',ROOT/'geometry.py')
geo=importlib.util.module_from_spec(spec);spec.loader.exec_module(geo)
wp.init()

@wp.kernel
def cast_dust(mesh_id:wp.uint64, origins:wp.array(dtype=wp.vec3), direction:wp.vec3,
              panel_faces:int, hits:wp.array(dtype=wp.int32), surface:wp.array(dtype=wp.int32)):
    i=wp.tid()
    hit=wp.mesh_query_ray(mesh_id,origins[i],direction,200.0)
    category=3 # escape
    if hit.result:
        if hit.face>=panel_faces:
            category=2 # ground
        else:
            category=0 # front, according to geometric winding
            if wp.dot(direction,hit.normal)>0.0:
                category=1
            module=hit.face//2
            wp.atomic_add(surface,module*2+category,1)
    wp.atomic_add(hits,category,1)

def mesh_data(family):
    points,indices,n=geo.triangulated(family)
    k=len(points)
    points=np.vstack([points,[[0,0,0],[100,0,0],[100,100,0],[0,100,0]]]).astype(np.float32)
    indices=np.r_[indices,[k,k+1,k+2,k,k+2,k+3]].astype(np.int32)
    return points,indices,n

def origins_for(velocity,n,seed):
    rng=np.random.default_rng(seed)
    vx,vy,vz=velocity
    flux=np.array([abs(vx)*100*4,abs(vy)*100*4,abs(vz)*10000])
    total=flux.sum()
    choose=rng.choice(3,n,p=flux/total)
    xyz=rng.uniform(0,1,(n,3))*[100,100,4]
    xyz[choose==0,0]=0 if vx>0 else 100
    xyz[choose==1,1]=0 if vy>0 else 100
    xyz[choose==2,2]=4
    return xyz.astype(np.float32),float(total)

def trace(mesh,origins,velocity,nmodules,device):
    direction=np.asarray(velocity,dtype=np.float32)
    direction/=np.linalg.norm(direction)
    hit=wp.zeros(4,dtype=wp.int32,device=device)
    surf=wp.zeros(nmodules*2,dtype=wp.int32,device=device)
    o=wp.array(origins,dtype=wp.vec3,device=device)
    wp.launch(cast_dust,dim=len(origins),inputs=[mesh.id,o,wp.vec3(*direction),nmodules*2,hit,surf],device=device)
    wp.synchronize_device(device)
    return hit.numpy(),surf.numpy().reshape((-1,2))

def numpy_reference(points,indices,origins,velocity,nmodules):
    """Independent vectorized Moller-Trumbore first-hit reference, one ray at a time."""
    tri=points[indices.reshape((-1,3))].astype(np.float64)
    a=tri[:,0];e1=tri[:,1]-a;e2=tri[:,2]-a
    d=np.array(velocity,dtype=float);d/=np.linalg.norm(d)
    h=np.cross(np.broadcast_to(d,e2.shape),e2)
    det=np.einsum('ij,ij->i',e1,h)
    valid=np.abs(det)>1e-9
    inv=np.zeros_like(det);inv[valid]=1/det[valid]
    counts=np.zeros(4,dtype=np.int64)
    for origin in origins:
        s=origin-a;u=inv*np.einsum('ij,ij->i',s,h);q=np.cross(s,e1)
        v=inv*(q@d);t=inv*np.einsum('ij,ij->i',e2,q)
        ok=valid&(u>=0)&(v>=0)&(u+v<=1)&(t>=0)&(t<=200)
        if not ok.any():counts[3]+=1;continue
        face=np.argmin(np.where(ok,t,np.inf))
        category=2 if face>=nmodules*2 else int(np.dot(d,np.cross(e1[face],e2[face]))>0)
        counts[category]+=1
    return counts

def main():
    device=wp.get_device('cuda:0')
    assert device.is_cuda, 'This pilot must actually run on an NVIDIA GPU.'
    cfg=dict(particles_per_run=500000,seeds=[101,102,103],settling_m_s=.01,
        concentration_ug_m3=100,exposure_hours=1,capture_probability=1,
        wind_speed_m_s=1,domain_m=[100,100,4],clear_gap_m=1,minimum_row_strip_m=.5,
        model='uniform-velocity first-hit interception; no CFD or optical calibration',
        wind_directions='meteorological origin; e.g. east means velocity toward west')
    rows=[];checks=[];t0=time.perf_counter()
    (ROOT/'surface_counts').mkdir(exist_ok=True)
    for family in ['vertical','tilted']:
        pts,idx,nmodules=mesh_data(family)
        mesh=wp.Mesh(points=wp.array(pts,dtype=wp.vec3,device=device),indices=wp.array(idx,dtype=wp.int32,device=device))
        for name,vxy in [('calm',(0,0)),('from_east',(-1,0)),('from_west',(1,0)),('from_north',(0,-1)),('from_south',(0,1))]:
            velocity=(*vxy,-cfg['settling_m_s'])
            check_origins,_=origins_for(velocity,256,47)
            gpu,_=trace(mesh,check_origins,velocity,nmodules,device)
            ref=numpy_reference(pts,idx,check_origins,velocity,nmodules)
            assert np.array_equal(gpu,ref),(family,name,gpu,ref)
            checks.append(dict(family=family,wind=name,rays=256,gpu_counts=gpu.tolist(),numpy_counts=ref.tolist()))
            for seed in cfg['seeds']:
                origins,flux=origins_for(velocity,cfg['particles_per_run'],seed)
                start=time.perf_counter()
                counts,surfaces=trace(mesh,origins,velocity,nmodules,device)
                elapsed=time.perf_counter()-start
                assert counts.sum()==cfg['particles_per_run']
                assert surfaces.sum()==counts[0]+counts[1]
                mass_per_particle_g=cfg['concentration_ug_m3']*1e-6*flux*3600*cfg['exposure_hours']/cfg['particles_per_run']
                area=nmodules*2.2*1.1
                rows.append(dict(family=family,wind=name,seed=seed,modules=nmodules,
                    front_hits=int(counts[0]),rear_hits=int(counts[1]),ground_hits=int(counts[2]),escape=int(counts[3]),
                    injected_mass_g=mass_per_particle_g*cfg['particles_per_run'],
                    front_g_m2=counts[0]*mass_per_particle_g/area,
                    rear_g_m2=counts[1]*mass_per_particle_g/area,
                    ground_g=counts[2]*mass_per_particle_g,
                    elapsed_seconds=elapsed))
                if seed==101:np.savez_compressed(ROOT/f'surface_counts/{family}_{name}.npz',counts=surfaces,mass_per_particle_g=mass_per_particle_g)
    with (ROOT/'results.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
    (ROOT/'config.json').write_text(json.dumps(cfg,indent=2),encoding='utf-8')
    audit=dict(status='PASS',warp_version=wp.__version__,device=str(device),device_name=device.name,
        runs=len(rows),total_particles=len(rows)*cfg['particles_per_run'],
        count_conservation='PASS',surface_count_conservation='PASS',independent_reference=checks,
        elapsed_seconds=time.perf_counter()-t0,field_validated=False,
        annual_pv_loss_computed=False,scope='Dry interception demonstrator, not a soiling forecast')
    (ROOT/'validation.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in audit.items() if k!='independent_reference'},indent=2))

if __name__=='__main__':main()
