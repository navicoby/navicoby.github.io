"""Build supplementary rain figures and self-contained scenario comparison page."""
from pathlib import Path
import json, zipfile, shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

BASE=Path(__file__).resolve().parent
ROOT=BASE;DIST=BASE/'generated_site'
(DIST/'figures').mkdir(parents=True,exist_ok=True)
(DIST/'data').mkdir(exist_ok=True)
r=pd.read_csv(ROOT/'rain_results.csv');e=pd.read_csv(ROOT/'rain_exposure.csv')
v=json.loads((ROOT/'rain_validation.json').read_text())
cfg=json.loads((ROOT/'rain_config.json').read_text())
order=['calm','from_east','from_west','from_north','from_south']
labels=['Calm','East','West','North','South']
colors={'vertical':'#D55E00','tilted':'#0072B2'}
plt.rcParams.update({'font.family':['Arial','DejaVu Sans'],'font.size':8.5,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42})
fig,axes=plt.subplots(2,2,figsize=(8.8,7.0),gridspec_kw={'height_ratios':[1,1.1]})
fig.subplots_adjust(wspace=.32,hspace=.58,left=.085,right=.97,bottom=.18,top=.95)
ax=axes[0,0];ax.set_axis_off();ax.set(xlim=(0,1),ylim=(0,1))
ax.text(0,1.04,'a',fontweight='bold',fontsize=12,transform=ax.transAxes)
ax.text(.06,1.04,'Event model',fontsize=10,transform=ax.transAxes)
def box(x,y,w,h,text,color):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.014,rounding_size=0.015',fc=color,ec='#bdc9cf',lw=.7))
    ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=8.1)
box(.03,.73,.94,.20,'Rain gauge P → Warp surface interception Rᵢ\n1 ha · Vertical / Tilted · front / rear','#edf4f8')
box(.03,.42,.41,.19,'Loose pool\n(1 − f) M₀','#f4f0e5')
box(.56,.42,.41,.19,'Strongly bound pool\nf M₀','#eaeff1')
for x in [.235,.765]:
    ax.annotate('',(x,.62),(x,.73),arrowprops={'arrowstyle':'->','color':'#50616b','lw':.9})
    ax.annotate('',(x,.19),(x,.41),arrowprops={'arrowstyle':'->','color':'#50616b','lw':.9})
ax.text(.235,.305,'× exp(−kₗ Rᵢ)',ha='center',bbox={'fc':'white','ec':'none','pad':1},fontsize=8)
ax.text(.765,.305,'× exp(−kᵦ Rᵢ)',ha='center',bbox={'fc':'white','ec':'none','pad':1},fontsize=8)
box(.03,.02,.94,.17,'Remaining dust = loose + bound\nM₀ = 100 mg m⁻² on every face','#f4f6f7')
ax=axes[0,1]
matrix=np.array([[e[(e.family==family)&(e.face==face)&(e.wind==wind)].surface_rain_mm_per_horizontal_mm.mean() for wind in order]
                for family,face in [('vertical','front'),('vertical','rear'),('tilted','front'),('tilted','rear')]])
im=ax.imshow(matrix,cmap='Blues',vmin=0,vmax=1.25,aspect='auto')
for i in range(4):
    for j in range(5):ax.text(j,i,f'{matrix[i,j]:.2f}',ha='center',va='center',fontsize=8,color='white' if matrix[i,j]>.7 else '#203746')
ax.set(xticks=range(5),xticklabels=labels,yticks=range(4),yticklabels=['V · front (E)','V · rear (W)','T · front (S)','T · rear (N)'],xlabel='Rain direction of origin')
ax.tick_params(length=0)
ax.set_title('b   Received rain / horizontal rainfall',loc='left',fontsize=10,pad=14)
cb=fig.colorbar(im,ax=ax,fraction=.04,pad=.03);cb.ax.tick_params(labelsize=7);cb.set_label('mm / mm',fontsize=8)
for ax,pool,letter,title in [(axes[1,0],'loose_dominated','c','Loose dominated · f = 0.20'),(axes[1,1],'adhered_dominated','d','Adhered dominated · f = 0.70')]:
    subset=r[(r.wind=='from_east')&(r.face=='front')&(r.adhesion==pool)]
    for family in ['vertical','tilted']:
        g=subset[subset.family==family].groupby(['rainfall_mm','coefficient_multiplier']).remaining_percent.mean().unstack()
        ax.fill_between(g.index,g[2.0],g[.5],color=colors[family],alpha=.12,lw=0)
        ax.plot(g.index,g[1.0],marker='o',markersize=3,color=colors[family],lw=1.6,label=family.title()+' front')
    ax.axhline(100,color='#78858c',ls=':',lw=1,label='Both rear faces (no direct rain)')
    ax.set(xlim=(0,40),ylim=(0,106),xticks=[0,10,20,30,40],xlabel='Horizontal rainfall per event (mm)',ylabel='Dust remaining (% of initial mass)')
    ax.set_title(letter+'   '+title,loc='left',fontsize=10,pad=14)
    ax.grid(axis='y',color='#e3e8eb',lw=.5);ax.set_axisbelow(True)
handles,leglabels=axes[1,0].get_legend_handles_labels()
fig.legend(handles,leglabels,ncol=3,loc='lower center',bbox_to_anchor=(.5,.072),frameon=False,fontsize=8)
fig.text(.5,.038,'c–d: easterly rain, horizontal 3 m/s / downward 5 m/s. Bands: assumed wash-off coefficients ×0.5–2; not confidence intervals.',ha='center',fontsize=7.2)
fig.text(.5,.012,'Hypothetical coefficients kₗ = 0.25 and kᵦ = 0.015 mm⁻¹. Initial dust is controlled, not predicted. No PV power loss is inferred.',ha='center',fontsize=7.2)
for ext in ['png','svg','pdf']:fig.savefig(DIST/f'figures/figS2_rain_adhesion.{ext}',dpi=300,bbox_inches='tight',pad_inches=.06)
plt.close(fig)

group=r.groupby(['family','wind','face','rainfall_mm','adhesion','coefficient_multiplier']).agg(remaining_percent=('remaining_percent','mean'),surface_rain_mm=('surface_rain_mm','mean')).reset_index()
records=group.round(6).to_dict('records')
(DIST/'data/rain_comparison.json').write_text(json.dumps(records,separators=(',',':')),encoding='utf-8')
for name in ['rain_results.csv','rain_exposure.csv','rain_config.json','rain_validation.json']:
    shutil.copy2(ROOT/name,DIST/'data'/name)

def value(family,pool,wind='from_east',face='front',rain=10):
    return float(group[(group.family==family)&(group.adhesion==pool)&(group.wind==wind)&(group.face==face)&(group.rainfall_mm==rain)&(group.coefficient_multiplier==1)].remaining_percent.iloc[0])
vl=value('vertical','loose_dominated');tl=value('tilted','loose_dominated')
vb=value('vertical','adhered_dominated');tb=value('tilted','adhered_dominated')
rows=''
for family,label in [('vertical','수직형'),('tilted','경사형')]:
    for face,facelabel in [('front','앞면'),('rear','뒷면')]:
        lo=value(family,'loose_dominated',face=face);hi=value(family,'adhered_dominated',face=face)
        dose=group[(group.family==family)&(group.face==face)&(group.wind=='from_east')&(group.rainfall_mm==10)].surface_rain_mm.mean()
        rows+=f'<tr><th scope="row">{label} {facelabel}</th><td>{dose:.2f} mm</td><td>100.0%</td><td>{lo:.1f}%</td><td>{hi:.1f}%</td></tr>'

page='''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="1만㎡ 수직·경사 태양광의 NVIDIA Warp 강우 노출과 먼지 부착·세척 가정 비교"><title>강우와 부착 먼지 비교 | Vertical PV Research</title><link rel="stylesheet" href="paper.css"><link rel="stylesheet" href="rain-comparison.css"><script defer src="rain-comparison.js"></script></head><body><main class="rain-paper"><a href="index.html#discussion">← 논문으로 돌아가기</a><header class="article-header"><p class="kicker">SUPPLEMENTARY METHOD · RAIN &amp; SOILING · v0.4</p><h1 class="paper-title">비가 오면 먼지는<br>얼마나 씻겨 나가는가?</h1><p class="subtitle">같은 초기 오염량에서 비교한 수직형·경사형의 강우 노출과 부착 먼지 잔류</p><p class="en-title">Rain interception and adhesion-dependent dust retention<br>on vertical and tilted photovoltaic arrays</p><div class="draft-note"><strong>가정 시나리오.</strong> NVIDIA GPU로 강우의 표면 충돌을 계산하고, 가정한 세척식으로 잔류 먼지를 비교했습니다. 부착 계수는 실측 보정 전이며, 본문의 연간 발전량·ESS 비용에는 반영하지 않았습니다.</div></header>
<section class="section"><h2>01 같은 비, 다른 표면 노출</h2><p>강우량계의 10mm와 모듈 표면에 닿는 물의 양은 다릅니다. 수직형은 동·서향 양면, 경사형은 남향 30° 배치를 사용합니다. 수직으로 내리는 비는 이상적인 수직면과 직접 충돌하지 않고, 옆에서 불어오는 비는 바람을 맞는 면을 적십니다. 따라서 “비가 왔으니 양면이 모두 깨끗해졌다”는 가정을 두지 않았습니다.</p><p>비를 맞기 전에는 모든 모듈의 각 면에 100mg/m²가 균일하게 붙어 있다고 설정했습니다. 이는 세척 효과만 비교하기 위한 통제 조건이며, 아래 건식 침착 시험의 결과를 누적한 값은 아닙니다.</p><div class="result-lead"><div><span>약한 부착 우세 · 수직형 앞면</span><strong>__VL__%</strong><small>10mm 동풍 강우 후 남은 먼지</small></div><div><span>약한 부착 우세 · 경사형 앞면</span><strong>__TL__%</strong><small>같은 초기 질량·같은 세척 계수</small></div><div><span>강한 부착 우세 · 수직 / 경사 앞면</span><strong>__VB__ / __TB__%</strong><small>강하게 붙은 비율을 20% → 70%로 변경</small></div></div><p class="table-note">비의 수평 이동속도 3m/s, 낙하속도 5m/s를 가정한 중앙 계수 결과입니다. 먼지 잔류율이며 발전 손실률이 아닙니다. 무강우 대조에서는 모든 면이 100%를 유지합니다.</p></section>
<section class="section" id="comparison"><h2>02 강우 조건별 비교</h2><p>강우량과 비가 오는 방향을 바꾸면 저장된 GPU 계산 결과가 표시됩니다. ‘약한 부착 우세’와 ‘강한 부착 우세’를 같은 표에서 비교할 수 있습니다.</p><div class="rain-controls"><label>수평면 누적 강우량<select id="rain-amount"><option value="0">0mm · 무강우</option><option value="0.5">0.5mm</option><option value="2">2mm</option><option value="5">5mm</option><option value="10" selected>10mm</option><option value="20">20mm</option><option value="40">40mm</option></select></label><label>비가 오는 방향<select id="rain-wind"><option value="calm">무풍 · 수직 낙하</option><option value="from_east" selected>동풍 · 동쪽에서</option><option value="from_west">서풍 · 서쪽에서</option><option value="from_north">북풍 · 북쪽에서</option><option value="from_south">남풍 · 남쪽에서</option></select></label></div><p id="rain-status" class="table-note" aria-live="polite">10mm · 동풍 · 초기 오염 100mg/m²/면</p><div class="table-wrap"><table><caption><b>보충 표 S1.</b> 초기 먼지 대비 잔류 질량. 괄호는 세척 계수 ×0.5–2의 가정 민감도 범위입니다.</caption><thead><tr><th scope="col">배치·면</th><th scope="col">표면에 닿은 물</th><th scope="col">비가 안 왔다면</th><th scope="col">약한 부착 우세<br>강부착분 20%</th><th scope="col">강한 부착 우세<br>강부착분 70%</th></tr></thead><tbody id="rain-body">__ROWS__</tbody></table></div><p id="rain-note" class="table-note">동풍 조건에서는 수직형의 동향 앞면과 경사형의 앞면에 직접 비가 닿습니다. 표면 강우 0은 이 모델의 직접 충돌이 없다는 뜻입니다.</p><noscript><p>조건 변경에는 JavaScript가 필요합니다. 위 표는 10mm 동풍의 중앙값입니다. 전체 결과는 아래 CSV로 확인할 수 있습니다.</p></noscript></section>
<section class="section"><h2>03 강우 × 부착 상태의 상호작용</h2><figure><a href="figures/figS2_rain_adhesion.svg"><img src="figures/figS2_rain_adhesion.svg" alt="강우 표면 충돌 과정, 풍향별 수직형·경사형 양면의 물 노출, 부착 상태별 먼지 잔류율 곡선"></a><figcaption><b>보충 그림 S2.</b> (a) 모듈별 강우 노출과 두 종류 먼지의 제거 과정. (b) 수평 강우 1mm당 각 면의 평균 직접 강우량. (c–d) 동풍 강우에서 약한 부착과 강한 부착 조건의 앞면 잔류율. 음영은 두 세척 계수를 함께 0.5–2배 바꾼 범위로, 신뢰구간이 아닙니다. 점은 계산한 강우량이며 선은 점 사이를 연결합니다. 가로 점선은 직접 비가 닿지 않은 양 배치의 뒷면입니다. <a href="figures/figS2_rain_adhesion.pdf">PDF</a> · <a href="figures/figS2_rain_adhesion.png">PNG</a></figcaption></figure><div class="callout"><p><strong>이 비교에서 확인한 점.</strong> 부착이 강할수록 같은 강우에도 먼지가 더 많이 남습니다. 수직형의 건식 침착이 작을 가능성과 강우 세척이 잘된다는 주장은 별개로 검증해야 합니다. 배치의 우열은 실제 먼지 누적·풍향·강우·양면 일사를 함께 계산해야 판단할 수 있습니다.</p></div></section>
<section class="section"><h2>04 계산 방법과 가정</h2><p>100 × 100m 부지에서 통로 순폭 1m인 기존 모듈 기하를 사용했습니다. 수직형 2,520장, 경사형 1,920장이고 모듈 한 면은 2.42m²입니다. 100 × 100 × 4m 영역의 위쪽과 바람 유입 측면에서 물을 나타내는 계산 입자를 투입하고, 패널·지면의 첫 충돌을 추적했습니다. 계산 입자 수는 실제 빗방울 수가 아닙니다.</p><p>무풍과 동·서·남·북풍, 두 배치, 난수 시드 3개에서 각 50만 입자를 사용했습니다. 주 계산 30회·1,500만 입자와 표본 수 점검용 400만 입자를 NVIDIA Warp 1.17.0 / RTX 4080 Laptop GPU에서 실행했습니다. 비의 속도는 처방한 값이며, 공기 흐름이나 빗방울의 가속 운동을 푼 결과가 아닙니다.</p><div class="equation"><span class="expr">Rᵢ = P · Hᵢ · (Σ Aⱼ |vⱼ|) / (N |vᶻ| Aₘ)</span><span class="expr">Mᵢ(P) = M₀ [(1 − f) exp(−kₗRᵢ) + f exp(−kᵦRᵢ)]</span></div><p>Rᵢ는 모듈 한 면의 수신 강우량(mm), P는 수평면 누적 강우량(mm), Hᵢ는 해당 면의 충돌 계수, N은 투입 입자 수입니다. Aⱼ는 유입 경계 면적, Aₘ은 모듈 면적이며, 1L/m² = 1mm로 환산합니다. 각 면에서 제거식을 먼저 계산한 뒤 평균하여 모듈 간 노출 차이를 보존했습니다. 한 모듈 안의 먼지와 물은 균일하게 퍼진다고 가정합니다.</p><div class="table-wrap small-table"><table><caption><b>보충 표 S2.</b> 실측 보정 전의 입력 가정</caption><thead><tr><th>입력</th><th>값</th><th>의미</th></tr></thead><tbody><tr><td>초기 질량 M₀</td><td>100mg/m²/면</td><td>모든 면의 동일한 통제 조건</td></tr><tr><td>강부착분율 f</td><td>0.20 / 0.70</td><td>약한 / 강한 부착 우세 시나리오</td></tr><tr><td>약한 먼지 세척 계수 kₗ</td><td>0.25mm⁻¹</td><td>가정값; 실험에서 추정해야 함</td></tr><tr><td>강한 먼지 세척 계수 kᵦ</td><td>0.015mm⁻¹</td><td>더 느리게 제거되는 가정값</td></tr><tr><td>계수 민감도</td><td>두 계수 동시 ×0.5, 1, 2</td><td>확률·신뢰구간이 아닌 가정 범위</td></tr><tr><td>강우량</td><td>0, 0.5, 2, 5, 10, 20, 40mm</td><td>한 번의 강우 사건 누적량</td></tr></tbody></table></div><p>이 단계에서 ‘흡착’은 표면에 남아 쉽게 떨어지지 않는 먼지를 뜻하는 <strong>유효 부착 분율</strong>로 표현했습니다. 분자 수준의 흡착력·접촉각·모세관력·젖었다 마르며 굳는 과정 자체를 계산한 것은 아닙니다. 세척 계수와 분율은 문헌에서 가져온 보편 상수가 아닙니다.</p></section>
<section class="section"><h2>05 무엇을 검증했고, 무엇이 남았는가</h2><p>모든 입자 실행에서 유입 = 앞면 + 뒷면 + 지면 + 이탈을 확인했고, 물 부피와 제거 전후 먼지 질량의 수지를 점검했습니다. 강우 광선 2,560개를 독립 NumPy 교차 계산과 대조했습니다. 무풍 경사면의 수신 강우량 cos30°, 동풍 수직면의 속도비 3/5와도 비교했습니다. GPU 세척식과 NumPy 식의 최대 차이는 0.000014mg/m² 미만입니다.</p><p>동풍·10mm·약한 부착·앞면 조건에서 입자 수를 50만에서 200만으로 늘린 점검은 잔류율 차이가 수직형 0.24%p, 경사형 0.19%p 미만이었습니다. 이는 선택한 두 조건의 수치 점검이며 모든 조건의 수렴이나 물리적 정확도를 보증하지 않습니다.</p><p>직접 비가 안 닿는 면은 이 모델에서 세척되지 않습니다. 실제로는 가장자리로 흐르는 물, 비산·튐, 난류, 재부착, 빗물 속 먼지, 물막과 배수 경로가 영향을 줄 수 있습니다. 강우 <strong>강도</strong>와 지속시간을 별도로 모델링하지 않아 같은 누적 강우량이면 같은 결과입니다. 짧은 약한 비가 오염을 더 굳히는 과정을 예측하려면 습윤·건조 이력과 부착력 실험이 추가로 필요합니다.</p><p>질량→광투과율→양면 출력의 보정 관계가 없으므로, 위 36%나 27%를 발전 손실률로 읽으면 안 됩니다. 다음 실험에서는 동일 먼지의 도포량·입경·조성, 강우 강도·풍향, 세척 전후 질량 및 앞·뒷면 광투과율을 함께 측정하고 계수를 추정해야 합니다.</p></section>
<section class="section"><h2>06 이전 건식 침착 시험과의 관계</h2><p>아래는 강우 전 단계에 해당하는 기존 건식 첫 충돌 시험입니다. 먼지 농도 100µg/m³, 침강속도 0.01m/s, 수평 풍속 1m/s, 노출 1시간과 충돌 시 완전부착을 가정했습니다. 30회·1,500만 입자를 계산했으며, 이번 통제 강우 실험의 초기 100mg/m²와는 별도 조건입니다.</p><figure><a href="figures/figS1_warp_interception.svg"><img src="figures/figS1_warp_interception.svg" alt="기존 건식 시험의 풍향별 앞면·뒷면 먼지 포획 질량"></a><figcaption><b>보충 그림 S1.</b> 기존 건식 충돌 시험. 오차막대는 난수 시드 3개의 Monte Carlo 표준편차로 현장 불확실성이 아닙니다. 무풍 수직면의 0은 직선 궤적의 결과이며 무오염의 증거가 아닙니다. <a href="figures/figS1_warp_interception.pdf">PDF</a> · <a href="data/warp_soiling_results.csv">건식 CSV</a></figcaption></figure></section>
<section class="section"><h2>07 자료와 재현</h2><div class="data-links"><a href="data/warp_soiling_pilot.zip" download>건식·강우 코드와 전체 결과 ZIP</a><a href="data/rain_results.csv" download>강우·부착 결과 CSV</a><a href="data/rain_exposure.csv" download>표면 강우량 CSV</a><a href="data/rain_config.json">가정 입력</a><a href="data/rain_validation.json">GPU 검증 기록</a></div><p>ZIP에는 모듈 기하, 건식·강우 실행 코드, 설정, 결과와 검증 기록을 제공합니다. 비교 표는 3개 난수 시드의 평균이며, 페이지는 저장된 계산 결과를 조회합니다. 재현 방법과 실행 환경은 ZIP의 README에 있습니다.</p></section>
<section class="section"><h2>08 문헌과 적용 범위</h2><ol class="refs"><li>IEA PVPS Task 13. <a href="https://iea-pvps.org/key-topics/soiling-losses-impact-on-the-performance-of-photovoltaic-power-plants/">Soiling Losses – Impact on the Performance of Photovoltaic Power Plants</a> (T13-21:2022). <a href="https://iea-pvps.org/wp-content/uploads/2023/01/IEA-PVPS-T13-21-2022-EXEC-SUMM-Soiling-Losses-PV-Plants.pdf">공식 요약</a>은 수분에 의한 고착·모세관 노화·뭉침과 현장별 보정의 중요성을 설명합니다. 본 시험의 부착 분율이나 세척 계수의 수치 근거로 사용하지 않았습니다.</li><li>Sandia PVPMC. <a href="https://pvpmc.sandia.gov/modeling-guide/1-weather-design-inputs/shading-soiling-and-reflection-losses/soiling-losses/hsu-soiling-model/">HSU Soiling Model</a>. 먼지 축적 질량과 세척 사건을 다루는 기존 방법의 비교 배경입니다. 여기서는 HSU 광학식을 적용하거나 세척 시 질량을 일괄 0으로 초기화하지 않았습니다.</li><li>NVIDIA. <a href="https://nvidia.github.io/warp/v1.17/language_reference/_generated/warp.mesh_query_ray.html">Warp 1.17 mesh_query_ray</a>. 기하의 첫 교차점 계산에 사용한 공식 기능 문서입니다.</li></ol></section><footer>VERTICAL PV RESEARCH · 보충 방법 v0.4 · 2026.09.25<br>계산 구현 검증 완료 · 현장 물리 검증 전</footer></main><script id="rain-data" type="application/json">__DATA__</script></body></html>'''
for key,val in {'__VL__':f'{vl:.1f}','__TL__':f'{tl:.1f}','__VB__':f'{vb:.1f}','__TB__':f'{tb:.1f}','__ROWS__':rows,'__DATA__':json.dumps(records,separators=(',',':'))}.items():page=page.replace(key,val)
(DIST/'warp-soiling.html').write_text(page,encoding='utf-8')

readme='''# NVIDIA Warp 건식 충돌 및 강우·부착 먼지 비교

## 재현
Python 3.12, NVIDIA Warp 1.17.0, NumPy 2.5.3. NVIDIA CUDA GPU가 필요하다.
`python -m pip install -r requirements.txt`
`python pilot.py` : 기존 건식 입자 시험. 결과는 results.csv, validation.json.
`python rain.py` : rain_config.json을 읽는 강우·부착 시험. 결과는 rain_results.csv, rain_exposure.csv, rain_validation.json.
실행 전 기존 결과를 보관한다. geometry.py와 pilot.py를 rain.py 옆에 둔다.

## 건식 시험
1만㎡ 부지의 모듈 기하, 100µg/m³, 바람 1m/s, 침강 0.01m/s, 1시간, 첫 충돌 완전부착 가정. 50만 입자 × 5개 풍향 × 2개 배치 × 3시드 = 1,500만 입자. 표본 오차는 실측 불확실성이 아니다. CFD·난류·재비산·입경별 물리와 광학 보정이 없다. 무풍 수직면 0은 이상화된 직선 궤적의 결과이다.

## 강우 시험
모든 면의 초기 먼지 100mg/m²를 동일하게 둔 통제 비교이며 건식 시험 결과의 누적이 아니다. 낙하속도 5m/s, 수평속도 3m/s(무풍 대조 포함), 누적 수평 강우 0–40mm. 50만 물 계산 입자 × 5방향 × 2배치 × 3시드 = 1,500만, 수렴 점검 400만 추가. RTX 4080 Laptop GPU에서 실행했다. 입자는 물 부피를 대표하며 실제 빗방울 개수·크기가 아니다.

수평 강우 1mm에서 총 유입 물량은 sum(inflow_area * normal_velocity) / downward_velocity L이다. 면별 충돌 계수로 배분하고 모듈 한 면 2.42m²로 나누어 직접 수신 강우 R(mm)를 구한다. 각 모듈 면에서 M_after = M0[(1-f)exp(-k_loose R) + f exp(-k_bound R)]를 적용한 후 평균한다. 한 모듈 면 내 균일 혼합을 가정한다.

f=0.2,0.7 / k_loose=0.25mm^-1 / k_bound=0.015mm^-1은 모두 예시 가정이며 실측·문헌 추정값이 아니다. 두 계수를 동시에 0.5,1,2배 바꾼 가정 민감도를 제공한다. 통계 신뢰구간이 아니다. rain_results.csv의 2,520행은 풍향·배치·면·강우량·부착·계수·시드 조합이고 별도 GPU 광선 실행 수가 아니다.

입자·물·먼지 수지, 무강우/무노출 보존, 비음수, 강우량·부착분율 단조성, 독립 NumPy 식과 광선 2,560개, 해석적 노출량을 점검했다. 50만→200만 표본 비교는 동풍 10mm 약한 부착 앞면 두 조건에 한정한다. 결과와 허용 오차는 rain_validation.json에 있다.

## 적용 한계
실측 검증 전의 가정 실험이다. '흡착'은 유효 부착분율로만 나타낸다. 분자 흡착, 기류장, 난류, 충돌 변형·튐, 물막·유출·가장자리 이동, 강우 중 먼지 유입, 습윤·건조 고착 동역학을 풀지 않는다. 강우 강도와 시간은 별도로 구분하지 않으므로 같은 누적 강우량이면 같은 결과다. 직접 비가 안 닿은 면의 잔류 100%는 모델 제한이다. 연간 기상·실측 침착과 연결하지 않았고, 잔류 먼지 %는 발전 손실 %가 아니다. 본문 발전량·ESS 비용은 변경하지 않았다.

## 근거
IEA PVPS T13-21:2022: https://iea-pvps.org/key-topics/soiling-losses-impact-on-the-performance-of-photovoltaic-power-plants/
Sandia HSU model: https://pvpmc.sandia.gov/modeling-guide/1-weather-design-inputs/shading-soiling-and-reflection-losses/soiling-losses/hsu-soiling-model/
Warp ray API: https://nvidia.github.io/warp/v1.17/language_reference/_generated/warp.mesh_query_ray.html
문헌은 모델 설계의 배경이며 가정 계수의 수치 근거가 아니다.
'''
(ROOT/'README.md').write_text(readme,encoding='utf-8')

print('Generated rain figure and comparison page in generated_site. Install pandas and matplotlib in addition to requirements.txt. Copy paper.css, rain-comparison.css/js, and figS1 from the published site for full presentation.')
