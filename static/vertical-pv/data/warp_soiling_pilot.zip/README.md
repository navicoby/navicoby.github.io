# NVIDIA Warp 건식 충돌 및 강우·부착 먼지 비교

## 재현
Python 3.12, NVIDIA Warp 1.17.0, NumPy 2.5.3. NVIDIA CUDA GPU가 필요하다.
`python -m pip install -r requirements.txt`
`python pilot.py` : 기존 건식 입자 시험. 결과는 results.csv, validation.json.
`python rain.py` : rain_config.json을 읽는 강우·부착 시험. 결과는 rain_results.csv, rain_exposure.csv, rain_validation.json.
실행 전 기존 결과를 보관한다. geometry.py와 pilot.py를 rain.py 옆에 둔다.

## 건식 시험
1만㎡ 부지의 모듈 기하, 100µg/m³, 바람 1m/s, 침강 0.01m/s, 1시간, 첫 충돌 완전부착 가정. 50만 입자 × 5개 풍향 × 2개 배치 × 3시드 = 1,500만 입자. 표본 오차는 실측 불확실성이 아니다. CFD·난류·재비산·입경별 물리와 광학 보정이 없다. 무풍 수직면 0은 이상화된 직선 궤적의 결과이다.

## 강우 시험
경사형은 단면(후면 발전 0), 수직형은 양면(후면계수 0.8)이다. 뒷면 먼지량은 단면형의 발전량을 의미하지 않는다. 기하가 같아 강우·먼지 충돌 결과 자체는 모듈 형식 수정으로 바뀌지 않는다. 모든 면의 초기 먼지 100mg/m²를 동일하게 둔 통제 비교이며 건식 시험 결과의 누적이 아니다. 낙하속도 5m/s, 수평속도 3m/s(무풍 대조 포함), 누적 수평 강우 0–40mm. 50만 물 계산 입자 × 5방향 × 2배치 × 3시드 = 1,500만, 수렴 점검 400만 추가. RTX 4080 Laptop GPU에서 실행했다. 입자는 물 부피를 대표하며 실제 빗방울 개수·크기가 아니다.

수평 강우 1mm에서 총 유입 물량은 sum(inflow_area * normal_velocity) / downward_velocity L이다. 면별 충돌 계수로 배분하고 모듈 한 면 2.42m²로 나누어 직접 수신 강우 R(mm)를 구한다. 각 모듈 면에서 M_after = M0[(1-f)exp(-k_loose R) + f exp(-k_bound R)]를 적용한 후 평균한다. 한 모듈 면 내 균일 혼합을 가정한다.

f=0.2,0.7 / k_loose=0.25mm^-1 / k_bound=0.015mm^-1은 모두 예시 가정이며 실측·문헌 추정값이 아니다. 두 계수를 동시에 0.5,1,2배 바꾼 가정 민감도를 제공한다. 통계 신뢰구간이 아니다. rain_results.csv의 2,520행은 풍향·배치·면·강우량·부착·계수·시드 조합이고 별도 GPU 광선 실행 수가 아니다.

입자·물·먼지 수지, 무강우/무노출 보존, 비음수, 강우량·부착분율 단조성, 독립 NumPy 식과 광선 2,560개, 해석적 노출량을 점검했다. 50만→200만 표본 비교는 동풍 10mm 약한 부착 앞면 두 조건에 한정한다. 결과와 허용 오차는 rain_validation.json에 있다.

## 적용 한계
실측 검증 전의 가정 실험이다. '흡착'은 유효 부착분율로만 나타낸다. 분자 흡착, 기류장, 난류, 충돌 변형·튐, 물막·유출·가장자리 이동, 강우 중 먼지 유입, 습윤·건조 고착 동역학을 풀지 않는다. 강우 강도와 시간은 별도로 구분하지 않으므로 같은 누적 강우량이면 같은 결과다. 직접 비가 안 닿은 면의 잔류 100%는 모델 제한이다. 연간 기상·실측 침착과 연결하지 않았고, 잔류 먼지 %는 발전 손실 %가 아니다. 본문 발전량·ESS 비용은 변경하지 않았다.

## 근거
IEA PVPS T13-21:2022: https://iea-pvps.org/key-topics/soiling-losses-impact-on-the-performance-of-photovoltaic-power-plants/
Sandia HSU model: https://pvpmc.sandia.gov/modeling-guide/1-weather-design-inputs/shading-soiling-and-reflection-losses/soiling-losses/hsu-soiling-model/
Warp ray API: https://nvidia.github.io/warp/v1.17/language_reference/_generated/warp.mesh_query_ray.html
문헌은 모델 설계의 배경이며 가정 계수의 수치 근거가 아니다.
