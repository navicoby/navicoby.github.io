Figure 1: conceptual geometry from parameters, not measured structures.
Figure 2: baseline.csv and hourly_mean_ac.csv (AC kW per kWp, KST hour bin).
Figure 3: spacing.csv; vertical rows plus tilted_reference only.
Figures 4-5: site_10000m2.csv and site_10000m2_parameters.json. Bird-eye views use actual module polygons; finite counts times infinite-row AC yield.
Figure 6: orientation_costs.csv and tenure_candidates.csv, a separate small-load scenario.
All results are modelled. No measured uncertainties or field validation.
