Source tables for current v0.7 figures. Common conditions and scope: study_v07.json, audit_v07.json. Full code: v07_reproducible.zip.
