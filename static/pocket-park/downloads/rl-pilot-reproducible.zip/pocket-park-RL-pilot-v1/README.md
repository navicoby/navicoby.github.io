# 소공원 자원·강화학습 예비실험

Python 3.11 환경에서 requirements.txt를 설치한 뒤 run_pilot.py를 실행한다.
결과 폴더에 summary.json이 있으면 덮어쓰지 않고 중단한다. 새 폴더에 소스·configs·data만 복사해 재현한다.
configs/parameters.json은 변수 정의, run_pilot.py의 CASES는 실제 시험한 9개 자원 조합이다.
웹에서 저장한 설정은 자동 실행되지 않는다. 별도 조합으로 CASES에 추가한 뒤 모든 정책에 동일하게 적용해야 한다.
학습은 NumPy로 구현한 마스킹 선형 REINFORCE이다. PPO나 심층 신경망을 사용하지 않았다.
비용·물리 시뮬레이션을 수행하지 않았다. 62개 작업의 경계석 분할과 토공반 인원 미확정 등 limitations를 반드시 확인한다.
기준 QGIS/IFC는 상위 소공원 웹페이지에서 내려받을 수 있다. 새 자원 조건의 공기는 기존 IFC 작업시간을 덮어쓰지 않는다.
