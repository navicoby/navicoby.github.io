"""Bounded, reproducible resource sensitivity and masked REINFORCE pilot."""
from pathlib import Path
import sys, json, copy, csv, hashlib, sqlite3, time
import numpy as np
import networkx as nx

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from parksim.simulator import simulate, audit, POLICIES
from parksim.common import config, dump, digest
from parksim import common, scenarios, simulator

# Read-only configuration cache; all experimental capacities are explicit.
C=config()
simulator.config=lambda:copy.deepcopy(C)
scenarios.config=lambda:copy.deepcopy(C)
TASKS=json.loads((ROOT/'data/tasks_wbs.json').read_text(encoding='utf-8'))
PARAM=json.loads((ROOT/'configs/parameters.json').read_text(encoding='utf-8'))
DEFAULT={p['key']:p['default'] for p in PARAM['parameters']}
CASES=[
 ('P0','기본 자원',{}),
 ('P1','굴삭기만 2대',{'excavators':2}),
 ('P2','토공반·굴삭기·차량 각 2',{'excavators':2,'earth_teams':2,'trucks':2}),
 ('P3','식재반 2개',{'landscape_teams':2,'landscapers':6,'general_workers':8}),
 ('P4','포장반 2개',{'paving_teams':2,'pavers':6,'special_workers':6,'general_workers':8,'excavators':2,'compactors':2}),
 ('P5','평떼 2개 조 / 10명',{'turf_gangs':2,'general_workers':8}),
 ('P6','평떼 3개 조 / 15명',{'turf_gangs':3,'general_workers':12}),
 ('P7','복수 작업반·굴삭기 2대',{'excavators':2,'earth_teams':2,'landscape_teams':2,'paving_teams':2,'turf_gangs':2,'landscapers':6,'general_workers':8,'special_workers':6,'pavers':6,'trucks':2,'compactors':2}),
 ('P8','동시 작업 최대 2건',{'workfronts':2})
]
CONTEXTS=['P0','P7']
FEATURES=['duration','tail','successors','excavator','labor','heavy','zone_A','zone_B','zone_C','zone_D','turf','shrubs','paving','closure','remaining_day_fit','resource_pressure','completed_fraction_x_tail']

def case_model(case_id):
    case=next(x for x in CASES if x[0]==case_id)
    p={**DEFAULT,**case[2]}
    caps=copy.deepcopy(C['resources'])
    mapping={'excavators':'excavator','earth_teams':'earth_crew','landscapers':'crew_landscaper','general_workers':'crew_general','special_workers':'crew_special','pavers':'crew_paver','trucks':'truck','compactors':'plate_compactor','landscape_teams':'planting_team','paving_teams':'paving_team','turf_gangs':'turf_team','workfronts':'workfront'}
    for key,res in mapping.items(): caps[res]=p[key]
    tasks=copy.deepcopy(TASKS)
    for t in tasks:
        b=t['required_resource_bundle']; a=t['activity_type']
        b['workfront']=1
        if a in ('curb','subbase','finish'): b['paving_team']=1
        elif a=='turf': b['turf_team']=1
        elif a in ('soil','trees','shrubs','mulch','bench','pergola'): b['planting_team']=1
    return tasks,caps,p

MODELS={cid:case_model(cid) for cid,_,_ in CASES}

class Policy:
    def __init__(self,tasks,theta=None,seed=0,greedy=False,uniform=False):
        self.theta=np.zeros(len(FEATURES)) if theta is None else np.array(theta,dtype=float)
        self.rng=np.random.default_rng(seed); self.greedy=greedy; self.uniform=uniform
        g=nx.DiGraph();g.add_nodes_from(t['task_id'] for t in tasks)
        g.add_edges_from((p,t['task_id']) for t in tasks for p in t['predecessors'])
        self.desc={t['task_id']:len(nx.descendants(g,t['task_id'])) for t in tasks}
        self.n=len(tasks); self.grad=np.zeros(len(FEATURES)); self.decisions=[]
    def features(self,t,state):
        duration=t['quantity']/t['productivity']+t.get('fixed_setup_time',0)+t.get('travel_hours',0)
        b=t['required_resource_bundle']; a=t['activity_type']; z=t['zone_id']
        h=(state['now']+8)%24; available=max(0,(12 if h<12 else 17)-h)
        labor=sum(n for r,n in b.items() if r.startswith('crew_'))
        pressure=max((n/max(1,state['capacities'][r]-state['used'].get(r,0)) for r,n in b.items()),default=0)
        tail=state['tail'][t['task_id']]/160
        return np.array([duration/32,tail,self.desc[t['task_id']]/self.n,
            b.get('excavator',0),labor/12,int(bool(t.get('heavy'))),
            *[int(z==zone) for zone in 'ABCD'],int(a=='turf'),int(a=='shrubs'),
            int(a in ('subbase','finish','curb')),int(bool(t.get('closes'))),
            min(2,duration/max(0.5,available))/2,pressure,len(state['done_ids'])/self.n*tail],dtype=float)
    def __call__(self,eligible,state):
        x=np.array([self.features(t,state) for t in eligible])
        scores=x@self.theta
        if self.uniform:scores[:]=0
        probs=np.exp(scores-scores.max());probs/=probs.sum()
        k=int(np.argmax(scores)) if self.greedy else int(self.rng.choice(len(eligible),p=probs))
        self.grad+=x[k]-probs@x
        if len(eligible)>1:self.decisions.append({'hour':state['now'],'candidates':[t['task_id'] for t in eligible],'chosen':eligible[k]['task_id']})
        return eligible[k]['task_id']

def count_runs():
    p=ROOT/'results/budget.sqlite'
    if not p.exists(): return 0
    with sqlite3.connect(p) as db:return db.execute('SELECT count(*) FROM attempts').fetchone()[0]

def run(cid,policy,sid,controller=None,detail=False):
    if count_runs()>=PARAM['campaign_run_cap']:raise RuntimeError('Campaign run budget exceeded')
    tasks,caps,_=MODELS[cid]
    r=simulate(tasks,policy=policy,scenario_id=str(sid),capacities=caps,dispatcher=controller,detail=detail)
    if r['status']!='COMPLETED':raise RuntimeError(f'{cid}/{policy}/{sid}: {r["status"]} {r["reason"]}')
    if detail:
        errors=audit(r,tasks,caps)
        if errors:raise AssertionError(errors)
        r['audit_errors']=errors
    r['case_id']=cid
    return r

def save_csv(path,rows):
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def verify():
    """Regression and an adversarial feasible-action fixture, not tautological tests."""
    legacy=simulate(TASKS,policy='B1_ZONE',detail=True)
    assert abs(legacy['elapsed_hours']/24-51.0694589773588)<0.0001, legacy['elapsed_hours']/24
    assert not audit(legacy,TASKS,C['resources'])
    parameterized=run('P0','B1_ZONE','deterministic',detail=True)
    # An invalid action must be rejected and recorded as an error.
    bad=simulate(TASKS,policy='RL_TEST',dispatcher=lambda e,s:'not_a_task',detail=False)
    assert bad['status']=='ERROR' and 'masked action' in bad['reason']
    fixture=copy.deepcopy(TASKS[0]);fixture.update(quantity=4,productivity=1,predecessors=[],lag=0,predecessor_lags={},travel_hours=0,fixed_setup_time=0,material_release_hour=0,heavy=False,closes=None,required_resource_bundle={'excavator':1},work_zones=['A'],zone_id='A',task_id='first')
    other=copy.deepcopy(fixture);other.update(task_id='second',zone_id='B',work_zones=['B'])
    caps=copy.deepcopy(C['resources'])
    one=simulate([fixture,other],capacities=caps,use_calendar=False,detail=True)
    caps['excavator']=2
    two=simulate([fixture,other],capacities=caps,use_calendar=False,detail=True)
    assert one['elapsed_hours']==8 and two['elapsed_hours']==4
    assert not audit(two,[fixture,other],caps)
    other['work_zones']=['A'];other['zone_id']='A'
    shared=simulate([fixture,other],capacities=caps,use_calendar=False,detail=True)
    assert shared['elapsed_hours']==8
    # Check analytic softmax score gradient against finite differences.
    x=np.array([[0.2,0.7],[-0.4,0.3],[0.5,-0.1]]);theta=np.array([0.3,-0.2]);k=1
    def logp(w):
        z=x@w;return z[k]-np.log(np.exp(z).sum())
    p=np.exp(x@theta);p/=p.sum();analytic=x[k]-p@x
    numerical=np.array([(logp(theta+np.eye(2)[j]*1e-6)-logp(theta-np.eye(2)[j]*1e-6))/2e-6 for j in range(2)])
    assert np.allclose(analytic,numerical,atol=1e-7)
    seeds=PARAM['seeds'];assert not(set(seeds['train'])&set(seeds['validation']) or set(seeds['train'])&set(seeds['test']) or set(seeds['validation'])&set(seeds['test']))
    report={'status':'PASS','legacy_B1_days':legacy['elapsed_hours']/24,'parameterized_B1_days':parameterized['elapsed_hours']/24,'baseline_task_hash':digest(TASKS),'legacy_regression':True,'invalid_action_rejected':True,'excavator_1_vs_2_fixture_hours':[8,4],'same_zone_exclusion':True,'policy_gradient_finite_difference':True,'seed_splits_disjoint':True}
    dump(ROOT/'validation/pilot-tests.json',report)
    print(json.dumps(report),flush=True)

def experiment():
    assert not (ROOT/'results/summary.json').exists(),'Preserve completed experiment.'
    verify()
    started=time.perf_counter(); seed=PARAM['seeds']; algo=PARAM['algorithm']
    # Precomputed comparator returns are used only as a reward baseline, never as policy observations.
    controls={}
    for cid in CONTEXTS:
        for sid in seed['train']:controls[cid,sid]=run(cid,'B2_READY',sid)['elapsed_hours']/24
    learned=[];training=[];validation=[]
    for init in seed['policy_initialization']:
        rng=np.random.default_rng(init);theta=rng.normal(0,.02,len(FEATURES));m=np.zeros_like(theta);v=m.copy(); best=None
        for epoch in range(1,algo['epochs']+1):
            gradients=[];rewards=[]
            for ep in range(algo['episodes_per_epoch']):
                cid=CONTEXTS[(epoch+ep)%len(CONTEXTS)];sid=seed['train'][int(rng.integers(len(seed['train'])))]
                policy=Policy(MODELS[cid][0],theta,seed=int(rng.integers(2**31)))
                r=run(cid,'RL_REINFORCE',sid,policy)
                advantage=(controls[cid,sid]-r['elapsed_hours']/24)/10
                gradients.append(advantage*policy.grad);rewards.append(advantage)
            grad=np.mean(gradients,axis=0);grad*=min(1,5/max(1e-12,np.linalg.norm(grad)))
            m=.9*m+.1*grad;v=.999*v+.001*grad*grad
            theta+=algo['learning_rate']*(m/(1-.9**epoch))/(np.sqrt(v/(1-.999**epoch))+1e-8)
            training.append({'seed':init,'epoch':epoch,'mean_advantage_over_B2_div10':float(np.mean(rewards)),'weight_norm':float(np.linalg.norm(theta))})
            if epoch in algo['checkpoint_epochs']:
                days=[]
                for cid in CONTEXTS:
                    for sid in seed['validation']:
                        r=run(cid,'RL_REINFORCE',sid,Policy(MODELS[cid][0],theta,greedy=True))
                        days.append(r['elapsed_hours']/24)
                score=float(np.mean(days));validation.append({'seed':init,'epoch':epoch,'mean_days':score})
                if best is None or score<best['validation_days']:best={'seed':init,'epoch':epoch,'validation_days':score,'theta':theta.tolist()}
                print(f'Train seed {init}: epoch {epoch}, validation {score:.3f} days; runs {count_runs()}',flush=True)
        learned.append(best)
    save_csv(ROOT/'results/training.csv',training);save_csv(ROOT/'results/validation.csv',validation)
    dump(ROOT/'results/policies.json',{'features':FEATURES,'policies':learned,'selected_seed':min(learned,key=lambda x:x['validation_days'])['seed']})
    # Test every training seed, rather than reporting a lucky seed alone.
    records=[]
    for cid in CONTEXTS:
        for sid in seed['test']:
            paired=[]
            choices=[(p,None) for p in POLICIES]+[('RANDOM_FEASIBLE',Policy(MODELS[cid][0],seed=sid,uniform=True))]
            choices += [('RL_SEED_'+str(p['seed']),Policy(MODELS[cid][0],p['theta'],greedy=True)) for p in learned]
            for label,controller in choices:
                r=run(cid,label,sid,controller,detail=True);paired.append(r['scenario_fingerprint'])
                row={'case_id':cid,'scenario_id':sid,'policy':label,'days':r['elapsed_hours']/24,'fingerprint':r['scenario_fingerprint'],'audit_errors':len(r['audit_errors']),'excavator_busy_hours':r['busy_hours'].get('excavator',0),'paid_shift_hours':r['paid_resource_hours']}
                records.append(row)
                if sid==seed['test'][0]:dump(ROOT/f'results/example-{cid}-{label}.json',r)
            assert len(set(paired))==1
        print(f'Test {cid} complete; runs {count_runs()}',flush=True)
    save_csv(ROOT/'results/test.csv',records)
    # Resource comparisons have a separate scenario namespace, and a fixed rule.
    sensitivity=[]
    for cid,label,_ in CASES:
        for sid in ['deterministic',*range(61000,61008)]:
            r=run(cid,'B2_READY',sid,detail=True)
            sensitivity.append({'case_id':cid,'label':label,'scenario':sid,'days':r['elapsed_hours']/24,'fingerprint':r['scenario_fingerprint'],'audit_errors':0})
    save_csv(ROOT/'results/resource-sensitivity.csv',sensitivity)
    for sid in ['deterministic',*range(61000,61008)]:assert len({r['fingerprint'] for r in sensitivity if r['scenario']==sid})==1
    stats=[];best_seed=min(learned,key=lambda p:p['validation_days'])['seed']
    rng=np.random.default_rng(70001)
    for cid in CONTEXTS:
        by={p:[r['days'] for r in records if r['case_id']==cid and r['policy']==p] for p in [*POLICIES,'RANDOM_FEASIBLE',*[f'RL_SEED_{p["seed"]}' for p in learned]]}
        # Descriptive best rule on held-out data, explicitly labelled post hoc.
        best_rule=min(POLICIES,key=lambda p:np.mean(by[p]))
        chosen=f'RL_SEED_{best_seed}';delta=np.array(by[best_rule])-np.array(by[chosen])
        bootstrap=np.mean(rng.choice(delta,(4000,len(delta)),replace=True),axis=1)
        stats.append({'case_id':cid,'mean_days':{p:float(np.mean(v)) for p,v in by.items()},'selected_by_validation':chosen,'descriptive_best_rule':best_rule,'selected_rl_saving_days_vs_best_rule':float(delta.mean()),'paired_bootstrap_95ci_saving_days':[float(x) for x in np.quantile(bootstrap,[.025,.975])],'all_training_seeds_mean_days':float(np.mean([by[f'RL_SEED_{p["seed"]}'] for p in learned]))})
    summary={'status':'COMPLETED_PRELIMINARY','task_count':len(TASKS),'algorithm':algo,'parameters':PARAM,'resource_cases':[{'case_id':cid,'label':label,'values':MODELS[cid][2]} for cid,label,_ in CASES],'test_statistics':stats,'resource_statistics':[{'case_id':cid,'label':label,'deterministic_days':next(r['days'] for r in sensitivity if r['case_id']==cid and r['scenario']=='deterministic'),'mean_stochastic_days':float(np.mean([r['days'] for r in sensitivity if r['case_id']==cid and r['scenario']!='deterministic']))} for cid,label,_ in CASES],'runs':count_runs(),'wall_seconds':time.perf_counter()-started,'all_test_and_sensitivity_audits_passed':True,'paired_scenarios_verified':True,'cost_optimized':False,'physical_simulation_executed':False,'limitations':['Synthetic site; weather and productivity distributions uncalibrated','Linear policy, three seeds, small holdout; no global optimum claim','62-task reference retains four curb tasks; whole-site curb revision is separate','Earthwork crew headcount unspecified; staffing totals exclude that abstract crew','Equipment size and physical access, pipe grade, storage and turning radii unverified','No same-zone cooperative speedup; task productivity not multiplied by crew counts']}
    dump(ROOT/'results/summary.json',summary)
    print(json.dumps({'runs':summary['runs'],'statistics':stats,'resource_statistics':summary['resource_statistics']},ensure_ascii=True),flush=True)

if __name__=='__main__':
    if '--verify' in sys.argv:verify()
    else:experiment()
