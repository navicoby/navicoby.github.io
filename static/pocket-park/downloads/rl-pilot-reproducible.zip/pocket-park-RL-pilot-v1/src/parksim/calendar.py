import math

def working(t):
    day=math.floor((t+8)/24)
    h=(t+8)%24
    return day%7<5 and (8<=h<12 or 13<=h<17)

def boundary(t):
    day=math.floor((t+8)/24)
    possible=[d*24+h-8 for d in range(day,day+9) if d%7<5 for h in (8,12,13,17)]
    return min(x for x in possible if x>t+1e-8)

def paid_hours_until(t):
    # Resources retained on every weekday, including paid idle time and rain.
    return sum(8 for d in range(math.floor((t+8)/24)+1) if d%7<5)
