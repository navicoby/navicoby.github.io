import hashlib
import math
import numpy as np
from .common import config

def random_for(scenario,key):
    seed=int.from_bytes(hashlib.sha256(f"parksim-v1/{scenario}/{key}".encode()).digest()[:8],"big")
    return np.random.default_rng(seed)

class Scenario:
    def __init__(self, scenario_id="deterministic", rain_intervals=None):
        self.id=str(scenario_id)
        self.deterministic=self.id=="deterministic"
        self.intervals=rain_intervals
        self.c=config()
        self._factors={}
        self._releases={}
        self._weather={}
    def factor(self, task_id):
        if self.deterministic:return 1.0
        if task_id not in self._factors:
            a,b=self.c["lognormal_common_sigma"],self.c["lognormal_task_sigma"]
            self._factors[task_id]=float(random_for(self.id,"common").lognormal(-a*a/2,a)*random_for(self.id,"task/"+task_id).lognormal(-b*b/2,b))
        return self._factors[task_id]
    def release(self,task):
        base=task.get("material_release_hour",0)
        if self.deterministic or base==0:return base
        key=(task["activity_type"],base)
        if key not in self._releases:self._releases[key]=base+float(random_for(self.id,"material/"+task["activity_type"]).triangular(0,8,32))
        return self._releases[key]
    def rainy(self,t):
        if self.intervals is not None:return any(a<=t<b for a,b in self.intervals)
        if self.deterministic:return False
        day=math.floor((t+8)/24)
        if day not in self._weather:self._weather[day]=bool(random_for(self.id,"weather/"+str(day)).random()<self.c["rain_probability_per_day"])
        return self._weather[day]
    def weather_boundary(self,t):
        if self.intervals is not None:
            return min([x for ab in self.intervals for x in ab if x>t+1e-8],default=math.inf)
        return (math.floor((t+8)/24)+1)*24-8
