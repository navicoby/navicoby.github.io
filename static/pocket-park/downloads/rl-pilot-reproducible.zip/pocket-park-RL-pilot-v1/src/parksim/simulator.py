"""SimPy event-driven central dispatcher with atomic resource bundles.

Time advances only at completion, work-calendar, weather, release and lag events.
Zone occupancy persists while work is suspended. Resource hire is charged for
whole retained shifts, while allocation is released outside working periods.
"""
import math
from collections import Counter, defaultdict
import networkx as nx
import simpy
from . import calendar
from .common import config, digest
from .scenarios import Scenario

EPS=1e-8
POLICIES=("B0_STAGE","B1_ZONE","B2_READY")

def validate_tasks(tasks,capacities):
    by={t["task_id"]:t for t in tasks}
    if len(by)!=len(tasks):raise ValueError("중복 작업 ID")
    graph=nx.DiGraph()
    graph.add_nodes_from(by)
    for t in tasks:
        if t["quantity"]<0 or not math.isfinite(t["quantity"]):raise ValueError("음수 또는 비유한 물량")
        if t["productivity"]<=0 or not math.isfinite(t["productivity"]):raise ValueError("생산성 오류")
        if t["productivity_unit"]!=t["unit"]+"/crew_hour":raise ValueError("생산성 단위 불일치")
        for r,n in t["required_resource_bundle"].items():
            if r not in capacities or n<1 or n>capacities[r]:raise ValueError("누락 또는 부족 자원: "+r)
        for p in t["predecessors"]:
            if p not in by:raise ValueError("누락 선행작업")
            graph.add_edge(p,t["task_id"])
    if not nx.is_directed_acyclic_graph(graph):raise ValueError("순환 선후행")
    return graph

def simulate(tasks,policy="B1_ZONE",scenario_id="deterministic",capacities=None,
             use_calendar=True,scenario=None,max_hours=None,max_events=None,detail=True,dispatcher=None):
    c=config()
    caps=capacities or c["resources"]
    if policy not in POLICIES and dispatcher is None:raise ValueError("미지원 정책")
    graph=validate_tasks(tasks,caps)
    from .experiments import reserve_run,finish_run
    budget_attempt=reserve_run(f"{policy}/{scenario_id}")
    scenario=scenario or Scenario(scenario_id)
    env=simpy.Environment()
    by={t["task_id"]:t for t in tasks}
    tail={}
    for tid in reversed(list(nx.topological_sort(graph))):
        t=by[tid]
        tail[tid]=t["quantity"]/t["productivity"]+max([tail[s] for s in graph.successors(tid)],default=0)
    remaining={t["task_id"]:t["quantity"]/t["productivity"]/scenario.factor(t["task_id"])+t.get("fixed_setup_time",0) for t in tasks}
    travel={t["task_id"]:t.get("travel_hours",0) for t in tasks}
    done={}; starts={}; owners={}; edges={z:"OPEN" for z in ("trunk","A","B","C","D")}
    events=[]; segments=[]; waits=Counter(); busy=Counter(); n_events=0
    max_hours=max_hours if max_hours is not None else c["max_sim_hours"]
    max_events=max_events if max_events is not None else c["max_events"]
    result={"status":"ERROR"}
    def event(tid,kind,reason="",resources=None):
        if detail:
            t=by.get(tid,{})
            events.append(dict(event_index=len(events),sim_hour=env.now,task_id=tid,event_type=kind,
                resource_ids=resources or [],zone_id=t.get("zone_id","SITE"),
                remaining_quantity=min(t.get("quantity",0),remaining.get(tid,0)*t.get("productivity",0)*scenario.factor(tid)),delay_reason=reason,
                cost_delta_krw=0))
    def rank(t):
        tid=t["task_id"]; zone="ABCD".find(t["zone_id"])
        resume=0 if tid in starts else 1
        if policy=="B0_STAGE":return (resume,t.get("legacy_priority_code",t["wbs_code"]),zone,tid)
        if policy=="B1_ZONE":return (resume,zone,t.get("legacy_priority_code",t["wbs_code"]),tid)
        return (resume,-tail[tid],zone,tid)
    ordered=sorted(tasks,key=lambda t:t["task_id"])
    def dispatch_order(now, is_work, raining, used):
        pending=sorted(ordered,key=rank)
        if dispatcher is None:
            yield from pending
            return
        while pending:
            eligible=[]
            for t in pending:
                tid=t['task_id']; z=t['zone_id']
                if tid in done or not is_work or raining: continue
                if not all(p in done for p in t['predecessors']): continue
                if now+EPS<max([done[p]+t.get('predecessor_lags',{}).get(p,t.get('lag',0)) for p in t['predecessors']],default=0): continue
                if now+EPS<scenario.release(t): continue
                zones=t.get('work_zones',[z])
                if t.get('heavy') and (edges.get('trunk')=='FINISHED_RESTRICTED' or any(edges.get(wz)=='FINISHED_RESTRICTED' for wz in zones)): continue
                if any(wz in owners and owners[wz]!=tid for wz in zones): continue
                bundle=dict(t['required_resource_bundle'])
                if t.get('heavy') and travel[tid]>EPS and 'gate' in caps: bundle['gate']=1
                if any(used[r]+n>caps[r] for r,n in bundle.items()): continue
                eligible.append(t)
            if not eligible:
                yield from pending
                return
            resumed=[t for t in eligible if t['task_id'] in starts]
            if resumed: chosen=resumed[0]
            else:
                # Only static design and presently observed state reach the policy.
                # Actual stochastic duration factors and future weather stay private.
                state={'now':now,'done_ids':tuple(done),'started_ids':tuple(starts),
                       'capacities':dict(caps),'used':dict(used),'tail':tail}
                tid=dispatcher(eligible,state)
                matches=[t for t in eligible if t['task_id']==tid]
                if not matches: raise ValueError('Policy selected a masked action')
                chosen=matches[0]
            pending.remove(chosen)
            yield chosen
    def runner():
        nonlocal n_events
        while len(done)<len(tasks):
            now=env.now
            if now>=max_hours-EPS or n_events>=max_events:
                result.update(status="TIMEOUT",reason="모의기간/사건수 상한")
                break
            # Complete tasks at the exact endpoint, before evaluating the calendar.
            for tid in list(starts):
                if tid not in done and remaining[tid]<=EPS and travel[tid]<=EPS:
                    done[tid]=now
                    z=by[tid]["zone_id"]
                    for wz in by[tid].get("work_zones",[z]):
                        if owners.get(wz)==tid:del owners[wz]
                    if by[tid].get("closes"):edges[by[tid]["closes"]]="FINISHED_RESTRICTED"
                    if tid.endswith("_backfill"):edges[z]="OPEN"
                    event(tid,"COMPLETE")
            if len(done)==len(tasks):
                result.update(status="COMPLETED",reason="")
                break
            is_work=not use_calendar or calendar.working(now)
            raining=scenario.rainy(now)
            allocated=[]; used=Counter(); reasons={}
            for t in dispatch_order(now,is_work,raining,used):
                tid=t["task_id"]; z=t["zone_id"]
                if tid in done:continue
                if not all(p in done for p in t["predecessors"]): reasons[tid]="PREDECESSOR"; continue
                if now+EPS<max([done[p]+t.get("predecessor_lags",{}).get(p,t.get("lag",0)) for p in t["predecessors"]],default=0): reasons[tid]="CURE_OR_LAG"; continue
                if now+EPS<scenario.release(t):reasons[tid]="MATERIAL"; continue
                if not is_work:reasons[tid]="NON_WORK";continue
                if raining:reasons[tid]="RAIN";continue
                if t.get("heavy") and (edges.get("trunk")=="FINISHED_RESTRICTED" or any(edges.get(wz)=="FINISHED_RESTRICTED" for wz in t.get("work_zones",[z]))):
                    result.update(status="INFEASIBLE",reason="유일 장비 접근로 최종 마감: "+tid)
                    event(tid,"BLOCKED","FINISHED_RESTRICTED")
                    return
                if any(wz in owners and owners[wz]!=tid for wz in t.get("work_zones",[z])):reasons[tid]="SPACE";continue
                bundle=dict(t["required_resource_bundle"])
                if t.get("heavy") and travel[tid]>EPS and "gate" in caps:bundle["gate"]=1
                if any(used[r]+n>caps[r] for r,n in bundle.items()):reasons[tid]="RESOURCE_OR_GATE";continue
                if tid not in starts:
                    starts[tid]=now
                    for wz in t.get("work_zones",[z]):owners[wz]=tid
                    event(tid,"START",resources=list(bundle))
                    if tid.endswith("_trench"):edges[z]="TRENCH_OPEN"
                used.update(bundle)
                allocated.append((tid,bundle))
            candidates=[max_hours]
            if use_calendar:candidates.append(calendar.boundary(now))
            weather_edge=scenario.weather_boundary(now)
            if math.isfinite(weather_edge):candidates.append(weather_edge)
            for t in tasks:
                tid=t["task_id"]
                if tid in done:continue
                release=scenario.release(t)
                if release>now+EPS:candidates.append(release)
                if all(p in done for p in t["predecessors"]):
                    lagend=max([done[p]+t.get("predecessor_lags",{}).get(p,t.get("lag",0)) for p in t["predecessors"]],default=0)
                    if lagend>now+EPS:candidates.append(lagend)
            for tid,_ in allocated:candidates.append(now+(travel[tid] if travel[tid]>EPS else remaining[tid]))
            positive=[x for x in candidates if x>now+EPS]
            # A zero-quantity fixture can complete without advancing time.
            if any(travel[tid]<=EPS and remaining[tid]<=EPS for tid,_ in allocated):continue
            if not positive or (not allocated and not use_calendar and not raining and min(positive)==max_hours):
                result.update(status="INFEASIBLE",reason="교착/향후 진행 사건 없음")
                break
            dt=min(positive)-now
            for tid,reason in reasons.items():waits[reason]+=dt
            for tid,bundle in allocated:
                moving=travel[tid]>EPS
                if moving:travel[tid]=max(0,travel[tid]-dt)
                else:remaining[tid]=max(0,remaining[tid]-dt)
                for r,n in bundle.items():busy[r]+=dt*n
                if detail:segments.append(dict(task_id=tid,start=now,finish=now+dt,zone_id=by[tid]["zone_id"],work_zones=by[tid].get("work_zones",[by[tid]["zone_id"]]),resources=bundle,phase="MOVE" if moving else "WORK",edge_states=dict(edges)))
            yield env.timeout(dt)
            n_events+=1
        if "reason" not in result:result["reason"]="未知"
    try:
        env.process(runner());env.run()
    except Exception as exc:
        result.update(status="ERROR",reason=repr(exc))
    # Resource allocations are interval-local; terminal state never retains them.
    occupied_at_termination=dict(owners)
    owners.clear()
    hours=env.now
    paid=calendar.paid_hours_until(hours) if use_calendar else hours
    labor=sum(c["hourly_rates_krw"].get(r,0)*n*paid for r,n in caps.items() if "crew" in r or r=="inspector")
    equipment=sum(c["hourly_rates_krw"].get(r,0)*n*paid for r,n in caps.items() if r in ("excavator","truck"))
    overhead=c["site_cost_per_calendar_day_krw"]*max(1,math.ceil(hours/24))
    costs=dict(materials=c["fixed_material_cost_krw"],labor=labor,equipment=equipment,temporary=c["temporary_works_cost_krw"],site=overhead)
    cost_enabled=c.get('estimate_cost',True)
    if cost_enabled:
        event("","COST_SETTLEMENT","ASSUMED full-shift retained hire")
        if events:events[-1]["cost_delta_krw"]=sum(costs.values())
    result.update(policy_id=policy,scenario_id=scenario.id,elapsed_hours=hours if result["status"]=="COMPLETED" else None,
        observed_until_hour=hours,cost_krw=sum(costs.values()) if cost_enabled else None,cost_components=costs if cost_enabled else {},cost_status='ASSUMED' if cost_enabled else 'NOT_ESTIMATED',
        completed_tasks=len(done),task_count=len(tasks),event_count=n_events,
        task_times={k:{"start":v,"finish":done.get(k)} for k,v in starts.items()},
        busy_hours=dict(busy),wait_task_hours=dict(waits),paid_resource_hours=paid,
        events=events,segments=segments,allocated_at_end={},occupied_at_termination=occupied_at_termination,
        scenario_fingerprint=digest({"factor":{t["task_id"]:scenario.factor(t["task_id"]) for t in tasks},
            "release":{t["task_id"]:scenario.release(t) for t in tasks},"rain_first_60_days":[scenario.rainy(d*24) for d in range(60)]}))
    finish_run(budget_attempt,result["status"])
    return result

def audit(result,tasks,capacities):
    errors=[]; by={t["task_id"]:t for t in tasks}; times=result["task_times"]
    for tid,timing in times.items():
        for pred in by[tid]["predecessors"]:
            if pred not in times or times[pred]["finish"] is None or timing["start"]+EPS<times[pred]["finish"]+by[tid].get("predecessor_lags",{}).get(pred,by[tid].get("lag",0)):errors.append("precedence "+tid)
    points=sorted({x for s in result["segments"] for x in (s["start"],s["finish"])})
    for a,b in zip(points,points[1:]):
        active=[s for s in result["segments"] if s["start"]<=a+EPS and s["finish"]>=b-EPS]
        used=Counter();zones=[]
        for s in active:
            used.update(s["resources"]);zones.extend(s.get("work_zones",[s["zone_id"]]))
            if by[s["task_id"]].get("heavy") and (s["edge_states"].get("trunk")=="FINISHED_RESTRICTED" or any(s["edge_states"].get(wz)=="FINISHED_RESTRICTED" for wz in s.get("work_zones",[s["zone_id"]]))):errors.append("access")
        if any(n>capacities[r] for r,n in used.items()):errors.append("resource")
        if len(zones)!=len(set(zones)):errors.append("space")
    for z in {t["zone_id"] for t in tasks}:
        intervals=sorted((v["start"],v["finish"]) for tid,v in times.items() if z in by[tid].get("work_zones",[by[tid]["zone_id"]]) and v["finish"] is not None)
        if any(b>c+EPS for (a,b),(c,d) in zip(intervals,intervals[1:])):errors.append("persistent zone occupancy")
    return errors
