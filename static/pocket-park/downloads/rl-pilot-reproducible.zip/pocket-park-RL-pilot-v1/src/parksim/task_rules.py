"""P2 fixed quantities; multi-zone drainage work and separate nursery units."""
from shapely.geometry import shape
from shapely.ops import unary_union
from .common import config,csvwrite,DATA,dump
RULE_VERSION='aggregate-P2-0.3'
def generate(model):
    objects=model['objects'];ledger=model['quantity_ledger'];tasks=[];by={o['object_id']:o for o in objects}
    def ids(z,kinds):return [o['object_id'] for o in objects if o['zone']==z and o['kind'] in kinds]
    def qty(z,stage):return sum(q['quantity'] for q in ledger if q['activity_type']==stage and by[q['object_id']]['zone']==z)
    def add(tid,z,stage,q,unit,rate,bundle,preds,outputs=None,heavy=False,lag=0,material=0,closes=None,work_zones=None):
        tasks.append(dict(task_id=tid,wbs_code=stage,zone_id=z,activity_type=tid.split('_',1)[-1],
            input_object_ids=[],output_object_ids=outputs or [],quantity=q,unit=unit,predecessors=preds,lag=lag,
            required_resource_bundle=bundle,productivity=rate,productivity_unit=unit+'/crew_hour',productivity_model_id=tid.split('_',1)[-1]+'_ASSUMED',
            fixed_setup_time=.20,travel_hours=(.15 if z in 'AB' else .10) if heavy else .03,
            work_polygon_id='ZONE_'+z,work_zones=work_zones or [z],access_node_id=z,heavy=heavy,closes=closes,
            conflict_class='exclusive_all_work_zones',material_release_hour=material,material_requirement='ASSUMED',calendar_id='WEEKDAY_8H',
            weather_rule='STOP_RAIN',interrupt_policy='RESUME_REMAINDER',inspection_gate=stage in ['23','70'],
            cost_rule_id='FULL_SHIFT_RETAINED',quantity_source='IFC_ROUNDTRIP',rule_version=RULE_VERSION,provenance_status='ASSUMED'))
    add('INIT','SITE','00',5,'ea',2,{'earth_crew':1},[],[o['object_id'] for o in objects if o['kind']=='protection'])
    tasks[-1]['input_object_ids']=[o['object_id'] for o in objects if o['kind']=='preserved_tree']
    zones={z:shape(by['ZONE_'+z]['geometry']) for z in 'ABCD'}
    pipe_zones={z:[wz for wz,g in zones.items() if shape(by['PIPE_'+z]['geometry']).intersection(g).length>1e-8] for z in 'ABCD'}
    endpoints={'A':['A','B'],'B':['B','D'],'C':['C','D'],'D':['D']}
    for z in 'ABCD':
        t=lambda name:z+'_'+name
        earth={'earth_crew':1,'excavator':1,'truck':1};land={'landscape_crew':1};pave={'paving_crew':1}
        add(t('strip'),z,'10',qty(z,'topsoil'),'m3',12,earth,['INIT'],heavy=True)
        add(t('grade'),z,'11',qty(z,'grading'),'m3',10,earth,[t('strip')],heavy=True)
        add(t('trench'),z,'20',qty(z,'trench'),'m3',4,earth,[t('grade')],heavy=True)
        add(t('chamber'),z,'21',1,'ea',1,earth,[t('trench')],ids(z,['chamber']),True,material=8)
        add(t('pipe'),z,'22',qty(z,'pipe_install'),'m',5,{'earth_crew':1},
            [wz+'_trench' for wz in pipe_zones[z]]+[wz+'_chamber' for wz in endpoints[z]],ids(z,['pipe']),True,material=8,work_zones=pipe_zones[z])
        add(t('inspect'),z,'23',1,'ea',2,{'inspector':1},[t('pipe')],work_zones=pipe_zones[z])
        add(t('backfill'),z,'24',qty(z,'backfill'),'m3',6,earth,[pz+'_inspect' for pz in 'ABCD' if z in pipe_zones[pz]],heavy=True)
        if qty(z,'foundations')>0:add(t('foundation'),z,'30',qty(z,'foundations'),'m3',1.5,earth,[t('backfill')],heavy=True)
        add(t('pits'),z,'31',qty(z,'tree_pits'),'m3',3,earth,[t('backfill')],heavy=True)
        soft=ids(z,['green','shrub','lawn']);protection=unary_union([shape(o['geometry']) for o in objects if o['kind']=='protection'])
        prep=unary_union([shape(by[oid]['geometry']) for oid in soft]).difference(protection).area
        add(t('soil'),z,'32',prep,'m2',45,land,[t('pits')])
        new=ids(z,['new_tree']);add(t('trees'),z,'33',len(new),'ea',2,{'landscape_crew':1,'excavator':1},[t('soil')],new,True,material=16)
        paved=ids(z,['walkway','plaza']);area=sum(by[oid].get('area_m2',0) for oid in paved)
        add(t('curb'),z,'39',qty(z,'curb_install'),'m',6,pave,[t('trees')]+([t('foundation')] if qty(z,'foundations')>0 else []),ids(z,['curb']),True)
        add(t('subbase'),z,'40',area,'m2',18,pave,[t('curb')],heavy=True)
        add(t('pavecheck'),z,'41',1,'ea',2,{'inspector':1},[t('subbase')])
        add(t('finish'),z,'42',area,'m2',12,pave,[t('pavecheck')],paved,closes=z)
        shrubs=ids(z,['shrub_plant']);add(t('shrubs'),z,'53',len(shrubs),'ea',20,land,[t('finish')],shrubs)
        grass=ids(z,['lawn']);add(t('turf'),z,'54',sum(by[oid]['area_m2'] for oid in grass),'m2',30,land,[t('finish')],grass)
        bases=ids(z,['green']);mulch=unary_union([shape(by[oid]['geometry']) for oid in bases]).difference(protection).area
        add(t('mulch'),z,'55',mulch,'m2',25,land,[t('finish')],bases)
        furniture=[]
        for kind,rate in [('bench',.5),('pergola',.0625)]:
            found=ids(z,[kind])
            if found:
                add(t(kind),z,'60',len(found),'ea',rate,land,[t('foundation'),t('finish')],found,lag=24,material=24);furniture.append(t(kind))
        add(t('check'),z,'70',1,'ea',1,{'inspector':1},[t('shrubs'),t('turf'),t('mulch')]+furniture)
    add('RESTORE','SITE','71',1,'ea',.25,{'earth_crew':1},[z+'_check' for z in 'ABCD'],closes='trunk')
    add('HANDOVER','SITE','72',1,'ea',.5,{'inspector':1},['RESTORE'])
    return tasks

def save(tasks):
    dump(DATA/"tasks.json",tasks)
    csvwrite(DATA/"tasks.csv",tasks)
    csvwrite(DATA/"dependencies.csv",[{"predecessor":p,"successor":t["task_id"],"relationship":"FINISH_START","lag_hours":t["lag"]} for t in tasks for p in t["predecessors"]])
    csvwrite(DATA/"object_task_map.csv",[{"object_id":o,"task_id":t["task_id"],"role":role} for t in tasks for role,key in [("OUTPUT","output_object_ids"),("INPUT","input_object_ids")] for o in t[key]])
    c=config()
    csvwrite(DATA/"resources.csv",[{"resource_id":r,"capacity":n,"rate_krw_per_h":c["hourly_rates_krw"].get(r,0),"basis":"ASSUMED"} for r,n in c["resources"].items()])
