import time,platform,sys,sqlite3,json
from datetime import datetime,timezone
from pathlib import Path
import pandas as pd
import yaml
from .common import ROOT,DATA,read,dump,digest,codehash,config,filehash,csvwrite
from .simulator import simulate,audit,POLICIES

def reserve_run(run_id):
    """Transactional budget reservation, safe for simultaneous worker processes."""
    path=ROOT/"results/budget.sqlite"
    path.parent.mkdir(exist_ok=True)
    with sqlite3.connect(path,timeout=30) as db:
        db.execute("CREATE TABLE IF NOT EXISTS attempts (id INTEGER PRIMARY KEY, run_id TEXT, created_utc TEXT, status TEXT)")
        db.execute("BEGIN IMMEDIATE")
        if db.execute("SELECT COUNT(*) FROM attempts").fetchone()[0]>=10000:raise RuntimeError("10,000회 실행예산 초과")
        cur=db.execute("INSERT INTO attempts(run_id,created_utc,status) VALUES (?,?,?)",(run_id,datetime.now(timezone.utc).isoformat(),"STARTED"))
        return cur.lastrowid

def finish_run(attempt,status):
    with sqlite3.connect(ROOT/"results/budget.sqlite",timeout=30) as db:db.execute("UPDATE attempts SET status=? WHERE id=?",(status,attempt))

def execute(policy,scenario,folder,detail=True):
    tasks=read(DATA/"tasks.json")
    baseline=read(DATA/"baseline_geometry.json")
    inputs=dict(code_hash=codehash(),config_hash=filehash(ROOT/"configs/baseline.yaml"),baseline_hash=baseline["baseline_hash"],tasks_hash=digest(tasks))
    key=digest({**inputs,"policy":policy,"scenario":str(scenario)})
    run_id=f"{policy}_{scenario}_{key[:10]}"
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    path=folder/(run_id+".json")
    if path.exists():return read(path)
    started=datetime.now(timezone.utc).isoformat();clock=time.perf_counter()
    result=simulate(tasks,policy=policy,scenario_id=str(scenario),detail=detail)
    result["run_id"]=run_id
    result["manifest"]={**inputs,"started_utc":started,"finished_utc":datetime.now(timezone.utc).isoformat(),"wall_seconds":time.perf_counter()-clock,"python":sys.version,"platform":platform.platform(),"rules":"aggregate-P2-0.3","output":path.name}
    result["audit_errors"]=audit(result,tasks,config()["resources"]) if detail else None
    if result["audit_errors"]:result["status"]="ERROR";result["reason"]="independent audit failed"
    for e in result["events"]:e.update(run_id=run_id,scenario_id=str(scenario),policy_id=policy)
    dump(path,result)
    if detail:csvwrite(folder/("events_"+run_id+".csv"),result["events"])
    return result

def smoke():
    ex=yaml.safe_load((ROOT/"configs/experiment.yaml").read_text(encoding="utf-8"))
    folder=ROOT/"results/smoke_v1"
    records=[]
    # First campaign is intentionally serial; two-worker equivalence is unit tested.
    for i in range(ex["smoke_scenarios"]):
        sid=ex["seed_namespaces"]["smoke"]+i
        for policy in POLICIES:
            records.append(execute(policy,sid,folder/"runs",detail=True))
        if (i+1)%10==0:print(f"smoke: {(i+1)*3}/102",flush=True)
    columns=["run_id","scenario_id","policy_id","status","elapsed_hours","cost_krw","completed_tasks","task_count","event_count","scenario_fingerprint","reason"]
    csvwrite(folder/"run_summary.csv",[{k:r[k] for k in columns} for r in records])
    dump(folder/"run_manifest.json",[{"run_id":r["run_id"],"status":r["status"],**r["manifest"]} for r in records])
    dump(folder/"seed_manifest.json",dict(stage="smoke",scenario_ids=list(range(10000,10000+ex["smoke_scenarios"])),paired=True,other_stages=ex["seed_namespaces"],policies=list(POLICIES),runs=len(records),candidates=3))
    for i in range(ex["smoke_scenarios"]):
        assert len({r["scenario_fingerprint"] for r in records[i*3:i*3+3]})==1
    return records

def export_budget():
    with sqlite3.connect(ROOT/"results/budget.sqlite") as db:
        frame=pd.read_sql_query("SELECT * FROM attempts",db)
    frame.to_csv(ROOT/"results/budget.csv",index=False,encoding="utf-8-sig")
    return len(frame)
