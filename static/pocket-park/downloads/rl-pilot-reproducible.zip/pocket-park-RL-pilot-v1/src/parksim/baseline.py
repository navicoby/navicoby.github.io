import json
import itertools
import math
import numpy as np
from shapely.geometry import box, Point, LineString, mapping, shape
from shapely.ops import unary_union
from .common import ROOT, DATA, config, dump, guid, csvwrite, digest

LOCAL_WKT = 'LOCAL_CS["Synthetic park local metres",LOCAL_DATUM["Synthetic origin",0],UNIT["metre",1],AXIS["X",EAST],AXIS["Y",NORTH]]'

def elevation(x, y):
    return .015 * (40-x) + .018 * y

def build():
    c = config()
    site = box(0, 0, 40, 50)
    zones = {"A": box(0,25,20,50), "B": box(20,25,40,50), "C":box(0,0,20,25), "D":box(20,0,40,25)}
    # Original reference-informed layout, not a tracing of any precedent.
    # 2m clear paving ring, 0.2m modular orthogonal boundaries.
    ring = box(8,10,32,40).difference(box(10,12,30,38))
    walkway = ring.union(box(19,0,21,10))
    pockets = unary_union([box(16,0,24,4),box(32,12,38,22),
                          box(5,27,8,31),box(13,40,19,43),box(9,6,15,10)])
    plaza = pockets.difference(walkway)
    p2=json.loads((ROOT/'data/raw/planting_P2.json').read_text(encoding='utf-8'))
    shrub=unary_union([shape(m['geometry']) for m in p2['masses']])
    cover={'walkway':walkway,'plaza':plaza,'lawn':shape(p2['turf']),'shrub':shrub,'green':shape(p2['tree_base'])}
    kerb=shape(p2['kerb'])
    existing = [Point(*p) for p in c["preserved_trees"]]
    protection = unary_union([p.buffer(1.75) for p in existing])
    access = {"trunk": LineString([(20,0),(20,25)]),
              "A":LineString([(20,25),(10,35)]), "B":LineString([(20,25),(23,34),(30,35)]),
             "C":LineString([(20,25),(10,15)]), "D":LineString([(20,25),(30,15)])}
    # A connected conceptual stormwater tree, draining to south gate outfall.
    # Pipe work is assigned by service branch; exact trench work envelopes remain a later refinement.
    pipes={"A":LineString([(9,39),(31,39)]),"B":LineString([(31,39),(31,11)]),
           "C":LineString([(9,11),(31,11)]),"D":LineString([(31,11),(31,0)])}
    chambers=[Point(9,39),Point(31,39),Point(9,11),Point(31,11)]
    chamber_footprints=unary_union([p.buffer(.5,cap_style=3) for p in chambers])
    trench_all=unary_union([g.buffer(.25,cap_style=2) for g in pipes.values()]).difference(chamber_footprints)
    corridor = unary_union([p.buffer(1.0, cap_style=2) for p in access.values()])
    trees=[Point(t['x_m'],t['y_m']) for t in p2['trees']]
    objects = []
    def add(oid, kind, geom, zone="SITE", **kw):
        p = geom.representative_point()
        objects.append(dict(object_id=oid, global_id=guid(oid), geometry_id=oid, kind=kind,
            zone=zone, geometry=mapping(geom), elevation_m=elevation(p.x,p.y),
            provenance="SYNTHETIC_DERIVED", **kw))
    def zoneof(p):
        return next(k for k,v in zones.items() if v.covers(p))
    for z,g in zones.items(): add("ZONE_"+z,"zone",g,z)
    def polygon_only(g):
        if g.geom_type=="Polygon":return [g]
        return [p for child in getattr(g,"geoms",[]) for p in polygon_only(child)]
    for k,g in cover.items():
        for z,zg in zones.items():
            part=unary_union(polygon_only(g.intersection(zg)))
            if part.area > 0: add(f"{k}_{z}",k,part,z,area_m2=part.area)
    for i,p in enumerate(existing,1): add(f"E{i:03}","preserved_tree",p,zoneof(p),count=1)
    for t,p in zip(p2['trees'],trees): add(t['object_id'],'new_tree',p,zoneof(p),count=1,species=t['species'],grade=t['grade'])
    for t in p2['shrubs']:
        p=Point(t['x_m'],t['y_m']);add('P2_'+t['point_id'],'shrub_plant',p,zoneof(p),count=1,species=t['species'],grade=t['grade'],mass_id=t['mass_id'])
    for i,(x,y) in enumerate([(35,14.8),(35,19.2),(5.6,29),(14.8,42),(17.4,42),(11.6,7)],1):
        add(f"BENCH{i:02}","bench",Point(x,y),zoneof(Point(x,y)),count=1)
    add("PERGOLA01","pergola",box(33,15,37,19),"D",count=1)
    for z,g in pipes.items():add("PIPE_"+z,"pipe",g,z,length_m=g.length)
    for z,p in zip("ABCD",chambers):add("CHAMBER_"+z,"chamber",p,z,count=1)
    paved_union=cover["walkway"].union(cover["plaza"])
    # Exclude outer entrances and shared internal paving boundaries from kerb.
    curb=paved_union.boundary.difference(site.boundary)
    for z,zg in zones.items():
        cg=curb.intersection(zg)
        if cg.length>0:add("CURB_"+z,"curb",unary_union(polygon_only(kerb.intersection(zg))),z,length_m=cg.length,area_m2=kerb.intersection(zg).area)
    for k,g in access.items(): add("ACCESS_"+k,"access",g,k if k in zones else "SITE",width_m=2.0)
    for i,p in enumerate(existing,1): add(f"PROTECT{i:02}","protection",p.buffer(1.75),zoneof(p))
    add("TERRAIN","terrain",site)
    add("CONTEXT_SIDEWALK","context_sidewalk",box(-5,-2,45,0),"CONTEXT")
    add("CONTEXT_ROAD","context_road",box(-5,-10,45,-2),"CONTEXT")
    quantities=[]
    def q(oid,stage,amount,unit,formula,exclusion):
        quantities.append(dict(quantity_id=f"{oid}:{stage}",object_id=oid,activity_type=stage,quantity=amount,unit=unit,
             formula=formula,quantity_source="SYNTHETIC_DERIVED",assumption_source="configs/baseline.yaml",
             duplicate_exclusion=exclusion,soil_state=("COMPACTED" if stage in ("backfill","subbase","sand_bedding") else "BANK") if unit=="m3" else "NA"))
    for z,g in zones.items():
        usable=g.difference(protection)
        ztrees=[p for p in trees if zoneof(p)==z]
        # Below-stripping excavation footprints are disjoint from grading.
        trench = trench_all.intersection(g)
        chamber = chamber_footprints.intersection(g)
        pits=unary_union([p.buffer(.5) for p in ztrees])
        foundations=unary_union([shape(o["geometry"]).buffer(.35) if o["kind"]!="pergola" else shape(o["geometry"]).boundary.buffer(.15)
                      for o in objects if o["zone"]==z and o["kind"] in ("bench","pergola","light")])
        # Disjoint subtraction ensures general grading never counts structural excavation.
        foundations=foundations.difference(trench.union(chamber)).difference(pits)
        grading=usable.difference(trench.union(chamber).union(pits).union(foundations))
        q("ZONE_"+z,"topsoil",usable.area*.15,"m3","zone.area * 0.15; no existing trees", "upper 0.15m only")
        q("ZONE_"+z,"grading",grading.area*.10,"m3","disjoint grading footprint * 0.10", "below stripping; excludes trench/pits/foundations")
        q("ZONE_"+z,"trench",trench.area*.65+chamber.area*.95,"m3","trench footprint * 0.65 + chamber footprint * 0.95 below stripping", "below stripping; chamber junctions counted once")
        q("PIPE_"+z,"pipe_install",pipes[z].length,"m","connected branch line.length", "not a hydraulic design")
        # OD envelope deducted only outside chamber excavation, so connections are not counted twice.
        pipe_volume_share=sum(pg.difference(chamber_footprints).intersection(g).length*math.pi*.11**2 for pg in pipes.values())
        chamber_volume=chamber.area*.8*.8*.85
        q('ZONE_'+z,'backfill',max(0,trench.area*.55+chamber.area*.95-pipe_volume_share-chamber_volume),'m3',
          'trench excavation - 0.10m bedding - OD220 pipe envelope + chamber excavation - below-strip chamber envelope',
          'COMPACTED; excludes chamber overlap from pipe volume')
        q("ZONE_"+z,"tree_pits",pits.area*.65,"m3","tree pit union.area * 0.65", "below stripping; excluded from grading")
        q("ZONE_"+z,"foundations",foundations.area*.4,"m3","disjoint foundation footprint * 0.40", "below stripping; excluded from grading")
    for o in objects:
        if "area_m2" in o: q(o["object_id"],"cover",o["area_m2"],"m2","polygon.area", "final cover counted once; subbase not extra site area")
        elif "count" in o: q(o["object_id"],"preserve" if o["kind"]=="preserved_tree" else "install",o["count"],"ea","object count","preserved trees excluded from new planting")
        if o["kind"] in ("walkway","plaza"):
            q(o["object_id"],"blocks",o["area_m2"]/.04,"ea","area / (0.20 * 0.20)","net module equivalent; cuts/joints/waste excluded")
            q(o["object_id"],"subbase",o["area_m2"]*.15,"m3","area * 0.15", "compacted aggregate; not additional surface area")
            q(o["object_id"],"sand_bedding",o["area_m2"]*.03,"m3","area * 0.03", "layer volume; not additional surface area")
        if o["kind"]=="curb":q(o["object_id"],"curb_install",o["length_m"],"m","paving union boundary minus entrances; clipped by zone", "granite section 0.15 x 0.20m ASSUMED")
    model=dict(design_version="0.4.0-R1",design_status="USER_REVISED_R1",crs=LOCAL_WKT,units="metre",origin="synthetic southwest; no real georeferencing",objects=objects,cover_areas={**{k:g.area for k,g in cover.items()},"curb":kerb.area},quantity_ledger=quantities)
    model["baseline_hash"]=digest(model)
    return model

def validate(model):
    objects=model["objects"]
    assert abs(sum(model["cover_areas"].values())-2000)<1e-8
    cover=[shape(o["geometry"]) for o in objects if "area_m2" in o]
    assert abs(sum(g.area for g in cover)-unary_union(cover).area)<1e-8
    assert len([o for o in objects if o["kind"]=="new_tree"])==16
    assert len([o for o in objects if o["kind"]=="shrub_plant"])==677
    assert len([o for o in objects if o["kind"]=="preserved_tree"])==0
    assert len({o["global_id"] for o in objects})==len(objects)
    assert all(shape(o["geometry"]).is_valid for o in objects)
    new=[shape(o["geometry"]) for o in objects if o["kind"]=="new_tree"]
    obstacles=unary_union([shape(o["geometry"]).buffer(.6 if o["kind"]=="pipe" else 0) for o in objects if o["kind"] in ("walkway","plaza","protection","pipe")])
    assert all(p.buffer(.5).disjoint(obstacles) for p in new)
    bykind=lambda k:unary_union([shape(o["geometry"]) for o in objects if o["kind"]==k])
    paved=bykind("walkway").union(bykind("plaza"))
    assert paved.geom_type=="Polygon", "Disconnected paving"
    assert bykind("walkway").equals(box(8,10,32,40).difference(box(10,12,30,38)).union(box(19,0,21,10)))
    assert bykind("protection").disjoint(paved), "Preserved tree protection meets paving"
    assert bykind("pergola").within(bykind("plaza"))
    for o in objects:
        if o["kind"]=="bench":
            p=shape(o["geometry"]);dx,dy=(.3,.9) if o["object_id"]=="BENCH03" else (.9,.3)
            assert bykind("plaza").covers(box(p.x-dx,p.y-dy,p.x+dx,p.y+dy))
    assert all(abs(q["quantity"]-round(q["quantity"]))<1e-6 for q in model["quantity_ledger"] if q["unit"]=="ea")
    minimum=min(p.distance(q) for i,p in enumerate(new) for q in new[i+1:])
    pipe=bykind("pipe")
    assert abs(pipe.length-83)<1e-8
    assert bykind("protection").disjoint(pipe.buffer(.25))
    assert all(shape(o["geometry"]).distance(pipe)<1e-8 for o in objects if o["kind"]=="chamber")
    assert bykind("protection").disjoint(bykind("access").buffer(1,cap_style=2))
    return {"cover_area_m2":2000,"new_trees":16,"shrubs":677,"preserved_trees":0,"object_count":len(objects),"geometry_valid":True,
            "paving_connected":True,"walkway_clear_width_m":2.0,"loop_centerline_length_m":100,
            "benches_within_recessed_pockets":True,"pergola_outside_walkway":True,
            "preserved_tree_protection_clear_of_paving":True,"new_tree_minimum_spacing_m":minimum,
            "pipe_length_m":pipe.length,"chambers_on_pipe_network":True,
            "pipe_trench_and_temporary_access_clear_of_tree_protection":True,
            "hydraulics_validated":False,"field_validated":False,"simulation_recomputed":"See results/run_manifest.json"}

def save(model):
    import geopandas as gpd
    DATA.mkdir(parents=True,exist_ok=True)
    dump(DATA/"baseline_geometry.json",model)
    csvwrite(DATA/"objects.csv",[{k:v for k,v in o.items() if k!="geometry"} for o in model["objects"]],fields=["object_id","global_id","geometry_id","kind","zone","elevation_m","provenance","area_m2","count","length_m","width_m","species","grade","mass_id"])
    csvwrite(DATA/"quantity_ledger.csv",model["quantity_ledger"])
    path=DATA/"baseline.gpkg"
    if path.exists(): path.unlink()
    for kind in sorted({o["kind"] for o in model["objects"]}):
        rows=[{**{k:v for k,v in o.items() if k!="geometry"},"geometry":shape(o["geometry"])} for o in model["objects"] if o["kind"]==kind]
        gpd.GeoDataFrame(rows,crs=LOCAL_WKT).to_file(path,layer=kind,driver="GPKG")
    dump(DATA/"geometry_validation.json",validate(model))
