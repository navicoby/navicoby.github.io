"""Research prototype. All physical and economic defaults are synthetic."""
__version__ = "0.1.0"
