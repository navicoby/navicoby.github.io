import json
from datetime import datetime,timedelta
from pathlib import Path
import ifcopenshell
import ifcopenshell.api as api
import ifcopenshell.util.element
import ifcopenshell.validate
from shapely.geometry import shape,Point,Polygon
from .common import guid,config,dump

def write(path,model,tasks=None,result=None):
    f=ifcopenshell.file(schema="IFC4X3_ADD2")
    def root(cls,key,name=None,ptype=None):
        obj=api.run("root.create_entity",f,ifc_class=cls,name=name or key,**({"predefined_type":ptype} if ptype else {}))
        obj.GlobalId=guid(key)
        return obj
    project=root("IfcProject","PROJECT","Synthetic pocket park 2000m2")
    units=[f.create_entity("IfcSIUnit",UnitType=k,Name=v) for k,v in [("LENGTHUNIT","METRE"),("AREAUNIT","SQUARE_METRE"),("VOLUMEUNIT","CUBIC_METRE"),("TIMEUNIT","SECOND")]]
    project.UnitsInContext=f.create_entity("IfcUnitAssignment",Units=units)
    context=api.run("context.add_context",f,context_type="Model")
    body=api.run("context.add_context",f,context_type="Model",context_identifier="Body",target_view="MODEL_VIEW",parent=context)
    site=root("IfcSite","SITE","Local synthetic site; not georeferenced")
    api.run("aggregate.assign_object",f,products=[site],relating_object=project)
    products={}
    classes={"walkway":("IfcPavement","FLEXIBLE"),"plaza":("IfcPavement","FLEXIBLE"),
        "pipe":("IfcPipeSegment","RIGIDSEGMENT"),"chamber":("IfcDistributionChamberElement","SUMP"),
        "bench":("IfcFurniture","USERDEFINED"),"light":("IfcLightFixture","POINTSOURCE"),
        "terrain":("IfcGeographicElement","TERRAIN"),"pergola":("IfcBuildingElementProxy","USERDEFINED")}
    def point(x,y,z=0):return f.create_entity("IfcCartesianPoint",Coordinates=(float(x),float(y),float(z)))
    def solid(poly,z,depth):
        exterior=list(poly.exterior.coords)
        p2=lambda x,y:f.create_entity("IfcCartesianPoint",Coordinates=(float(x),float(y)))
        outer=f.create_entity("IfcPolyline",Points=[p2(x,y) for x,y in exterior])
        holes=[f.create_entity("IfcPolyline",Points=[p2(x,y) for x,y in r.coords]) for r in poly.interiors]
        profile=f.create_entity("IfcArbitraryProfileDefWithVoids",ProfileType="AREA",OuterCurve=outer,InnerCurves=holes) if holes else f.create_entity("IfcArbitraryClosedProfileDef",ProfileType="AREA",OuterCurve=outer)
        return f.create_entity("IfcExtrudedAreaSolid",SweptArea=profile,Position=f.create_entity("IfcAxis2Placement3D",Location=point(0,0,z)),ExtrudedDirection=f.create_entity("IfcDirection",DirectionRatios=(0.,0.,1.)),Depth=depth)
    for o in model["objects"]:
        kind=o["kind"]
        cls,ptype=classes.get(kind,("IfcGeographicElement","VEGETATION") if kind in ("new_tree","preserved_tree","green","lawn","shrub","shrub_plant","rain_garden") else ("IfcBuildingElementProxy","USERDEFINED"))
        obj=root(cls,o["object_id"],o["object_id"],ptype)
        if ptype=="USERDEFINED":obj.ObjectType=kind
        api.run("spatial.assign_container",f,products=[obj],relating_structure=site)
        pset=api.run("pset.add_pset",f,product=obj,name="LCS_Provenance")
        props={"ObjectId":o["object_id"],"Kind":kind,"Zone":o["zone"],"GeometryJSON":json.dumps(o["geometry"]),"Source":"SYNTHETIC", "ElevationMetre":o["elevation_m"]}
        api.run("pset.edit_pset",f,pset=pset,properties=props)
        quantities=[q for q in model["quantity_ledger"] if q["object_id"]==o["object_id"]]
        if quantities:
            entries=[]
            for q in quantities:
                qclass,attr={"m2":("IfcQuantityArea","AreaValue"),"m3":("IfcQuantityVolume","VolumeValue"),"m":("IfcQuantityLength","LengthValue"),"ea":("IfcQuantityCount","CountValue")}[q["unit"]]
                value=int(round(q["quantity"])) if q["unit"]=="ea" else float(q["quantity"])
                if q["unit"]=="ea" and abs(value-q["quantity"])>1e-6:raise ValueError("non-integer IFC count")
                entries.append(f.create_entity(qclass,Name=q["activity_type"],Description=json.dumps(q,ensure_ascii=False),**{attr:value}))
            qto=f.create_entity("IfcElementQuantity",GlobalId=guid(o["object_id"]+":QTO"),Name="LCS_Quantities",Quantities=entries)
            f.create_entity("IfcRelDefinesByProperties",GlobalId=guid(o["object_id"]+":QTO_REL"),RelatedObjects=[obj],RelatingPropertyDefinition=qto)
        # Concept geometry only; terrain uses actual synthetic plane vertices.
        g=shape(o["geometry"])
        if kind=="terrain":
            from .baseline import elevation
            points=f.create_entity("IfcCartesianPointList3D",CoordList=[(x,y,elevation(x,y)) for x,y in [(0.,0.),(40.,0.),(40.,50.),(0.,50.)]])
            items=[f.create_entity("IfcTriangulatedFaceSet",Coordinates=points,Closed=False,CoordIndex=[(1,2,3),(1,3,4)])]
            rep_type="Tessellation"
        else:
            if g.geom_type=="Point":g=g.buffer(.22 if kind in ("new_tree","preserved_tree") else .3,quad_segs=8)
            elif g.geom_type in ("LineString","MultiLineString","GeometryCollection"):g=g.buffer(config()["pipe_diameter_m"]/2 if kind=="pipe" else .075 if kind=="curb" else .04,cap_style=2)
            polys=list(g.geoms) if g.geom_type=="MultiPolygon" else [g]
            depth=3. if kind in ("new_tree","preserved_tree") else .1
            items=[solid(p,o["elevation_m"],depth) for p in polys if isinstance(p,Polygon) and p.area>0]
            rep_type="SweptSolid"
        if items:
            representation=f.create_entity("IfcShapeRepresentation",ContextOfItems=body,RepresentationIdentifier="Body",RepresentationType=rep_type,Items=items)
            obj.Representation=f.create_entity("IfcProductDefinitionShape",Representations=[representation])
            api.run("geometry.edit_object_placement",f,product=obj)
        products[o["object_id"]]=obj
    if tasks:
        schedule=api.run("sequence.add_work_schedule",f,name="SIMULATED "+(result.get("run_id","representative") if result else "baseline"),predefined_type="PLANNED",start_time=config()["start_datetime"])
        schedule.GlobalId=guid("SCHEDULE")
        calendar=f.create_entity("IfcWorkCalendar",GlobalId=guid("WORKCALENDAR"),Name="Mon-Fri 08-12 and 13-17",PredefinedType="NOTDEFINED")
        periods=[f.create_entity("IfcTimePeriod",StartTime=a,EndTime=b) for a,b in [("08:00:00","12:00:00"),("13:00:00","17:00:00")]]
        recur=f.create_entity("IfcRecurrencePattern",RecurrenceType="WEEKLY",WeekdayComponent=[1,2,3,4,5],TimePeriods=periods)
        calendar.WorkingTimes=[f.create_entity("IfcWorkTime",Name="ASSUMED standard week",RecurrencePattern=recur)]
        resources={}
        for r,capacity in config()["resources"].items():
            cls="IfcCrewResource" if "crew" in r else "IfcLaborResource" if r=="inspector" else "IfcConstructionEquipmentResource"
            resource=api.run("resource.add_resource",f,ifc_class=cls,name=r)
            resource.GlobalId=guid("RESOURCE_"+r)
            ps=api.run("pset.add_pset",f,product=resource,name="LCS_Construction")
            api.run("pset.edit_pset",f,pset=ps,properties={"Capacity":capacity,"RateKrwPerHour":config()["hourly_rates_krw"].get(r,0),"Basis":"ASSUMED; full retained shift"})
            resources[r]=resource
        wbs={}; entities={}
        for z in ("SITE","A","B","C","D"):
            parent=api.run("sequence.add_task",f,work_schedule=schedule,name="WBS_"+z,identification="WBS_"+z)
            parent.GlobalId=guid("WBS_"+z);wbs[z]=parent
        for t in tasks:
            obj=api.run("sequence.add_task",f,parent_task=wbs[t["zone_id"]],name=t["task_id"],identification=t["task_id"],predefined_type="CONSTRUCTION")
            obj.GlobalId=guid("TASK_"+t["task_id"]);entities[t["task_id"]]=obj
            ps=api.run("pset.add_pset",f,product=obj,name="LCS_Construction")
            api.run("pset.edit_pset",f,pset=ps,properties={"TaskJSON":json.dumps(t),"ScheduleBasis":"SIMULATED_NOT_ACTUAL"})
            api.run("control.assign_control",f,relating_control=calendar,related_objects=[obj])
            for oid in t["output_object_ids"]:api.run("sequence.assign_product",f,relating_product=products[oid],related_object=obj)
            for oid in t["input_object_ids"]:api.run("sequence.assign_process",f,relating_process=obj,related_object=products[oid])
            for r in t["required_resource_bundle"]:api.run("sequence.assign_process",f,relating_process=obj,related_object=resources[r])
        for tid,obj in entities.items():obj.Identification=tid
        for t in tasks:
            for p in t["predecessors"]:
                relation=api.run("sequence.assign_sequence",f,relating_process=entities[p],related_process=entities[t["task_id"]],sequence_type="FINISH_START")
                if t["lag"]:
                    relation.TimeLag=f.create_entity("IfcLagTime",LagValue=f.create_entity("IfcDuration",f"PT{t['lag']}H"),DurationType="ELAPSEDTIME")
        # assign_sequence cascades dates; write measured simulation outputs only
        # after the complete dependency graph is present.
        if result:
            start=datetime.fromisoformat(config()["start_datetime"])
            for tid,times in result["task_times"].items():
                if times["finish"] is None:continue
                tt=api.run("sequence.add_task_time",f,task=entities[tid])
                tt.DataOrigin="PREDICTED";tt.DurationType="ELAPSEDTIME"
                tt.ScheduleStart=(start+timedelta(hours=times["start"])).isoformat()
                tt.ScheduleFinish=(start+timedelta(hours=times["finish"])).isoformat()
                tt.ScheduleDuration=f"PT{(times['finish']-times['start'])*3600:.6f}S"
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    f.write(str(path))

def extract(path):
    f=ifcopenshell.open(str(path))
    objects=[];ledger=[]
    for obj in f.by_type("IfcProduct"):
        ps=ifcopenshell.util.element.get_psets(obj).get("LCS_Provenance")
        if not ps:continue
        o=dict(object_id=ps["ObjectId"],global_id=obj.GlobalId,geometry_id=ps["ObjectId"],kind=ps["Kind"],zone=ps["Zone"],geometry=json.loads(ps["GeometryJSON"]),elevation_m=ps["ElevationMetre"],provenance="SYNTHETIC_DERIVED")
        for rel in obj.IsDefinedBy:
            if rel.is_a("IfcRelDefinesByProperties") and rel.RelatingPropertyDefinition.is_a("IfcElementQuantity"):
                for q in rel.RelatingPropertyDefinition.Quantities:
                    row=json.loads(q.Description);row["quantity"]=float(q[3]);ledger.append(row)
                    if row["activity_type"]=="cover":o["area_m2"]=float(q[3])
                    if row["unit"]=="ea":o["count"]=float(q[3])
                    if row["activity_type"]=="pipe_install":o["length_m"]=float(q[3])
        objects.append(o)
    return dict(objects=objects,quantity_ledger=ledger,schema=f.schema_identifier)

def validate_file(path,model,tasks=None,result=None):
    f=ifcopenshell.open(str(path))
    logger=ifcopenshell.validate.json_logger()
    ifcopenshell.validate.validate(f,logger,express_rules=True)
    schema_errors=[str(x) for x in logger.statements if x["level"]=="error"]
    actual=extract(path)
    errors=[]
    if actual["schema"]!="IFC4X3_ADD2":errors.append("schema")
    if {o["object_id"]:o["global_id"] for o in actual["objects"]}!={o["object_id"]:o["global_id"] for o in model["objects"]}:errors.append("object ids")
    expected={q["quantity_id"]:q["quantity"] for q in model["quantity_ledger"]}
    observed={q["quantity_id"]:q["quantity"] for q in actual["quantity_ledger"]}
    if set(expected)!=set(observed) or any(abs(v-observed.get(k,-999))>1e-8 for k,v in expected.items()):errors.append("quantities")
    units={u.UnitType:(u.Name,u.Prefix) for u in f.by_type("IfcSIUnit")}
    if units.get("LENGTHUNIT")!=("METRE",None):errors.append("metre units")
    if tasks:
        seq={(r.RelatingProcess.Identification,r.RelatedProcess.Identification) for r in f.by_type("IfcRelSequence")}
        if seq!={(p,t["task_id"]) for t in tasks for p in t["predecessors"]}:errors.append("dependencies")
        outputs={(r.RelatingProduct.Name,t.Identification) for r in f.by_type("IfcRelAssignsToProduct") for t in r.RelatedObjects}
        if outputs!={(o,t["task_id"]) for t in tasks for o in t["output_object_ids"]}:errors.append("output relation direction")
        assigned={(r.RelatingProcess.Identification,o.Name) for r in f.by_type("IfcRelAssignsToProcess") for o in r.RelatedObjects}
        expected_assigned={(t["task_id"],r) for t in tasks for r in t["required_resource_bundle"]}|{(t["task_id"],o) for t in tasks for o in t["input_object_ids"]}
        if assigned!=expected_assigned:errors.append("resource/input relations")
        for resource in f.by_type("IfcConstructionResource"):
            if resource.Name not in config()["resources"]:continue
            ps=ifcopenshell.util.element.get_psets(resource).get("LCS_Construction",{})
            if ps.get("Capacity")!=config()["resources"][resource.Name]:errors.append("resource capacity")
        if len(f.by_type("IfcWorkCalendar"))!=1:errors.append("work calendar")
        if result:
            start=datetime.fromisoformat(config()["start_datetime"])
            for t in f.by_type("IfcTask"):
                if t.Identification not in result["task_times"]:continue
                v=result["task_times"][t.Identification]
                for field,key in [("ScheduleStart","start"),("ScheduleFinish","finish")]:
                    expected_time=start+timedelta(hours=v[key])
                    if abs((datetime.fromisoformat(getattr(t.TaskTime,field))-expected_time).total_seconds())>.001:errors.append("schedule "+t.Identification)
                if t.TaskTime.ActualStart or t.TaskTime.ActualFinish:errors.append("actual time falsely set")
    return dict(schema=f.schema_identifier,schema_errors=schema_errors,business_errors=errors,passed=not schema_errors and not errors,objects=len(actual["objects"]),quantities=len(actual["quantity_ledger"]))
