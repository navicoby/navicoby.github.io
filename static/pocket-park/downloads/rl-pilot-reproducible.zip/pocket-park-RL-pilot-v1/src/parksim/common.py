from pathlib import Path
import csv
import hashlib
import json
import uuid
import yaml

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data" / "processed"

def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def config():
    return yaml.safe_load((ROOT / "configs/baseline.yaml").read_text(encoding="utf-8"))

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()

def filehash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def codehash():
    return digest({p.name: filehash(p) for p in sorted((ROOT / "src/parksim").glob("*.py"))})

def guid(key):
    import ifcopenshell.guid
    return ifcopenshell.guid.compress(uuid.uuid5(uuid.NAMESPACE_URL, "parksim:v1:" + key).hex)

def csvwrite(path, rows, fields=None):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows and not fields:
        return
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields or list(rows[0]))
        writer.writeheader()
        writer.writerows([{k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v for k,v in row.items()} for row in rows])
